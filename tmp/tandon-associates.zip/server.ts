import express from "express";
import { createServer as createViteServer } from "vite";
import path from "path";
import { fileURLToPath } from "url";
import Database from "better-sqlite3";
import { createServer } from "http";
import { Server } from "socket.io";

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

const db = new Database("legal_tech.db");

// Initialize Database Tables
db.exec(`
  CREATE TABLE IF NOT EXISTS users (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    email TEXT UNIQUE,
    name TEXT,
    role TEXT, -- 'student', 'lawyer', 'firm_admin', 'client'
    college TEXT,
    is_verified INTEGER DEFAULT 0,
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP
  );

  CREATE TABLE IF NOT EXISTS cases (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    user_id INTEGER,
    client_name TEXT,
    case_title TEXT,
    court_name TEXT,
    status TEXT,
    next_hearing TEXT,
    cnr_number TEXT,
    last_updated DATETIME DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY(user_id) REFERENCES users(id)
  );

  CREATE TABLE IF NOT EXISTS watchdog_subscriptions (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    user_id INTEGER,
    topic TEXT,
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY(user_id) REFERENCES users(id)
  );

  CREATE TABLE IF NOT EXISTS chat_messages (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    room TEXT,
    user_id INTEGER,
    user_name TEXT,
    message TEXT,
    timestamp DATETIME DEFAULT CURRENT_TIMESTAMP
  );

  CREATE TABLE IF NOT EXISTS case_documents (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    case_id INTEGER,
    name TEXT,
    type TEXT,
    size INTEGER,
    url TEXT,
    uploaded_by INTEGER,
    uploaded_at DATETIME DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY(case_id) REFERENCES cases(id),
    FOREIGN KEY(uploaded_by) REFERENCES users(id)
  );

  CREATE TABLE IF NOT EXISTS document_versions (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    document_id INTEGER,
    version_number INTEGER,
    name TEXT,
    url TEXT,
    size INTEGER,
    updated_by INTEGER,
    updated_at DATETIME DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY(document_id) REFERENCES case_documents(id),
    FOREIGN KEY(updated_by) REFERENCES users(id)
  );
`);

async function startServer() {
  const app = express();
  const httpServer = createServer(app);
  const io = new Server(httpServer, {
    cors: { origin: "*" }
  });
  const PORT = 3000;

  app.use(express.json());

  // WebSocket Logic
  io.on("connection", (socket) => {
    console.log("User connected:", socket.id);

    socket.on("join-room", (room) => {
      socket.join(room);
      console.log(`User ${socket.id} joined room: ${room}`);
    });

    socket.on("send-message", (data) => {
      const { room, userId, userName, message } = data;
      db.prepare("INSERT INTO chat_messages (room, user_id, user_name, message) VALUES (?, ?, ?, ?)").run(room, userId, userName, message);
      io.to(room).emit("new-message", { ...data, timestamp: new Date() });
    });

    socket.on("doc-edit", (data) => {
      // Broadcast document edits to others in the same room
      socket.to(data.room).emit("doc-update", data);
    });

    socket.on("disconnect", () => {
      console.log("User disconnected:", socket.id);
    });
  });

  // API Routes
  app.get("/api/health", (req, res) => {
    res.json({ status: "ok", message: "Tandon Associates Legal Tech API is running" });
  });

  // User Auth Mock
  app.post("/api/auth/login", (req, res) => {
    const { email } = req.body;
    let user = db.prepare("SELECT * FROM users WHERE email = ?").get(email);
    if (!user) {
      let role = 'lawyer';
      if (email.endsWith('@tandonassociates.com')) {
        role = email.startsWith('admin@') ? 'firm_admin' : 'lawyer';
      } else if (email.endsWith('.edu')) {
        role = 'student';
      } else if (email.includes('client')) {
        role = 'client';
      }
      
      db.prepare("INSERT INTO users (email, name, role) VALUES (?, ?, ?)").run(email, email.split('@')[0], role);
      user = db.prepare("SELECT * FROM users WHERE email = ?").get(email);
    }
    res.json(user);
  });

  // Conflict of Interest Checker
  app.get("/api/conflict-check", (req, res) => {
    const { name } = req.query;
    if (!name) return res.status(400).json({ error: "Name is required" });
    
    const conflicts = db.prepare("SELECT * FROM cases WHERE client_name LIKE ? OR case_title LIKE ?").all(`%${name}%`, `%${name}%`);
    res.json({
      hasConflict: conflicts.length > 0,
      conflicts: conflicts
    });
  });

  // Watchdog Subscriptions
  app.get("/api/watchdog", (req, res) => {
    const { userId } = req.query;
    const subs = db.prepare("SELECT * FROM watchdog_subscriptions WHERE user_id = ?").all(userId);
    res.json(subs);
  });

  app.post("/api/watchdog", (req, res) => {
    const { userId, topic } = req.body;
    db.prepare("INSERT INTO watchdog_subscriptions (user_id, topic) VALUES (?, ?)").run(userId, topic);
    res.json({ success: true });
  });

  // Cases for Client Portal
  app.get("/api/client/cases", (req, res) => {
    const { email } = req.query;
    const cases = db.prepare("SELECT * FROM cases WHERE client_name = ?").all(email);
    res.json(cases);
  });

  // Chat History
  app.get("/api/chat/:room", (req, res) => {
    const { room } = req.params;
    const messages = db.prepare("SELECT * FROM chat_messages WHERE room = ? ORDER BY timestamp ASC").all(room);
    res.json(messages);
  });

  // eCourts CNR Tracking Mock
  app.get("/api/cases/:cnr", (req, res) => {
    const { cnr } = req.params;
    const hash = cnr.split('').reduce((acc, char) => acc + char.charCodeAt(0), 0);
    const courts = ["Bombay High Court", "Delhi High Court", "Supreme Court of India", "District Court, Pune", "Karnataka High Court"];
    const statuses = ["Pending", "Disposed", "Orders Reserved", "Adjourned", "Active"];
    const court = courts[hash % courts.length];
    const status = statuses[hash % statuses.length];
    
    setTimeout(() => {
      res.json({
        cnr,
        title: `State vs. ${hash % 2 === 0 ? 'Kulkarni' : 'Sharma'} & Ors.`,
        court,
        status,
        next_hearing: `2026-0${(hash % 9) + 1}-15`,
        bench: "Division Bench"
      });
    }, 1500);
  });

  // Case Documents
  app.get("/api/cases/:caseId/documents", (req, res) => {
    const { caseId } = req.params;
    const docs = db.prepare("SELECT * FROM case_documents WHERE case_id = ?").all(caseId);
    res.json(docs);
  });

  app.post("/api/cases/:caseId/documents", (req, res) => {
    const { caseId } = req.params;
    const { name, type, size, url, uploadedBy } = req.body;
    const result = db.prepare("INSERT INTO case_documents (case_id, name, type, size, url, uploaded_by) VALUES (?, ?, ?, ?, ?, ?)").run(caseId, name, type, size, url, uploadedBy);
    
    // Create initial version
    db.prepare("INSERT INTO document_versions (document_id, version_number, name, url, size, updated_by) VALUES (?, ?, ?, ?, ?, ?)").run(result.lastInsertRowid, 1, name, url, size, uploadedBy);
    
    res.json({ success: true, id: result.lastInsertRowid });
  });

  app.get("/api/documents/:docId/versions", (req, res) => {
    const { docId } = req.params;
    const versions = db.prepare("SELECT v.*, u.name as user_name FROM document_versions v JOIN users u ON v.updated_by = u.id WHERE v.document_id = ? ORDER BY v.version_number DESC").all(docId);
    res.json(versions);
  });

  app.post("/api/documents/:docId/versions", (req, res) => {
    const { docId } = req.params;
    const { name, url, size, updatedBy } = req.body;
    const lastVersion = db.prepare("SELECT MAX(version_number) as max_v FROM document_versions WHERE document_id = ?").get(docId);
    const nextVersion = (lastVersion?.max_v || 0) + 1;
    
    db.prepare("INSERT INTO document_versions (document_id, version_number, name, url, size, updated_by) VALUES (?, ?, ?, ?, ?, ?)").run(docId, nextVersion, name, url, size, updatedBy);
    
    // Update main document pointer
    db.prepare("UPDATE case_documents SET name = ?, url = ?, size = ? WHERE id = ?").run(name, url, size, docId);
    
    res.json({ success: true, version: nextVersion });
  });

  // Clients
  app.get("/api/clients", (req, res) => {
    const clients = db.prepare("SELECT * FROM users WHERE role = 'client'").all();
    res.json(clients);
  });

  // Vite middleware for development
  if (process.env.NODE_ENV !== "production") {
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: "spa",
    });
    app.use(vite.middlewares);
  } else {
    app.use(express.static(path.join(__dirname, "dist")));
    app.get("*", (req, res) => {
      res.sendFile(path.join(__dirname, "dist/index.html"));
    });
  }

  httpServer.listen(PORT, "0.0.0.0", () => {
    console.log(`Server running on http://localhost:${PORT}`);
  });
}

startServer();
