export type UserRole = 'firm' | 'solo' | 'corporate' | 'student';
export type Section = 'dashboard' | 'cases' | 'ecourts' | 'contracts' | 'documents' | 'team' | 'analytics' | 'settings' | 'ai' | 'ai-chat' | 'innovation' | 'client-portal' | 'conflict-checker' | 'watchdog' | 'student-hub' | 'compliance-audit' | 'research' | 'drafting' | 'clients' | 'privacy' | 'terms' | 'disclaimer';

export interface User {
  id: number;
  email: string;
  name: string;
  role: string;
  userType: UserRole;
  isStudentVerified?: boolean;
  studentId?: string;
  university?: string;
}

export interface Notification {
  id: string;
  title: string;
  message: string;
  time: string;
  isRead: boolean;
  type: 'info' | 'warning' | 'success';
}
