import React, { useState, useEffect } from 'react';
import { 
  Menu,
  Scale, 
  Search, 
  FileText, 
  Users, 
  CreditCard, 
  ShieldCheck, 
  Activity, 
  BookOpen, 
  Gavel, 
  Bell,
  ChevronRight,
  LayoutDashboard,
  Settings,
  HelpCircle,
  LogOut,
  Cpu,
  Plus,
  Briefcase,
  FileCheck,
  BarChart3,
  Lock,
  Mail,
  Eye,
  MapPin,
  Image as ImageIcon,
  Video,
  Mic,
  Music,
  Volume2,
  Zap,
  BrainCircuit,
  MessageSquare,
  Copy,
  Download,
  Trash2,
  X,
  Info,
  ThumbsUp,
  ThumbsDown,
  ChevronDown,
  ChevronUp,
  Bold,
  Italic,
  List,
  ListOrdered,
  Bookmark,
  AlertCircle,
  CheckCircle2,
  Info,
  Send,
  Share2,
  Clock,
  ArrowLeft,
  Moon,
  Sun,
  History,
  GraduationCap,
  Quote,
  Timer,
  Receipt,
  ClipboardList,
  Building2,
  AlertTriangle,
  FolderTree,
  FileSearch
} from 'lucide-react';
import { motion, AnimatePresence } from 'framer-motion';
import { io, Socket } from 'socket.io-client';
import Markdown from 'react-markdown';

// Component Imports
import SidebarItem from './components/SidebarItem';
import StatCard from './components/StatCard';
import TableRow from './components/TableRow';
import EmptyState from './components/EmptyState';
import ChatMessageContent from './components/ChatMessageContent';
import StudentVerificationModal from './components/modals/StudentVerificationModal';
import MootPerformanceModal from './components/modals/MootPerformanceModal';
import HearingCalendar from './components/HearingCalendar';
import LegalDictionary from './components/LegalDictionary';
import DocumentVersionModal from './components/modals/DocumentVersionModal';

declare global {
  interface Window {
    aistudio: {
      hasSelectedApiKey: () => Promise<boolean>;
      openSelectKey: () => Promise<void>;
    };
  }
}

import { 
  askLegalAssistantWithThinking,
  quickLegalHelp,
  searchLegalPrecedents,
  locateLegalServices,
  analyzeEvidenceImage,
  generateVisualEvidence,
  editEvidenceImage,
  animateEvidenceVideo,
  transcribeLegalAudio,
  synthesizeLegalSpeech,
  generateLegalDocument
} from './services/legalService';

// --- Types ---
type UserRole = 'firm' | 'solo' | 'corporate' | 'student';
type Section = 'dashboard' | 'cases' | 'ecourts' | 'contracts' | 'documents' | 'team' | 'analytics' | 'settings' | 'ai' | 'ai-chat' | 'innovation' | 'client-portal' | 'conflict-checker' | 'watchdog' | 'student-hub' | 'compliance-audit' | 'research' | 'drafting' | 'clients' | 'privacy' | 'terms' | 'disclaimer' | 'calendar' | 'for-lawyers' | 'for-corporates' | 'lots-247' | 'challan-pay';

interface User {
  id: number;
  email: string;
  name: string;
  role: string;
  userType: UserRole;
  isStudentVerified?: boolean;
  studentId?: string;
  university?: string;
}

interface Notification {
  id: string;
  title: string;
  message: string;
  time: string;
  isRead: boolean;
  type: 'info' | 'warning' | 'success';
}

// --- Main App ---

export default function App() {
  const [activeTab, setActiveTab] = useState<Section>('dashboard');
  const [showLanding, setShowLanding] = useState(true);
  const [isSignup, setIsSignup] = useState(false);
  const [firmName, setFirmName] = useState('');
  const [user, setUser] = useState<User | null>(() => {
    const saved = localStorage.getItem('legal_user');
    return saved ? JSON.parse(saved) : null;
  });
  const [isDarkMode, setIsDarkMode] = useState(() => {
    return localStorage.getItem('legal_dark_mode') === 'true';
  });
  const [isVerifyingStudent, setIsVerifyingStudent] = useState(false);
  const [isViewingDocHistory, setIsViewingDocHistory] = useState(false);
  const [selectedDocForHistory, setSelectedDocForHistory] = useState<{id: string, name: string} | null>(null);
  const [verificationStep, setVerificationStep] = useState<'form' | 'upload' | 'pending' | 'success'>('form');
  const [studentDetails, setStudentDetails] = useState({ university: '', studentId: '', gradYear: '' });
  const [isAuth, setIsAuth] = useState(() => {
    return localStorage.getItem('legal_is_auth') === 'true';
  });
  const [loginEmail, setLoginEmail] = useState('demo@lawfirm.com');
  const [loginPassword, setLoginPassword] = useState('Demo@123');
  const [authError, setAuthError] = useState('');
  const [loading, setLoading] = useState(false);
  const [toasts, setToasts] = useState<Array<{ id: string, message: string, type: 'success' | 'error' | 'info' }>>([]);

  const addToast = (message: string, type: 'success' | 'error' | 'info' = 'success') => {
    const id = Date.now().toString();
    setToasts([...toasts, { id, message, type }]);
    setTimeout(() => {
      setToasts(prev => prev.filter(t => t.id !== id));
    }, 3000);
  };

  const [aiPrompt, setAiPrompt] = useState('');
  const [aiResponse, setAiResponse] = useState('');
  const [draftType, setDraftType] = useState('Legal Notice');
  const [draftInput, setDraftInput] = useState('');
  const [draftResult, setDraftResult] = useState('');
  const [chatHistory, setChatHistory] = useState<Array<{
    id: string;
    role: 'user' | 'ai';
    content: string;
    type: 'text' | 'image' | 'video' | 'audio';
    timestamp: Date;
    isError?: boolean;
    feedback?: 'up' | 'down';
  }>>([]);
  const [isAiLoading, setIsAiLoading] = useState(false);

  const hasPermission = (permission: string) => {
    if (!user) return false;
    if (user.role === 'Admin') return true;
    
    const permissions: Record<string, string[]> = {
      'Lawyer': ['view_cases', 'edit_cases', 'view_team', 'view_analytics', 'view_innovation', 'view_ecourts', 'view_contracts', 'view_documents'],
      'Junior Lawyer': ['view_cases', 'view_documents', 'view_ecourts', 'view_innovation'],
      'Paralegal': ['view_cases', 'view_documents', 'view_ecourts'],
      'Client': ['view_client_portal', 'upload_documents'],
      'Student': ['view_student_hub', 'view_innovation']
    };

    return permissions[user.role]?.includes(permission) || false;
  };

  const [aiMode, setAiMode] = useState<'chat' | 'search' | 'maps' | 'vision' | 'edit' | 'video' | 'audio' | 'tts'>('chat');
  const [aiFile, setAiFile] = useState<File | null>(null);
  const [aiFilePreview, setAiFilePreview] = useState<string | null>(null);
  const [showExportMenu, setShowExportMenu] = useState(false);
  const [showNotifications, setShowNotifications] = useState(false);
  const [notifications, setNotifications] = useState<Notification[]>([
    { id: '1', title: 'Case Update', message: 'Hearing for Case #1234 has been rescheduled to March 15th.', time: '2h ago', isRead: false, type: 'info' },
    { id: '2', title: 'Document Ready', message: 'The Non-Disclosure Agreement for Client X is ready for review.', time: '5h ago', isRead: false, type: 'success' },
    { id: '3', title: 'Subscription Warning', message: 'Your professional tier subscription expires in 3 days.', time: '1d ago', isRead: true, type: 'warning' },
  ]);

  const [cases, setCases] = useState<any[]>(() => {
    const saved = localStorage.getItem('legal_cases');
    return saved ? JSON.parse(saved) : [
      { id: '1', name: 'Smith vs Johnson', type: 'Civil Litigation', status: 'Active', nextHearing: 'Dec 15, 2025', timestamp: new Date('2025-12-15').getTime(), department: 'Litigation' },
      { id: '2', name: 'ABC Corp Merger', type: 'Corporate', status: 'Active', nextHearing: 'Dec 20, 2025', timestamp: new Date('2025-12-20').getTime(), department: 'Corporate' },
      { id: '3', name: 'Property Dispute', type: 'Real Estate', status: 'Pending', nextHearing: 'Jan 5, 2026', timestamp: new Date('2026-01-05').getTime(), department: 'Real Estate' },
      { id: '4', name: 'Divorce Settlement', type: 'Family Law', status: 'Completed', nextHearing: 'Closed', timestamp: new Date('2025-11-01').getTime(), department: 'Family' },
    ];
  });

  const [contracts, setContracts] = useState<any[]>(() => {
    const saved = localStorage.getItem('legal_contracts');
    return saved ? JSON.parse(saved) : [
      { id: '1', name: 'Service Agreement', client: 'Tech Corp Inc', expiryDate: 'Dec 31, 2025', status: 'Active', timestamp: new Date('2025-12-31').getTime() },
      { id: '2', name: 'Employment Contract', client: 'John Doe', expiryDate: 'Jun 15, 2026', status: 'Active', timestamp: new Date('2026-06-15').getTime() },
    ];
  });

  const [teamMembers, setTeamMembers] = useState<any[]>(() => {
    const saved = localStorage.getItem('legal_team');
    return saved ? JSON.parse(saved) : [
      { id: '1', name: 'John Doe', email: 'john@lawfirm.com', role: 'Admin', status: 'Active' },
      { id: '2', name: 'Jane Smith', email: 'jane@lawfirm.com', role: 'Attorney', status: 'Active' },
      { id: '3', name: 'Mike Johnson', email: 'mike@lawfirm.com', role: 'Paralegal', status: 'Active' },
    ];
  });

  // Student Hub Extensions
  const [mootHistory, setMootHistory] = useState<any[]>(() => {
    const saved = localStorage.getItem('legal_moot_history');
    return saved ? JSON.parse(saved) : [
      { id: '1', caseName: 'State vs. Sharma (Criminal Appeal)', score: 92, date: 'Oct 12, 2024', rank: 'Best Speaker' },
      { id: '2', caseName: 'TechCorp vs. DataPrivacy (IP Rights)', score: 88, date: 'Nov 25, 2024', rank: 'Runner Up' },
      { id: '3', caseName: 'GreenEarth vs. PolluterInc (Environmental)', score: 95, date: 'Jan 15, 2025', rank: 'Winner' }
    ];
  });
  const [isAddingMootPerformance, setIsAddingMootPerformance] = useState(false);
  const [newMootPerformance, setNewMootPerformance] = useState({
    caseName: '',
    score: 80,
    date: new Date().toISOString().split('T')[0],
    rank: ''
  });
  
  // Solo/Firm Extensions
  const [timeLogs, setTimeLogs] = useState<any[]>(() => {
    const saved = localStorage.getItem('legal_time_logs');
    return saved ? JSON.parse(saved) : [];
  });
  const [invoices, setInvoices] = useState<any[]>(() => {
    const saved = localStorage.getItem('legal_invoices');
    return saved ? JSON.parse(saved) : [];
  });
  const [tasks, setTasks] = useState<any[]>(() => {
    const saved = localStorage.getItem('legal_tasks');
    return saved ? JSON.parse(saved) : [];
  });

  const [cnrInput, setCnrInput] = useState('');
  const [cnrResult, setCnrResult] = useState<any>(null);
  const [isCnrLoading, setIsCnrLoading] = useState(false);
  const [cnrError, setCnrError] = useState('');
  const [savedCnrs, setSavedCnrs] = useState<string[]>(() => {
    const saved = localStorage.getItem('savedCnrs');
    return saved ? JSON.parse(saved) : [];
  });

  // Document Generation State
  const [docTemplate, setDocTemplate] = useState('Non-Disclosure Agreement');
  const [docDetails, setDocDetails] = useState('');
  const [docResult, setDocResult] = useState('');
  const [isDocLoading, setIsDocLoading] = useState(false);
  
  // Innovation Hub State
  const [innovationMode, setInnovationMode] = useState<'moot' | 'brief' | 'statute' | 'timeline' | 'exhibit' | 'policy' | 'evidence' | 'audio' | 'computable-contract' | 'algorithmic-triage'>('brief');
  const [computableInput, setComputableInput] = useState('');
  const [computableResult, setComputableResult] = useState<any>(null);
  const [isComputableLoading, setIsComputableLoading] = useState(false);
  const [triageInput, setTriageInput] = useState('');
  const [triageResult, setTriageResult] = useState<any>(null);
  const [isTriageLoading, setIsTriageLoading] = useState(false);
  const [mootCase, setMootCase] = useState('');
  const [isMootActive, setIsMootActive] = useState(false);
  const [mootChat, setMootChat] = useState<Array<{role: 'judge' | 'counsel', text: string}>>([]);
  const [mootInput, setMootInput] = useState('');
  const [isMootLoading, setIsMootLoading] = useState(false);
  
  const [briefInput, setBriefInput] = useState('');
  const [briefResult, setBriefResult] = useState('');
  const [isBriefLoading, setIsBriefLoading] = useState(false);
  
  const [statuteInput, setStatuteInput] = useState('');
  const [statuteResult, setStatuteResult] = useState('');
  const [isStatuteLoading, setIsStatuteLoading] = useState(false);
  
  const [timelineInput, setTimelineInput] = useState('');
  const [timelineResult, setTimelineResult] = useState<any[]>([]);
  const [isTimelineLoading, setIsTimelineLoading] = useState(false);
  const [isEvidenceLoading, setIsEvidenceLoading] = useState(false);
  const [evidenceResult, setEvidenceResult] = useState('');
  const [evidenceFile, setEvidenceFile] = useState<File | null>(null);
  const [evidencePreview, setEvidencePreview] = useState<string | null>(null);
  
  const [isAudioLoading, setIsAudioLoading] = useState(false);
  const [audioResult, setAudioResult] = useState('');
  const [audioFile, setAudioFile] = useState<File | null>(null);

  const [isExhibitLoading, setIsExhibitLoading] = useState(false);
  const [exhibitResult, setExhibitResult] = useState<string | null>(null);
  const [exhibitPrompt, setExhibitPrompt] = useState('');
  const [exhibitFile, setExhibitFile] = useState<string | null>(null);

  const [isSpeaking, setIsSpeaking] = useState(false);
  const [speechUrl, setSpeechUrl] = useState<string | null>(null);
  
  // New Features State
  const [socket, setSocket] = useState<Socket | null>(null);
  const [teamChatRoom, setTeamChatRoom] = useState('general');
  const [teamMessages, setTeamMessages] = useState<any[]>([]);
  const [teamInput, setTeamInput] = useState('');
  
  const [conflictSearch, setConflictSearch] = useState('');
  const [conflictResult, setConflictResult] = useState<any>(null);
  const [isConflictLoading, setIsConflictLoading] = useState(false);
  
  const [watchdogTopic, setWatchdogTopic] = useState('');
  const [watchdogSubs, setWatchdogSubs] = useState<any[]>([]);
  const [isWatchdogLoading, setIsWatchdogLoading] = useState(false);
  const [watchdogSummaries, setWatchdogSummaries] = useState<Record<number, string>>({});
  const [isSummarizingWatchdog, setIsSummarizingWatchdog] = useState<Record<number, boolean>>({});
  
  const [clientCases, setClientCases] = useState<any[]>([]);
  const [isClientLoading, setIsClientLoading] = useState(false);

  const [hasApiKey, setHasApiKey] = useState(false);
  const [isSidebarOpen, setIsSidebarOpen] = useState(false);

  const [docSearchQuery, setDocSearchQuery] = useState('');
  const [docTypeFilter, setDocTypeFilter] = useState('All');
  const [docDateFilter, setDocDateFilter] = useState('All Time');
  const [docClientFilter, setDocClientFilter] = useState('All');

  const [globalSearch, setGlobalSearch] = useState('');
  const [caseSearchQuery, setCaseSearchQuery] = useState('');
  const [caseStatusFilter, setCaseStatusFilter] = useState('All');
  const [caseDateFilter, setCaseDateFilter] = useState('All');

  const [recentDocuments, setRecentDocuments] = useState<any[]>(() => {
    const saved = localStorage.getItem('legal_documents');
    return saved ? JSON.parse(saved) : [
      { name: 'Court_Order_Smith.pdf', type: 'PDF', date: 'Today', size: '2.1 MB', timestamp: new Date().getTime(), client: 'Smith & Co' },
      { name: 'Contract_Draft.docx', type: 'Word', date: 'Yesterday', size: '1.3 MB', timestamp: new Date().getTime() - 86400000, client: 'Tech Corp' },
      { name: 'Financial_Analysis.xlsx', type: 'Excel', date: '2 days ago', size: '0.9 MB', timestamp: new Date().getTime() - 172800000, client: 'Global Fin' },
      { name: 'Client_Intake_Form.pdf', type: 'PDF', date: 'Last Week', size: '0.5 MB', timestamp: new Date().getTime() - 604800000, client: 'John Doe' },
      { name: 'Settlement_Agreement.docx', type: 'Word', date: 'Last Month', size: '1.8 MB', timestamp: new Date().getTime() - 2592000000, client: 'Smith & Co' },
    ];
  });

  useEffect(() => {
    localStorage.setItem('legal_documents', JSON.stringify(recentDocuments));
  }, [recentDocuments]);

  const handleFileUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;
    
    const newDoc = {
      name: file.name,
      type: file.name.split('.').pop()?.toUpperCase() || 'File',
      date: 'Just now',
      size: `${(file.size / 1024 / 1024).toFixed(1)} MB`,
      timestamp: new Date().getTime(),
      client: 'Unassigned'
    };
    
    setRecentDocuments([newDoc, ...recentDocuments]);
    addToast(`${file.name} uploaded successfully!`, 'success');
  };

  const filteredDocuments = recentDocuments.filter(doc => {
    const matchesSearch = doc.name.toLowerCase().includes(docSearchQuery.toLowerCase()) || 
                          doc.client.toLowerCase().includes(docSearchQuery.toLowerCase());
    const matchesType = docTypeFilter === 'All' || doc.type === docTypeFilter;
    const matchesClient = docClientFilter === 'All' || doc.client === docClientFilter;
    
    let matchesDate = true;
    const now = new Date().getTime();
    if (docDateFilter === 'Past 24 Hours') {
      matchesDate = now - doc.timestamp <= 86400000;
    } else if (docDateFilter === 'Past Week') {
      matchesDate = now - doc.timestamp <= 604800000;
    } else if (docDateFilter === 'Past Month') {
      matchesDate = now - doc.timestamp <= 2592000000;
    }

    return matchesSearch && matchesType && matchesDate && matchesClient;
  });

  const filteredCases = cases.filter(c => {
    const matchesSearch = c.name.toLowerCase().includes(caseSearchQuery.toLowerCase()) || 
                          c.type.toLowerCase().includes(caseSearchQuery.toLowerCase());
    const matchesStatus = caseStatusFilter === 'All' || c.status === caseStatusFilter;
    
    let matchesDate = true;
    if (caseDateFilter !== 'All' && c.timestamp) {
      const now = new Date().getTime();
      if (caseDateFilter === 'Upcoming (7 Days)') {
        matchesDate = c.timestamp >= now && c.timestamp <= now + 7 * 86400000;
      } else if (caseDateFilter === 'Upcoming (30 Days)') {
        matchesDate = c.timestamp >= now && c.timestamp <= now + 30 * 86400000;
      } else if (caseDateFilter === 'Past Cases') {
        matchesDate = c.timestamp < now;
      }
    }
    
    return matchesSearch && matchesStatus && matchesDate;
  });

  useEffect(() => {
    localStorage.setItem('legal_user', JSON.stringify(user));
    localStorage.setItem('legal_is_auth', JSON.stringify(isAuth));
    localStorage.setItem('legal_dark_mode', JSON.stringify(isDarkMode));
    localStorage.setItem('legal_cases', JSON.stringify(cases));
    localStorage.setItem('legal_contracts', JSON.stringify(contracts));
    localStorage.setItem('legal_team', JSON.stringify(teamMembers));
    localStorage.setItem('legal_moot_history', JSON.stringify(mootHistory));
    localStorage.setItem('legal_time_logs', JSON.stringify(timeLogs));
    localStorage.setItem('legal_invoices', JSON.stringify(invoices));
    localStorage.setItem('legal_tasks', JSON.stringify(tasks));

    if (isDarkMode) {
      document.documentElement.classList.add('dark');
    } else {
      document.documentElement.classList.remove('dark');
    }
  }, [user, isAuth, isDarkMode, cases, contracts, teamMembers, mootHistory, timeLogs, invoices, tasks]);

  useEffect(() => {
    const checkApiKey = async () => {
      if (window.aistudio) {
        const selected = await window.aistudio.hasSelectedApiKey();
        setHasApiKey(selected);
      }
    };
    checkApiKey();
  }, []);

  useEffect(() => {
    if (isAuth && user) {
      const newSocket = io();
      setSocket(newSocket);
      
      newSocket.emit('join-room', 'general');
      
      // Phase 1: Chat History Persistence
      fetch(`/api/chat/general`)
        .then(res => res.json())
        .then(data => {
          setTeamMessages(data.map((m: any) => ({
            room: m.room,
            userId: m.user_id,
            userName: m.user_name,
            message: m.message,
            timestamp: new Date(m.timestamp)
          })));
        })
        .catch(err => console.error('Failed to fetch chat history:', err));
      
      newSocket.on('new-message', (msg) => {
        setTeamMessages(prev => [...prev, msg]);
      });

      // Fetch initial data
      fetchWatchdogSubs();
      if (user.role === 'client') {
        fetchClientCases();
      }

      return () => {
        newSocket.disconnect();
      };
    }
  }, [isAuth, user]);

  const fetchWatchdogSubs = async () => {
    if (!user) return;
    try {
      const res = await fetch(`/api/watchdog?userId=${user.id}`);
      if (res.ok) setWatchdogSubs(await res.json());
    } catch (err) {
      console.error(err);
    }
  };

  const fetchClientCases = async () => {
    if (!user) return;
    setIsClientLoading(true);
    try {
      const res = await fetch(`/api/client/cases?email=${user.email}`);
      if (res.ok) setClientCases(await res.json());
    } catch (err) {
      console.error(err);
    } finally {
      setIsClientLoading(false);
    }
  };

  const handleSendTeamMessage = () => {
    if (!socket || !teamInput || !user) return;
    socket.emit('send-message', {
      room: teamChatRoom,
      userId: user.id,
      userName: user.name,
      message: teamInput
    });
    setTeamInput('');
  };

  const handleConflictCheck = async () => {
    if (!conflictSearch) return;
    setIsConflictLoading(true);
    try {
      const res = await fetch(`/api/conflict-check?name=${conflictSearch}`);
      if (res.ok) {
        const data = await res.json();
        if (data.hasConflict) {
          const analysis = await askLegalAssistantWithThinking(`
            Analyze these potential legal conflicts of interest for client "${conflictSearch}":
            ${JSON.stringify(data.conflicts)}
            
            Determine if these represent a direct ethical conflict, a potential risk, or if they are likely benign. Provide a clear recommendation.
          `);
          setConflictResult({ ...data, aiAnalysis: analysis });
        } else {
          setConflictResult(data);
        }
      }
    } catch (err) {
      console.error(err);
    } finally {
      setIsConflictLoading(false);
    }
  };

  const handleAddWatchdog = async () => {
    if (!watchdogTopic || !user) return;
    setIsWatchdogLoading(true);
    try {
      const res = await fetch('/api/watchdog', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ userId: user.id, topic: watchdogTopic })
      });
      if (res.ok) {
        setWatchdogTopic('');
        fetchWatchdogSubs();
      }
    } catch (err) {
      console.error(err);
    } finally {
      setIsWatchdogLoading(false);
    }
  };

  const handleGenerateWatchdogSummary = async (sub: any) => {
    setIsSummarizingWatchdog(prev => ({ ...prev, [sub.id]: true }));
    try {
      const summary = await searchLegalPrecedents(`Latest legal updates, amendments, and case law regarding: ${sub.topic}`);
      setWatchdogSummaries(prev => ({ ...prev, [sub.id]: summary.text }));
      addToast(`Generated summary for ${sub.topic}`, 'success');
    } catch (error) {
      addToast('Failed to generate summary', 'error');
    } finally {
      setIsSummarizingWatchdog(prev => ({ ...prev, [sub.id]: false }));
    }
  };

  const handleAnalyzeEvidence = async () => {
    if (!evidenceFile) return;
    setIsEvidenceLoading(true);
    try {
      const reader = new FileReader();
      reader.readAsDataURL(evidenceFile);
      reader.onload = async () => {
        const base64 = (reader.result as string).split(',')[1];
        const result = await analyzeEvidenceImage("Analyze this legal evidence image for key details, tampering, or significant findings.", base64, evidenceFile.type);
        setEvidenceResult(result);
      };
    } catch (error) {
      addToast('Failed to analyze evidence', 'error');
    } finally {
      setIsEvidenceLoading(false);
    }
  };

  const handleTranscribeAudio = async () => {
    if (!audioFile) return;
    setIsAudioLoading(true);
    try {
      const reader = new FileReader();
      reader.readAsDataURL(audioFile);
      reader.onload = async () => {
        const base64 = (reader.result as string).split(',')[1];
        const result = await transcribeLegalAudio(base64, audioFile.type);
        setAudioResult(result);
      };
    } catch (error) {
      addToast('Failed to transcribe audio', 'error');
    } finally {
      setIsAudioLoading(false);
    }
  };

  const handleGenerateExhibit = async () => {
    if (!exhibitPrompt) return;

    if (!hasApiKey && window.aistudio) {
      await window.aistudio.openSelectKey();
      setHasApiKey(true);
    }

    setIsExhibitLoading(true);
    try {
      const base64 = exhibitFile ? exhibitFile.split(',')[1] : undefined;
      const vidUrl = await import('./services/legalService').then(m => m.animateEvidenceVideo(exhibitPrompt, base64));
      if (vidUrl) {
        setExhibitResult(vidUrl);
      }
    } catch (err) {
      console.error(err);
      addToast('Failed to generate exhibit', 'error');
    } finally {
      setIsExhibitLoading(false);
    }
  };

  const handleSpeak = async (text: string) => {
    if (isSpeaking) {
      setIsSpeaking(false);
      return;
    }
    setIsSpeaking(true);
    try {
      const url = await synthesizeLegalSpeech(text);
      if (url) {
        const audio = new Audio(url);
        audio.onended = () => setIsSpeaking(false);
        audio.play();
      }
    } catch (error) {
      addToast('Failed to synthesize speech', 'error');
      setIsSpeaking(false);
    }
  };

  const handleLogin = async (e: React.FormEvent) => {
    e.preventDefault();
    setLoading(true);
    setAuthError('');

    try {
      const res = await fetch('/api/auth/login', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ email: loginEmail })
      });
      
      if (!res.ok) throw new Error('Login failed');
      const data = await res.json();
      
      // Normalize roles from server to frontend types
      let userType: UserRole = 'firm';
      if (data.role === 'student') userType = 'student';
      else if (data.role === 'client') userType = 'corporate'; // Mapping client to corporate for UI
      else if (data.role === 'lawyer') userType = 'solo';
      else if (data.role === 'firm_admin') userType = 'firm';

      setUser({
        id: data.id,
        name: data.name || loginEmail.split('@')[0],
        email: data.email,
        role: data.role,
        userType: userType,
        isStudentVerified: data.is_verified === 1,
        university: data.college || ''
      });
      setIsAuth(true);
      
      // If student and not verified, maybe show hub or dashboard with banner
      if (userType === 'student') {
        setActiveTab('student-hub');
      }
    } catch (err) {
      setAuthError('Failed to login. Please try again.');
    } finally {
      setLoading(false);
    }
  };

  const extractHeaders = (text: string) => {
    const lines = text.split('\n');
    return lines
      .filter(line => line.startsWith('#') || line.toUpperCase() === line.trim() && line.trim().length > 3 && line.trim().length < 50)
      .map((line, index) => ({ id: `header-${index}`, text: line.replace(/^#+\s*/, '').trim() }));
  };

  const handleGenerateComputable = async () => {
    if (!computableInput) return;
    setIsComputableLoading(true);
    try {
      const prompt = `Convert the following legal agreement into a "Computable Contract" format. 
      Include:
      1. Logic Triggers (IF-THEN-ELSE)
      2. Compliance Checkpoints
      3. Automated Execution Steps
      4. JSON-like structure for the logic.
      
      Agreement:
      ${computableInput}`;
      
      const res = await askLegalAssistantWithThinking(prompt);
      setComputableResult(res);
    } catch (err) {
      console.error(err);
    } finally {
      setIsComputableLoading(false);
    }
  };

  const handleRunTriage = async () => {
    if (!triageInput) return;
    setIsTriageLoading(true);
    try {
      const prompt = `Perform an "Algorithmic Triage" for the following legal scenario.
      Map the conditions to specific jurisdiction-based strategies and automated compliance resolutions.
      Format as a decision tree or algorithmic flow.
      
      Scenario:
      ${triageInput}`;
      
      const res = await askLegalAssistantWithThinking(prompt);
      setTriageResult(res);
    } catch (err) {
      console.error(err);
    } finally {
      setIsTriageLoading(false);
    }
  };

  const handleAiAction = async () => {
    if (!aiPrompt && !aiFile) return;

    if ((aiMode === 'video' || aiMode === 'vision') && !hasApiKey) {
      if (window.aistudio) {
        await window.aistudio.openSelectKey();
        setHasApiKey(true);
      }
    }

    setIsAiLoading(true);
    
    // Add user message immediately
    const userMsgId = Date.now().toString();
    const newUserMsg = {
      id: userMsgId,
      role: 'user' as const,
      content: aiPrompt || (aiFile ? `Uploaded file: ${aiFile.name}` : 'Request'),
      type: 'text' as const,
      timestamp: new Date()
    };
    
    setChatHistory(prev => [...prev, newUserMsg]);
    setAiPrompt(''); // Clear input immediately

    try {
      let res;
      let type: 'text' | 'image' | 'video' | 'audio' = 'text';

      switch (aiMode) {
        case 'chat':
          if (newUserMsg.content.toLowerCase().includes('analyze') || newUserMsg.content.length > 50) {
            res = await askLegalAssistantWithThinking(newUserMsg.content);
          } else {
            res = await quickLegalHelp(newUserMsg.content);
          }
          break;
        case 'search':
          const searchRes = await searchLegalPrecedents(newUserMsg.content);
          res = `**Legal Precedents Found:**\n\n${searchRes.text}\n\n**Sources:**\n${searchRes.sources.map((s: any) => `- [${s.web.title}](${s.web.uri})`).join('\n')}`;
          break;
        case 'maps':
          const mapRes = await locateLegalServices(newUserMsg.content);
          res = `**Locations Found:**\n\n${mapRes.text}\n\n**Places:**\n${mapRes.places.map((p: any) => `- [${p.googleMaps.title}](${p.googleMaps.uri})`).join('\n')}`;
          break;
        case 'vision':
          if (aiFilePreview) {
            const base64 = aiFilePreview.split(',')[1];
            res = await analyzeEvidenceImage(newUserMsg.content, base64);
          } else {
            const img = await generateVisualEvidence(newUserMsg.content);
            if (img) {
              res = img;
              type = 'image';
            } else {
              res = "Failed to generate visual evidence.";
            }
          }
          break;
        case 'edit':
          if (aiFilePreview) {
            const base64 = aiFilePreview.split(',')[1];
            const editedImg = await editEvidenceImage(newUserMsg.content, base64);
            if (editedImg) {
              res = editedImg;
              type = 'image';
            } else {
              res = "Failed to edit image.";
            }
          } else {
            res = "Please upload an image to edit.";
          }
          break;
        case 'video':
          const vidUrl = await animateEvidenceVideo(newUserMsg.content, aiFilePreview ? aiFilePreview.split(',')[1] : undefined);
          if (vidUrl) {
             res = vidUrl;
             type = 'video';
          } else {
            res = "Failed to generate video.";
          }
          break;
        case 'audio':
          if (aiFilePreview) {
             const base64 = aiFilePreview.split(',')[1];
             res = await transcribeLegalAudio(base64);
          }
          break;
        case 'tts':
          const audioUrl = await synthesizeLegalSpeech(newUserMsg.content);
          if (audioUrl) {
             res = audioUrl;
             type = 'audio';
             const audio = new Audio(audioUrl);
             audio.play();
          } else {
             res = "Failed to generate speech.";
          }
          break;
      }

      const aiMsg = {
        id: (Date.now() + 1).toString(),
        role: 'ai' as const,
        content: res || 'No response generated.',
        type: type,
        timestamp: new Date()
      };
      setChatHistory(prev => [...prev, aiMsg]);
      setAiResponse(res || '');

    } catch (err: any) {
      console.error(err);
      const errorMsg = {
        id: (Date.now() + 1).toString(),
        role: 'ai' as const,
        content: `Error: ${err.message || 'Failed to process request'}`,
        type: 'text' as const,
        timestamp: new Date(),
        isError: true
      };
      setChatHistory(prev => [...prev, errorMsg]);
    } finally {
      setIsAiLoading(false);
      setAiFile(null);
      setAiFilePreview(null);
    }
  };

  const handleGenerateDraft = async () => {
    if (!draftInput) return;
    setLoading(true);
    try {
      const res = await generateLegalDocument(draftType, draftInput);
      setDraftResult(res || 'Failed to generate draft.');
      addToast('Draft generated successfully!', 'success');
    } catch (err: any) {
      console.error(err);
      addToast('Failed to generate draft: ' + err.message, 'error');
    } finally {
      setLoading(false);
    }
  };

  const handleExportChat = async (format: 'txt' | 'json' | 'pdf' | 'csv' | 'md') => {
    const now = new Date();
    const dateStr = now.toISOString().split('T')[0];
    const timeStr = now.toTimeString().split(' ')[0].replace(/:/g, '-');
    const filename = `legal-research-history-${dateStr}_${timeStr}`;

    if (format === 'txt') {
      const text = chatHistory.map(m => `[${m.timestamp.toLocaleString()}] ${m.role.toUpperCase()}: ${m.type === 'text' ? m.content : '[Media Content]'}`).join('\n\n');
      const blob = new Blob([text], { type: 'text/plain' });
      const url = URL.createObjectURL(blob);
      const a = document.createElement('a');
      a.href = url;
      a.download = `${filename}.txt`;
      a.click();
    } else if (format === 'json') {
      const jsonStr = JSON.stringify(chatHistory, null, 2);
      const blob = new Blob([jsonStr], { type: 'application/json' });
      const url = URL.createObjectURL(blob);
      const a = document.createElement('a');
      a.href = url;
      a.download = `${filename}.json`;
      a.click();
    } else if (format === 'pdf') {
      const { jsPDF } = await import('jspdf');
      const doc = new jsPDF();
      
      doc.setFontSize(16);
      doc.text('Tandon Associates - Legal Research History', 14, 20);
      doc.setFontSize(10);
      doc.text(`Generated on: ${now.toLocaleString()}`, 14, 28);
      
      let y = 40;
      const pageHeight = doc.internal.pageSize.height;
      
      chatHistory.forEach(msg => {
        const roleText = `[${msg.timestamp.toLocaleString()}] ${msg.role.toUpperCase()}:`;
        doc.setFont('helvetica', 'bold');
        
        if (y > pageHeight - 20) {
          doc.addPage();
          y = 20;
        }
        
        doc.text(roleText, 14, y);
        y += 6;
        
        doc.setFont('helvetica', 'normal');
        const content = msg.type === 'text' ? msg.content : `[Media Content: ${msg.type}]`;
        
        // Split text to fit page width
        const splitText = doc.splitTextToSize(content, 180);
        
        splitText.forEach((line: string) => {
          if (y > pageHeight - 20) {
            doc.addPage();
            y = 20;
          }
          doc.text(line, 14, y);
          y += 6;
        });
        
        y += 4; // Extra space between messages
      });
      
      doc.save(`${filename}.pdf`);
    } else if (format === 'csv') {
      const headers = ['Timestamp', 'Role', 'Type', 'Content'];
      const rows = chatHistory.map(m => [
        m.timestamp.toISOString(),
        m.role,
        m.type,
        `"${(m.type === 'text' ? m.content : '[Media Content]').replace(/"/g, '""')}"`
      ]);
      const csvContent = [headers.join(','), ...rows.map(r => r.join(','))].join('\n');
      const blob = new Blob([csvContent], { type: 'text/csv' });
      const url = URL.createObjectURL(blob);
      const a = document.createElement('a');
      a.href = url;
      a.download = `${filename}.csv`;
      a.click();
    } else if (format === 'md') {
      const mdContent = `# Legal Research History\n\nGenerated on: ${now.toLocaleString()}\n\n---\n\n` + 
        chatHistory.map(m => `**[${m.timestamp.toLocaleString()}] ${m.role.toUpperCase()}**\n\n${m.type === 'text' ? m.content : '*[Media Content]*'}`).join('\n\n---\n\n');
      const blob = new Blob([mdContent], { type: 'text/markdown' });
      const url = URL.createObjectURL(blob);
      const a = document.createElement('a');
      a.href = url;
      a.download = `${filename}.md`;
      a.click();
    }
  };

  const handleCopyChat = () => {
    const text = chatHistory.map(m => `[${m.timestamp.toLocaleString()}] ${m.role.toUpperCase()}: ${m.type === 'text' ? m.content : '[Media Content]'}`).join('\n\n');
    navigator.clipboard.writeText(text);
  };

  const handleClearChat = () => {
    if (confirm('Are you sure you want to clear the chat history?')) {
      setChatHistory([]);
    }
  };

  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    if (e.target.files && e.target.files[0]) {
      const file = e.target.files[0];
      setAiFile(file);
      const reader = new FileReader();
      reader.onloadend = () => {
        setAiFilePreview(reader.result as string);
      };
      reader.readAsDataURL(file);
    }
  };

  const handleAddMootPerformance = () => {
    const newEntry = {
      ...newMootPerformance,
      id: Date.now().toString()
    };
    setMootHistory(prev => [...prev, newEntry]);
    setIsAddingMootPerformance(false);
    setNewMootPerformance({
      caseName: '',
      score: 80,
      date: new Date().toISOString().split('T')[0],
      rank: ''
    });
  };

  const handleCnrSearch = async (e: React.FormEvent | string) => {
    if (typeof e !== 'string') {
      e.preventDefault();
    }
    const searchCnr = typeof e === 'string' ? e : cnrInput;
    
    // Phase 1: Strict CNR Validation (16-character alphanumeric)
    const cnrRegex = /^[A-Z0-9]{16}$/i;
    if (!searchCnr || !cnrRegex.test(searchCnr)) {
      setCnrError('Please enter a valid 16-character alphanumeric CNR number.');
      return;
    }
    
    if (typeof e === 'string') {
      setCnrInput(searchCnr);
    }
    
    setIsCnrLoading(true);
    setCnrError('');
    setCnrResult(null);
    try {
      const res = await fetch(`/api/cases/${searchCnr}`);
      if (!res.ok) throw new Error('Failed to fetch case details');
      const data = await res.json();
      setCnrResult(data);
    } catch (err) {
      setCnrError('Could not retrieve case status. Please check the CNR number and try again.');
    } finally {
      setIsCnrLoading(false);
    }
  };

  const handleSaveCnr = (cnr: string) => {
    if (!savedCnrs.includes(cnr)) {
      const newSaved = [cnr, ...savedCnrs].slice(0, 5); // Keep last 5
      setSavedCnrs(newSaved);
      localStorage.setItem('savedCnrs', JSON.stringify(newSaved));
    }
  };

  const handleRemoveSavedCnr = (cnr: string) => {
    const newSaved = savedCnrs.filter(c => c !== cnr);
    setSavedCnrs(newSaved);
    localStorage.setItem('savedCnrs', JSON.stringify(newSaved));
  };

  const markAsRead = (id: string) => {
    setNotifications(notifications.map(n => n.id === id ? { ...n, isRead: true } : n));
  };

  const markAllAsRead = () => {
    setNotifications(notifications.map(n => ({ ...n, isRead: true })));
  };

  const handleGenerateDocument = async () => {
    if (!docDetails) return;
    setIsDocLoading(true);
    try {
      const result = await generateLegalDocument(docTemplate, docDetails);
      setDocResult(result);
    } catch (err) {
      console.error(err);
      setDocResult("Error generating document. Please try again.");
    } finally {
      setIsDocLoading(false);
    }
  };

  const handleStartMoot = async () => {
    if (!mootCase) return;
    setIsMootLoading(true);
    try {
      const initialResponse = await import('./services/legalService').then(m => m.startMootCourtSession(mootCase));
      setMootChat([{ role: 'judge', text: initialResponse }]);
      setIsMootActive(true);
    } catch (err) {
      console.error(err);
    } finally {
      setIsMootLoading(false);
    }
  };

  const handleMootMessage = async () => {
    if (!mootInput) return;
    const userMsg = { role: 'counsel' as const, text: mootInput };
    setMootChat(prev => [...prev, userMsg]);
    setMootInput('');
    setIsMootLoading(true);
    try {
      const history = mootChat.map(m => `${m.role === 'judge' ? 'Judge' : 'Counsel'}: ${m.text}`).join('\n');
      const prompt = `Case Context: ${mootCase}\n\nHistory:\n${history}\nCounsel: ${userMsg.text}\n\nJudge:`;
      const response = await import('./services/legalService').then(m => m.askLegalAssistantWithThinking(prompt));
      setMootChat(prev => [...prev, { role: 'judge', text: response }]);
    } catch (err) {
      console.error(err);
    } finally {
      setIsMootLoading(false);
    }
  };

  const handleGenerateBrief = async () => {
    if (!briefInput) return;
    setIsBriefLoading(true);
    try {
      const res = await import('./services/legalService').then(m => m.generateCaseBrief(briefInput));
      setBriefResult(res);
    } catch (err) {
      console.error(err);
    } finally {
      setIsBriefLoading(false);
    }
  };

  const handleSimplifyStatute = async () => {
    if (!statuteInput) return;
    setIsStatuteLoading(true);
    try {
      const res = await import('./services/legalService').then(m => m.simplifyStatute(statuteInput));
      setStatuteResult(res);
    } catch (err) {
      console.error(err);
    } finally {
      setIsStatuteLoading(false);
    }
  };

  const handleGenerateTimeline = async () => {
    if (!timelineInput) return;
    setIsTimelineLoading(true);
    try {
      const res = await import('./services/legalService').then(m => m.generateEvidenceTimeline(timelineInput));
      setTimelineResult(JSON.parse(res));
    } catch (err) {
      console.error(err);
    } finally {
      setIsTimelineLoading(false);
    }
  };

  if (!isAuth) {
    if (showLanding) {
      return (
        <div className="min-h-screen bg-slate-50 flex flex-col">
          <header className="p-6 flex justify-between items-center bg-white border-b border-slate-100">
            <div className="flex items-center gap-3">
              <div className="bg-emerald-600 p-2 rounded-xl text-white shadow-md shadow-emerald-200">
                <Scale size={24} />
              </div>
              <h1 className="text-xl font-bold text-slate-900">Tandon Associates</h1>
            </div>
            <button 
              onClick={() => setShowLanding(false)}
              className="bg-emerald-600 text-white px-6 py-2.5 rounded-xl font-bold shadow-md shadow-emerald-200 hover:bg-emerald-700 transition-all"
            >
              Sign In
            </button>
          </header>
          
          <main className="flex-1 flex flex-col items-center justify-center p-6 text-center">
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              className="max-w-3xl space-y-8"
            >
              <h2 className="text-5xl md:text-6xl font-extrabold text-slate-900 tracking-tight">
                Modern Legal Operations <br className="hidden md:block" />
                <span className="text-emerald-600">Powered by AI</span>
              </h2>
              <p className="text-xl text-slate-500 max-w-2xl mx-auto leading-relaxed">
                Streamline case tracking, automate document generation, and leverage advanced AI for legal research in one unified platform.
              </p>
              <div className="flex flex-wrap justify-center gap-4 pt-4">
                <button 
                  onClick={() => setShowLanding(false)}
                  className="bg-emerald-600 text-white px-8 py-4 rounded-xl font-bold text-lg shadow-xl shadow-emerald-200 hover:bg-emerald-700 transition-all flex items-center gap-2"
                >
                  Get Started <ChevronRight size={20} />
                </button>
              </div>

              <div className="pt-20 max-w-xl mx-auto">
                <div className="bg-white p-8 rounded-3xl shadow-xl border border-slate-100 text-left space-y-6">
                  <h3 className="text-2xl font-bold text-slate-900">Contact Our Experts</h3>
                  <p className="text-slate-500 text-sm">Have questions? Send us a message and our team will get back to you within 24 hours.</p>
                  <div className="space-y-4">
                    <input type="text" placeholder="Your Name" className="w-full p-3 bg-slate-50 border border-slate-200 rounded-xl outline-none focus:ring-2 focus:ring-emerald-500 transition-all" />
                    <input type="email" placeholder="Email Address" className="w-full p-3 bg-slate-50 border border-slate-200 rounded-xl outline-none focus:ring-2 focus:ring-emerald-500 transition-all" />
                    <textarea placeholder="How can we help?" className="w-full h-32 p-3 bg-slate-50 border border-slate-200 rounded-xl outline-none focus:ring-2 focus:ring-emerald-500 transition-all resize-none"></textarea>
                    <button 
                      onClick={() => addToast('Message sent successfully! We will contact you soon.', 'success')}
                      className="w-full bg-slate-900 text-white py-3 rounded-xl font-bold hover:bg-slate-800 transition-all"
                    >
                      Send Message
                    </button>
                  </div>
                </div>
              </div>
            </motion.div>
          </main>
          
          <footer className="p-10 bg-white border-t border-slate-100">
            <div className="max-w-7xl mx-auto grid grid-cols-1 md:grid-cols-4 gap-10">
              <div className="space-y-4">
                <div className="flex items-center gap-3">
                  <div className="bg-emerald-600 p-2 rounded-lg text-white">
                    <Scale size={20} />
                  </div>
                  <h4 className="font-bold text-slate-900">Tandon Associates</h4>
                </div>
                <p className="text-sm text-slate-500">The future of legal technology, built for modern law firms and professionals.</p>
              </div>
              <div>
                <h5 className="font-bold text-slate-900 mb-4 uppercase tracking-widest text-xs">Platform</h5>
                <ul className="space-y-2 text-sm text-slate-500">
                  <li className="hover:text-emerald-600 cursor-pointer">Case Management</li>
                  <li className="hover:text-emerald-600 cursor-pointer">AI Research</li>
                  <li className="hover:text-emerald-600 cursor-pointer">Document Automation</li>
                </ul>
              </div>
              <div>
                <h5 className="font-bold text-slate-900 mb-4 uppercase tracking-widest text-xs">Company</h5>
                <ul className="space-y-2 text-sm text-slate-500">
                  <li className="hover:text-emerald-600 cursor-pointer">About Us</li>
                  <li className="hover:text-emerald-600 cursor-pointer">Contact</li>
                  <li className="hover:text-emerald-600 cursor-pointer">Privacy Policy</li>
                </ul>
              </div>
              <div>
                <h5 className="font-bold text-slate-900 mb-4 uppercase tracking-widest text-xs">Legal</h5>
                <ul className="space-y-2 text-sm text-slate-500">
                  <li className="hover:text-emerald-600 cursor-pointer">Terms of Service</li>
                  <li className="hover:text-emerald-600 cursor-pointer">Disclaimer</li>
                  <li className="hover:text-emerald-600 cursor-pointer">Cookie Policy</li>
                </ul>
              </div>
            </div>
          </footer>
        </div>
      );
    }

    return (
      <div className="min-h-screen bg-slate-50 flex items-center justify-center p-6 relative">
        <button 
          onClick={() => setShowLanding(true)}
          className="absolute top-6 left-6 p-3 bg-white text-slate-500 hover:text-emerald-600 hover:bg-emerald-50 rounded-xl shadow-sm border border-slate-200 transition-all flex items-center gap-2 font-medium"
        >
          <ArrowLeft size={20} />
          <span>Back to Home</span>
        </button>
        <motion.div 
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          className="w-full max-w-md bg-white rounded-3xl shadow-xl border border-slate-100 p-8"
        >
          <div className="flex flex-col items-center mb-8">
            <div className="bg-emerald-600 p-3 rounded-2xl text-white mb-4 shadow-lg shadow-emerald-200">
              <Scale size={32} />
            </div>
            <h1 className="text-2xl font-bold text-slate-900">Tandon Associates</h1>
            <p className="text-slate-500 text-sm">{isSignup ? 'Create your account' : 'Legal Operations Platform'}</p>
          </div>

          <form onSubmit={handleLogin} className="space-y-6">
            {isSignup && (
              <div className="space-y-4">
                <div>
                  <label className="block text-sm font-bold text-slate-700 mb-2">Full Name</label>
                  <div className="relative">
                    <Users className="absolute left-3 top-1/2 -translate-y-1/2 text-slate-400" size={18} />
                    <input 
                      type="text" 
                      className="w-full pl-10 pr-4 py-3 bg-slate-50 border border-slate-200 rounded-xl focus:ring-2 focus:ring-emerald-500 outline-none transition-all"
                      placeholder="John Doe"
                      required
                    />
                  </div>
                </div>
                {loginEmail.endsWith('@tandonassociates.com') || loginEmail.includes('firm') ? (
                  <div>
                    <label className="block text-sm font-bold text-slate-700 mb-2">Firm Name</label>
                    <div className="relative">
                      <Building2 className="absolute left-3 top-1/2 -translate-y-1/2 text-slate-400" size={18} />
                      <input 
                        type="text" 
                        value={firmName}
                        onChange={(e) => setFirmName(e.target.value)}
                        className="w-full pl-10 pr-4 py-3 bg-slate-50 border border-slate-200 rounded-xl focus:ring-2 focus:ring-emerald-500 outline-none transition-all"
                        placeholder="Tandon Associates"
                        required
                      />
                    </div>
                  </div>
                ) : null}
              </div>
            )}
            <div>
              <label className="block text-sm font-bold text-slate-700 mb-2">Email Address</label>
              <div className="relative">
                <Mail className="absolute left-3 top-1/2 -translate-y-1/2 text-slate-400" size={18} />
                <input 
                  type="email" 
                  value={loginEmail}
                  onChange={(e) => setLoginEmail(e.target.value)}
                  className="w-full pl-10 pr-4 py-3 bg-slate-50 border border-slate-200 rounded-xl focus:ring-2 focus:ring-emerald-500 outline-none transition-all"
                  placeholder="demo@lawfirm.com"
                  required
                />
              </div>
            </div>

            <div>
              <label className="block text-sm font-bold text-slate-700 mb-2">Password</label>
              <div className="relative">
                <Lock className="absolute left-3 top-1/2 -translate-y-1/2 text-slate-400" size={18} />
                <input 
                  type="password" 
                  value={loginPassword}
                  onChange={(e) => setLoginPassword(e.target.value)}
                  className="w-full pl-10 pr-4 py-3 bg-slate-50 border border-slate-200 rounded-xl focus:ring-2 focus:ring-emerald-500 outline-none transition-all"
                  placeholder="••••••••"
                  required
                />
              </div>
            </div>

            {authError && (
              <p className="text-rose-500 text-xs font-medium bg-rose-50 p-3 rounded-lg border border-rose-100">
                {authError}
              </p>
            )}

            <button 
              type="submit"
              disabled={loading}
              className="w-full bg-emerald-600 text-white py-3 rounded-xl font-bold shadow-lg shadow-emerald-200 hover:bg-emerald-700 transition-all flex items-center justify-center gap-2"
            >
              {loading ? 'Authenticating...' : (isSignup ? 'Create Account' : 'Sign In')}
              {!loading && <ChevronRight size={18} />}
            </button>

            <div className="text-center">
              <button 
                type="button"
                onClick={() => setIsSignup(!isSignup)}
                className="text-sm font-bold text-emerald-600 hover:text-emerald-700"
              >
                {isSignup ? 'Already have an account? Sign In' : "Don't have an account? Sign Up"}
              </button>
            </div>

            <div className="relative my-8">
              <div className="absolute inset-0 flex items-center">
                <div className="w-full border-t border-slate-100"></div>
              </div>
              <div className="relative flex justify-center text-xs uppercase">
                <span className="bg-white px-2 text-slate-400 font-medium">Quick Access for Testing</span>
              </div>
            </div>

            <div className="grid grid-cols-2 gap-3">
              <button 
                type="button"
                onClick={() => { setLoginEmail('student@university.edu'); setLoginPassword('Demo@123'); }}
                className="p-3 border border-slate-100 rounded-xl text-xs font-bold text-slate-600 hover:bg-emerald-50 hover:text-emerald-600 hover:border-emerald-100 transition-all flex flex-col items-center gap-1"
              >
                <Bookmark size={16} />
                Law Student
              </button>
              <button 
                type="button"
                onClick={() => { setLoginEmail('partner@tandonassociates.com'); setLoginPassword('Demo@123'); }}
                className="p-3 border border-slate-100 rounded-xl text-xs font-bold text-slate-600 hover:bg-emerald-50 hover:text-emerald-600 hover:border-emerald-100 transition-all flex flex-col items-center gap-1"
              >
                <Scale size={16} />
                Senior Partner
              </button>
            </div>
          </form>

          <div className="mt-8 pt-6 border-t border-slate-100 text-center">
            <p className="text-xs text-slate-400 mb-2 uppercase tracking-widest font-bold">Demo Credentials (Role Testing)</p>
            <div className="bg-slate-50 p-3 rounded-xl text-xs text-slate-600 font-mono text-left space-y-1">
              <p><strong>Lawyer:</strong> lawyer@tandonassociates.com</p>
              <p><strong>Admin:</strong> admin@tandonassociates.com</p>
              <p><strong>Student:</strong> student@university.edu</p>
              <p className="mt-2 text-slate-400 italic">Password can be anything</p>
            </div>
          </div>
        </motion.div>
      </div>
    );
  }

  return (
    <div className="flex h-screen bg-slate-50 dark:bg-slate-950 font-sans text-slate-900 dark:text-slate-100 overflow-hidden relative">
      {/* Toast Container */}
      <div className="fixed bottom-6 right-6 z-[200] space-y-3">
        <AnimatePresence>
          {toasts.map(toast => (
            <motion.div
              key={toast.id}
              initial={{ opacity: 0, x: 50, scale: 0.9 }}
              animate={{ opacity: 1, x: 0, scale: 1 }}
              exit={{ opacity: 0, x: 20, scale: 0.9 }}
              className={`px-6 py-4 rounded-2xl shadow-2xl flex items-center gap-3 min-w-[300px] border ${
                toast.type === 'success' ? 'bg-emerald-600 text-white border-emerald-500' : 
                toast.type === 'error' ? 'bg-rose-600 text-white border-rose-500' : 
                'bg-slate-900 text-white border-slate-800'
              }`}
            >
              {toast.type === 'success' ? <CheckCircle2 size={20} /> : toast.type === 'error' ? <AlertCircle size={20} /> : <Info size={20} />}
              <span className="font-medium text-sm">{toast.message}</span>
              <button onClick={() => setToasts(prev => prev.filter(t => t.id !== toast.id))} className="ml-auto opacity-70 hover:opacity-100">
                <X size={16} />
              </button>
            </motion.div>
          ))}
        </AnimatePresence>
      </div>

      {/* Sidebar Overlay for Mobile */}
      <AnimatePresence>
        {isSidebarOpen && (
          <motion.div 
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            onClick={() => setIsSidebarOpen(false)}
            className="fixed inset-0 bg-slate-900/50 backdrop-blur-sm z-40 lg:hidden"
          />
        )}
      </AnimatePresence>

      {/* Sidebar */}
      <aside className={`
        fixed lg:static inset-y-0 left-0 w-64 bg-white dark:bg-slate-900 border-r border-slate-200 dark:border-slate-800 flex flex-col p-6 shrink-0 z-50 transition-transform duration-300 lg:translate-x-0
        ${isSidebarOpen ? 'translate-x-0' : '-translate-x-full'}
      `}>
        <div className="flex items-center justify-between mb-10 px-2">
          <div className="flex items-center gap-3">
            <div className="bg-emerald-600 p-2 rounded-lg text-white">
              <Scale size={24} />
            </div>
            <h1 className="text-xl font-bold tracking-tight text-slate-900 dark:text-slate-100">Tandon <span className="text-emerald-600">Legal</span></h1>
          </div>
          <button onClick={() => setIsSidebarOpen(false)} className="lg:hidden p-2 text-slate-400 hover:text-slate-600 dark:hover:text-slate-200">
            <X size={20} />
          </button>
        </div>

        <nav className="flex-1 space-y-1 overflow-y-auto">
          <SidebarItem icon={LayoutDashboard} label="Dashboard" active={activeTab === 'dashboard'} onClick={() => { setActiveTab('dashboard'); setIsSidebarOpen(false); }} />
          <SidebarItem icon={Gavel} label="Cases" active={activeTab === 'cases'} onClick={() => { setActiveTab('cases'); setIsSidebarOpen(false); }} />
          <SidebarItem icon={Clock} label="Calendar" active={activeTab === 'calendar'} onClick={() => { setActiveTab('calendar'); setIsSidebarOpen(false); }} />
          <SidebarItem icon={Users} label="Clients" active={activeTab === 'clients'} onClick={() => { setActiveTab('clients'); setIsSidebarOpen(false); }} />
          <SidebarItem icon={Search} label="eCourts Tracker" active={activeTab === 'ecourts'} onClick={() => { setActiveTab('ecourts'); setIsSidebarOpen(false); }} />
          <SidebarItem icon={FileSearch} label="Legal Research" active={activeTab === 'research'} onClick={() => { setActiveTab('research'); setIsSidebarOpen(false); }} />
          <SidebarItem icon={ClipboardList} label="Drafting" active={activeTab === 'drafting'} onClick={() => { setActiveTab('drafting'); setIsSidebarOpen(false); }} />
          <SidebarItem icon={FileText} label="Contracts" active={activeTab === 'contracts'} onClick={() => { setActiveTab('contracts'); setIsSidebarOpen(false); }} />
          <SidebarItem icon={BookOpen} label="Documents" active={activeTab === 'documents'} onClick={() => { setActiveTab('documents'); setIsSidebarOpen(false); }} />
          
          <div className="pt-4 pb-2 px-4">
            <p className="text-[10px] font-bold text-slate-400 uppercase tracking-widest">Specialized Portals</p>
          </div>
          <SidebarItem icon={Briefcase} label="For Lawyers" active={activeTab === 'for-lawyers'} onClick={() => { setActiveTab('for-lawyers'); setIsSidebarOpen(false); }} />
          <SidebarItem icon={ShieldCheck} label="For Corporates" active={activeTab === 'for-corporates'} onClick={() => { setActiveTab('for-corporates'); setIsSidebarOpen(false); }} />
          <SidebarItem icon={Activity} label="LOTS 24/7" active={activeTab === 'lots-247'} onClick={() => { setActiveTab('lots-247'); setIsSidebarOpen(false); }} />
          <SidebarItem icon={CreditCard} label="Challan Pay" active={activeTab === 'challan-pay'} onClick={() => { setActiveTab('challan-pay'); setIsSidebarOpen(false); }} />
          
          {/* Phase 1: Role-Based Visibility */}
          {(user?.role === 'firm_admin' || user?.role === 'lawyer') && (
            <>
              <SidebarItem icon={Users} label="Team" active={activeTab === 'team'} onClick={() => { setActiveTab('team'); setIsSidebarOpen(false); }} />
              <SidebarItem icon={ShieldCheck} label="Conflict Checker" active={activeTab === 'conflict-checker'} onClick={() => { setActiveTab('conflict-checker'); setIsSidebarOpen(false); }} />
              <SidebarItem icon={BrainCircuit} label="Watchdog" active={activeTab === 'watchdog'} onClick={() => { setActiveTab('watchdog'); setIsSidebarOpen(false); }} />
            </>
          )}

          {user?.role === 'firm_admin' && (
            <SidebarItem icon={BarChart3} label="Analytics" active={activeTab === 'analytics'} onClick={() => { setActiveTab('analytics'); setIsSidebarOpen(false); }} />
          )}

          <SidebarItem icon={Cpu} label="AI Tools" active={activeTab === 'ai'} onClick={() => { setActiveTab('ai'); setIsSidebarOpen(false); }} />
          <SidebarItem icon={Zap} label="Innovation Hub" active={activeTab === 'innovation'} onClick={() => { setActiveTab('innovation'); setIsSidebarOpen(false); }} />
          
          {user?.userType === 'corporate' && (
            <SidebarItem icon={ShieldCheck} label="Compliance & Audit" active={activeTab === 'compliance-audit'} onClick={() => { setActiveTab('compliance-audit'); setIsSidebarOpen(false); }} />
          )}

          <SidebarItem icon={MessageSquare} label="AI Research Chat" active={activeTab === 'ai-chat'} onClick={() => { setActiveTab('ai-chat'); setAiMode('chat'); setIsSidebarOpen(false); }} />
          
          {user?.userType === 'student' && (
            <SidebarItem icon={Bookmark} label="Student Hub" active={activeTab === 'student-hub'} onClick={() => { setActiveTab('student-hub'); setIsSidebarOpen(false); }} />
          )}

          <SidebarItem icon={Settings} label="Settings" active={activeTab === 'settings'} onClick={() => { setActiveTab('settings'); setIsSidebarOpen(false); }} />
          
          {user?.userType === 'corporate' && (
            <SidebarItem icon={Briefcase} label="Client Portal" active={activeTab === 'client-portal'} onClick={() => { setActiveTab('client-portal'); setIsSidebarOpen(false); }} />
          )}
        </nav>

        <div className="pt-6 border-t border-slate-100 dark:border-slate-800 space-y-1">
          <SidebarItem icon={HelpCircle} label="Support" />
          <button 
            onClick={() => setIsAuth(false)}
            className="w-full flex items-center gap-3 px-4 py-3 rounded-xl text-rose-500 hover:bg-rose-50 dark:hover:bg-rose-900/20 transition-all"
          >
            <LogOut size={20} />
            <span className="font-medium">Logout</span>
          </button>
        </div>
      </aside>

      {/* Main Content */}
      <main className="flex-1 flex flex-col min-w-0">
        {/* Header */}
        <header className="bg-white dark:bg-slate-900 border-b border-slate-200 dark:border-slate-800 px-4 sm:px-8 py-4 flex justify-between items-center z-20 sticky top-0">
          <div className="flex items-center gap-4 flex-1">
            <button 
              onClick={() => setIsSidebarOpen(true)}
              className="lg:hidden p-2 text-slate-500 dark:text-slate-400 hover:bg-slate-100 dark:hover:bg-slate-800 rounded-lg transition-all"
            >
              <Menu size={24} />
            </button>
            <div className="relative w-full max-w-md hidden xs:block group">
              <Search className="absolute left-3 top-1/2 -translate-y-1/2 text-slate-400 group-focus-within:text-emerald-500 transition-colors" size={18} />
              <input 
                type="text" 
                placeholder="Global Search (Cases, Docs, Team)..." 
                value={globalSearch}
                onChange={(e) => setGlobalSearch(e.target.value)}
                className="w-full pl-10 pr-4 py-2 bg-slate-100 dark:bg-slate-800 border-none rounded-xl focus:ring-2 focus:ring-emerald-500 transition-all outline-none text-sm dark:text-slate-100"
              />
              {globalSearch && (
                <div className="absolute top-full left-0 right-0 mt-2 bg-white dark:bg-slate-900 rounded-2xl shadow-2xl border border-slate-100 dark:border-slate-800 overflow-hidden z-50 max-h-96 overflow-y-auto">
                  <div className="p-3 border-b border-slate-50 dark:border-slate-800 bg-slate-50/50 dark:bg-slate-800/50">
                    <p className="text-[10px] font-bold text-slate-400 uppercase tracking-widest">Search Results</p>
                  </div>
                  <div className="divide-y divide-slate-50 dark:divide-slate-800">
                    {cases.filter(c => c.name.toLowerCase().includes(globalSearch.toLowerCase())).map(c => (
                      <div key={c.id} onClick={() => { setActiveTab('cases'); setGlobalSearch(''); }} className="p-4 hover:bg-slate-50 dark:hover:bg-slate-800 cursor-pointer flex items-center gap-3">
                        <div className="p-2 bg-emerald-100 dark:bg-emerald-900/30 text-emerald-600 rounded-lg"><Gavel size={16} /></div>
                        <div>
                          <p className="text-sm font-bold text-slate-900 dark:text-slate-100">{c.name}</p>
                          <p className="text-[10px] text-slate-500">Case • {c.type}</p>
                        </div>
                      </div>
                    ))}
                    {teamMembers.filter(t => t.name.toLowerCase().includes(globalSearch.toLowerCase())).map(t => (
                      <div key={t.id} onClick={() => { setActiveTab('team'); setGlobalSearch(''); }} className="p-4 hover:bg-slate-50 dark:hover:bg-slate-800 cursor-pointer flex items-center gap-3">
                        <div className="p-2 bg-blue-100 dark:bg-blue-900/30 text-blue-600 rounded-lg"><Users size={16} /></div>
                        <div>
                          <p className="text-sm font-bold text-slate-900 dark:text-slate-100">{t.name}</p>
                          <p className="text-[10px] text-slate-500">Team Member • {t.role}</p>
                        </div>
                      </div>
                    ))}
                    {recentDocuments.filter(d => d.name.toLowerCase().includes(globalSearch.toLowerCase())).map(d => (
                      <div key={d.name} onClick={() => { setActiveTab('documents'); setGlobalSearch(''); }} className="p-4 hover:bg-slate-50 dark:hover:bg-slate-800 cursor-pointer flex items-center gap-3">
                        <div className="p-2 bg-amber-100 dark:bg-amber-900/30 text-amber-600 rounded-lg"><FileText size={16} /></div>
                        <div>
                          <p className="text-sm font-bold text-slate-900 dark:text-slate-100">{d.name}</p>
                          <p className="text-[10px] text-slate-500">Document • {d.type}</p>
                        </div>
                      </div>
                    ))}
                    {globalSearch && ![...cases, ...teamMembers, ...recentDocuments].some(item => (item.name || '').toLowerCase().includes(globalSearch.toLowerCase())) && (
                      <div className="p-8 text-center text-slate-400 text-sm italic">No matches found.</div>
                    )}
                  </div>
                </div>
              )}
            </div>
          </div>

          <div className="flex items-center gap-2 sm:gap-4">
            <button 
              onClick={() => setIsDarkMode(!isDarkMode)}
              className="p-2.5 text-slate-500 dark:text-slate-400 hover:bg-slate-100 dark:hover:bg-slate-800 rounded-xl transition-all"
              title={isDarkMode ? "Switch to Light Mode" : "Switch to Dark Mode"}
            >
              {isDarkMode ? <Sun size={20} /> : <Moon size={20} />}
            </button>
            <div className="relative">
              <button 
                onClick={() => setShowNotifications(!showNotifications)}
                className={`p-2.5 rounded-xl relative transition-all ${showNotifications ? 'bg-emerald-50 dark:bg-emerald-900/30 text-emerald-600' : 'text-slate-500 dark:text-slate-400 hover:bg-slate-100 dark:hover:bg-slate-800'}`}
              >
                <Bell size={20} />
                {notifications.some(n => !n.isRead) && (
                  <span className="absolute top-2.5 right-2.5 w-2 h-2 bg-rose-500 rounded-full border-2 border-white dark:border-slate-900"></span>
                )}
              </button>

              <AnimatePresence>
                {showNotifications && (
                  <motion.div 
                    initial={{ opacity: 0, y: 10, scale: 0.95 }}
                    animate={{ opacity: 1, y: 0, scale: 1 }}
                    exit={{ opacity: 0, y: 10, scale: 0.95 }}
                    className="absolute right-0 mt-3 w-80 bg-white dark:bg-slate-900 rounded-2xl shadow-2xl border border-slate-100 dark:border-slate-800 overflow-hidden z-50"
                  >
                    <div className="p-4 border-b border-slate-100 dark:border-slate-800 flex justify-between items-center bg-slate-50/50 dark:bg-slate-800/50">
                      <h3 className="font-bold text-slate-900 dark:text-slate-100">Notifications</h3>
                      <button 
                        onClick={markAllAsRead}
                        className="text-xs font-bold text-emerald-600 hover:text-emerald-700"
                      >
                        Mark all as read
                      </button>
                    </div>
                    <div className="max-h-96 overflow-y-auto">
                      {notifications.length > 0 ? (
                        notifications.map(notification => (
                          <div 
                            key={notification.id}
                            onClick={() => markAsRead(notification.id)}
                            className={`p-4 border-b border-slate-50 dark:border-slate-800 cursor-pointer hover:bg-slate-50 dark:hover:bg-slate-800 transition-colors ${!notification.isRead ? 'bg-emerald-50/30 dark:bg-emerald-900/10' : ''}`}
                          >
                            <div className="flex justify-between items-start mb-1">
                              <h4 className={`text-sm font-bold ${!notification.isRead ? 'text-slate-900 dark:text-slate-100' : 'text-slate-600 dark:text-slate-400'}`}>
                                {notification.title}
                              </h4>
                              <span className="text-[10px] text-slate-400 font-medium">{notification.time}</span>
                            </div>
                            <p className="text-xs text-slate-500 dark:text-slate-400 leading-relaxed line-clamp-2">
                              {notification.message}
                            </p>
                          </div>
                        ))
                      ) : (
                        <div className="p-8 text-center text-slate-400 text-sm italic">No new notifications.</div>
                      )}
                    </div>
                  </motion.div>
                )}
              </AnimatePresence>
            </div>
            
            <div className="h-8 w-[1px] bg-slate-200 dark:bg-slate-800 hidden xs:block"></div>
            
            <div className="flex items-center gap-3 pl-2">
              <div className="text-right hidden sm:block">
                <p className="text-sm font-bold text-slate-900 dark:text-slate-100 truncate max-w-[120px]">{user?.name}</p>
                <p className="text-[10px] font-bold text-emerald-600 uppercase tracking-widest">{user?.userType}</p>
              </div>
              <div className="w-10 h-10 bg-emerald-600 rounded-xl flex items-center justify-center text-white font-bold shadow-lg shadow-emerald-200 dark:shadow-none">
                {user?.name?.charAt(0)}
              </div>
            </div>
          </div>
        </header>
        {/* Dynamic View */}
        <div className="flex-1 overflow-y-auto p-4 sm:p-8">
          <AnimatePresence mode="wait">
            {activeTab === 'dashboard' && (
              <motion.div 
                key="dashboard"
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                exit={{ opacity: 0, y: -20 }}
                className="space-y-8"
              >
                <div className="flex justify-between items-end">
                  <div>
                    <h2 className="text-3xl font-bold text-slate-900 dark:text-slate-100">Welcome back, {user?.name.split(' ')[0]}</h2>
                    <p className="text-slate-500 dark:text-slate-400 mt-1">Here's a summary of your legal operations.</p>
                  </div>
                  {user?.userType === 'student' && (
                    <div className="flex-1 max-w-md bg-gradient-to-r from-emerald-600 to-teal-600 p-6 rounded-2xl text-white shadow-lg shadow-emerald-200 flex items-center justify-between gap-6">
                      <div className="flex items-center gap-4">
                        <div className="p-3 bg-white/20 rounded-xl">
                          {user?.isStudentVerified ? <CheckCircle2 size={24} /> : <Bookmark size={24} />}
                        </div>
                        <div>
                          <p className="font-bold text-lg">{user?.isStudentVerified ? 'Verified Student' : 'Law Student?'}</p>
                          <p className="text-emerald-50 text-sm">
                            {user?.isStudentVerified 
                              ? 'You have full access to student resources.' 
                              : 'Verify to unlock free student resources.'}
                          </p>
                        </div>
                      </div>
                      {!user?.isStudentVerified && (
                        <button 
                          onClick={() => setIsVerifyingStudent(true)}
                          className="bg-white text-emerald-600 px-5 py-2.5 rounded-xl font-bold hover:bg-emerald-50 transition-all shadow-sm active:scale-95"
                        >
                          Verify Now
                        </button>
                      )}
                      {user?.isStudentVerified && (
                        <div className="bg-white/20 px-4 py-2 rounded-lg text-xs font-bold uppercase tracking-wider">
                          Status: Active
                        </div>
                      )}
                    </div>
                  )}
                  <button 
                    onClick={() => {
                      const name = prompt('Enter Case Name:');
                      const type = prompt('Enter Case Type:');
                      if (name && type) {
                        setCases([...cases, { id: Date.now().toString(), name, type, status: 'Active', nextHearing: 'TBD', timestamp: new Date().getTime() }]);
                        setActiveTab('cases');
                      }
                    }}
                    className="bg-emerald-600 text-white px-6 py-3 rounded-xl font-bold shadow-xl shadow-emerald-500/20 hover:bg-emerald-700 transition-all flex items-center gap-2 active:scale-95"
                  >
                    <Plus size={20} strokeWidth={3} />
                    New Case
                  </button>
                </div>

                <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
                  <div onClick={() => setActiveTab('cases')} className="cursor-pointer transition-transform hover:scale-[1.02] active:scale-[0.98]">
                    <StatCard label="Active Cases" value={cases.length.toString()} trend={12} icon={Gavel} />
                  </div>
                  <div onClick={() => setActiveTab('contracts')} className="cursor-pointer transition-transform hover:scale-[1.02] active:scale-[0.98]">
                    <StatCard label="Contracts" value={contracts.length.toString()} trend={5} icon={FileCheck} />
                  </div>
                  <div onClick={() => setActiveTab('documents')} className="cursor-pointer transition-transform hover:scale-[1.02] active:scale-[0.98]">
                    <StatCard label="Documents" value={filteredDocuments.length.toString()} trend={23} icon={BookOpen} />
                  </div>
                  <div onClick={() => setActiveTab('team')} className="cursor-pointer transition-transform hover:scale-[1.02] active:scale-[0.98]">
                    <StatCard label="Team Members" value={teamMembers.length.toString()} icon={Users} />
                  </div>
                </div>

                <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
                  {/* Recent Activity */}
                  <div className="lg:col-span-2 bg-white dark:bg-slate-900 rounded-2xl border border-slate-100 dark:border-slate-800 shadow-sm overflow-hidden">
                    <div className="p-6 border-b border-slate-50 dark:border-slate-800 flex justify-between items-center">
                      <h3 className="font-bold text-lg text-slate-900 dark:text-slate-100">Recent Activity</h3>
                      <button className="text-emerald-600 text-sm font-bold hover:underline">View All</button>
                    </div>
                    <div className="divide-y divide-slate-50 dark:divide-slate-800">
                      {[
                        ...cases.slice(-3).reverse().map(c => ({ title: c.name, type: 'Case', status: c.status, updated: 'Recently' })),
                        ...contracts.slice(-2).reverse().map(c => ({ title: c.name, type: 'Contract', status: c.status, updated: 'Recently' })),
                      ].slice(0, 5).map((item, idx) => (
                        <div 
                          key={idx} 
                          onClick={() => setActiveTab(item.type === 'Case' ? 'cases' : 'contracts')}
                          className="p-6 flex items-center justify-between hover:bg-slate-50 dark:hover:bg-slate-800 transition-all cursor-pointer group"
                        >
                          <div className="flex items-center gap-4">
                            <div className="h-12 w-12 bg-slate-100 dark:bg-slate-800 rounded-xl flex items-center justify-center text-slate-400 group-hover:bg-emerald-100 dark:group-hover:bg-emerald-900/30 group-hover:text-emerald-600 transition-all">
                              <Activity size={24} />
                            </div>
                            <div>
                              <p className="font-bold text-slate-900 dark:text-slate-100">{item.title}</p>
                              <p className="text-xs text-slate-500 dark:text-slate-400">{item.type}</p>
                            </div>
                          </div>
                          <div className="text-right">
                            <p className="text-sm font-medium text-emerald-600">{item.status}</p>
                            <p className="text-xs text-slate-400">{item.updated}</p>
                          </div>
                        </div>
                      ))}
                    </div>
                  </div>

                  {/* AI Insights */}
                  <div className="bg-slate-900 rounded-2xl p-6 text-white shadow-xl relative overflow-hidden flex flex-col">
                    <div className="relative z-10 flex-1">
                      <div className="flex items-center gap-2 text-emerald-400 mb-4">
                        <Cpu size={20} />
                        <span className="text-xs font-bold uppercase tracking-widest">AI Legal Assistant</span>
                      </div>
                      <h3 className="text-xl font-bold mb-4">Performance Insights</h3>
                      <div className="space-y-4">
                        <div className="bg-white/5 p-4 rounded-xl border border-white/10">
                          <p className="text-xs text-slate-400 mb-1">Success Rate</p>
                          <p className="text-xl font-bold text-emerald-400">89%</p>
                        </div>
                        <div className="bg-white/5 p-4 rounded-xl border border-white/10">
                          <p className="text-xs text-slate-400 mb-1">Avg Resolution Time</p>
                          <p className="text-xl font-bold text-emerald-400">45 Days</p>
                        </div>
                      </div>
                    </div>
                    <button className="relative z-10 mt-6 w-full bg-emerald-600 hover:bg-emerald-700 py-3 rounded-xl text-sm font-bold transition-all shadow-lg shadow-emerald-900/20">
                      View Full Analysis
                    </button>
                    <div className="absolute -bottom-10 -right-10 w-40 h-40 bg-emerald-600/20 rounded-full blur-3xl"></div>
                  </div>
                </div>
              </motion.div>
            )}

            {activeTab === 'ecourts' && (
              <motion.div 
                key="ecourts"
                initial={{ opacity: 0, scale: 0.95 }}
                animate={{ opacity: 1, scale: 1 }}
                className="max-w-4xl mx-auto space-y-6"
              >
                <div className="text-center mb-10">
                  <h2 className="text-3xl font-bold mb-2 text-slate-900 dark:text-slate-100">eCourts CNR Tracking</h2>
                  <p className="text-slate-500 dark:text-slate-400">Track the real-time status of any case across Indian courts using its 16-digit CNR number.</p>
                </div>

                <div className="bg-white dark:bg-slate-900 rounded-2xl shadow-xl border border-slate-100 dark:border-slate-800 overflow-hidden p-8">
                  <form onSubmit={handleCnrSearch} className="flex gap-4 mb-8">
                    <div className="relative flex-1">
                      <Search className="absolute left-4 top-1/2 -translate-y-1/2 text-slate-400" size={20} />
                      <input 
                        type="text" 
                        value={cnrInput}
                        onChange={(e) => setCnrInput(e.target.value.toUpperCase())}
                        placeholder="Enter 16-digit CNR Number (e.g., MHOS010023422024)"
                        className="w-full pl-12 pr-4 py-4 bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-xl focus:ring-2 focus:ring-emerald-500 outline-none transition-all font-mono text-lg dark:text-slate-100"
                        maxLength={16}
                      />
                    </div>
                    <button 
                      type="submit"
                      disabled={isCnrLoading || !cnrInput}
                      className="bg-emerald-600 text-white px-8 py-4 rounded-xl font-bold shadow-lg shadow-emerald-200 dark:shadow-none hover:bg-emerald-700 disabled:opacity-50 transition-all flex items-center gap-2 whitespace-nowrap"
                    >
                      {isCnrLoading ? 'Searching...' : 'Track Case'}
                      <ChevronRight size={20} />
                    </button>
                  </form>

                  {cnrError && (
                    <div className="bg-rose-50 text-rose-600 p-4 rounded-xl border border-rose-100 font-medium text-center">
                      {cnrError}
                    </div>
                  )}

                  {isCnrLoading && (
                    <div className="flex flex-col items-center justify-center py-12 text-slate-400 gap-4">
                      <motion.div animate={{ rotate: 360 }} transition={{ repeat: Infinity, duration: 1, ease: "linear" }}>
                        <Scale size={48} />
                      </motion.div>
                      <p className="animate-pulse font-medium">Connecting to eCourts servers...</p>
                    </div>
                  )}

                  {cnrResult && !isCnrLoading && (
                    <motion.div 
                      initial={{ opacity: 0, y: 10 }}
                      animate={{ opacity: 1, y: 0 }}
                      className="bg-slate-50 rounded-xl border border-slate-200 p-6"
                    >
                      <div className="flex items-center gap-3 mb-6 pb-6 border-b border-slate-200">
                        <div className="bg-emerald-100 p-3 rounded-xl text-emerald-600">
                          <ShieldCheck size={24} />
                        </div>
                        <div>
                          <p className="text-sm text-slate-500 font-bold uppercase tracking-wider">Verified Case Record</p>
                          <p className="text-xl font-bold text-slate-900">{cnrResult.title}</p>
                        </div>
                      </div>

                      <div className="grid grid-cols-2 gap-6">
                        <div>
                          <p className="text-sm text-slate-500 mb-1">CNR Number</p>
                          <div className="flex items-center gap-2">
                            <p className="font-mono font-bold text-slate-900">{cnrResult.cnr}</p>
                            <button 
                              onClick={() => navigator.clipboard.writeText(cnrResult.cnr)}
                              className="text-slate-400 hover:text-emerald-600 transition-colors"
                              title="Copy CNR"
                            >
                              <Copy size={16} />
                            </button>
                          </div>
                        </div>
                        <div>
                          <p className="text-sm text-slate-500 mb-1">Court</p>
                          <p className="font-bold text-slate-900">{cnrResult.court}</p>
                        </div>
                        <div>
                          <p className="text-sm text-slate-500 mb-1">Current Status</p>
                          <span className="inline-block px-3 py-1 bg-amber-100 text-amber-700 rounded-full text-sm font-bold">
                            {cnrResult.status}
                          </span>
                        </div>
                        <div>
                          <p className="text-sm text-slate-500 mb-1">Next Hearing Date</p>
                          <p className="font-bold text-slate-900">{cnrResult.next_hearing}</p>
                        </div>
                        <div className="col-span-2">
                          <p className="text-sm text-slate-500 mb-1">Bench</p>
                          <p className="font-bold text-slate-900">{cnrResult.bench}</p>
                        </div>
                        <div className="col-span-2 flex justify-end mt-4">
                          <button 
                            onClick={() => handleSaveCnr(cnrResult.cnr)}
                            disabled={savedCnrs.includes(cnrResult.cnr)}
                            className="text-sm font-bold flex items-center gap-2 px-4 py-2 rounded-lg transition-colors bg-emerald-50 text-emerald-600 hover:bg-emerald-100 disabled:opacity-50 disabled:cursor-not-allowed"
                          >
                            <Bookmark size={16} />
                            {savedCnrs.includes(cnrResult.cnr) ? 'Saved' : 'Save CNR'}
                          </button>
                        </div>
                      </div>
                    </motion.div>
                  )}

                  {!cnrResult && !isCnrLoading && !cnrError && (
                    <div className="flex flex-col items-center justify-center py-12 text-slate-300 gap-4">
                      <Search size={64} />
                      <p>Enter a CNR number above to view case details.</p>
                    </div>
                  )}
                  
                  {savedCnrs.length > 0 && (
                    <div className="mt-8 pt-8 border-t border-slate-100">
                      <h3 className="text-sm font-bold text-slate-500 uppercase tracking-wider mb-4 flex items-center gap-2">
                        <Bookmark size={16} /> Saved CNR Numbers
                      </h3>
                      <div className="flex flex-wrap gap-3">
                        {savedCnrs.map(cnr => (
                          <div key={cnr} className="flex items-center bg-slate-50 border border-slate-200 rounded-lg overflow-hidden group">
                            <button 
                              onClick={() => handleCnrSearch(cnr)}
                              className="px-4 py-2 font-mono text-sm text-slate-700 hover:bg-slate-100 transition-colors"
                            >
                              {cnr}
                            </button>
                            <button 
                              onClick={() => handleRemoveSavedCnr(cnr)}
                              className="px-3 py-2 text-slate-400 hover:text-rose-600 hover:bg-rose-50 transition-colors border-l border-slate-200"
                              title="Remove saved CNR"
                            >
                              <X size={14} />
                            </button>
                          </div>
                        ))}
                      </div>
                    </div>
                  )}
                </div>
              </motion.div>
            )}

            {activeTab === 'calendar' && (
              <motion.div 
                key="calendar"
                initial={{ opacity: 0, scale: 0.95 }}
                animate={{ opacity: 1, scale: 1 }}
                className="max-w-6xl mx-auto space-y-6"
              >
                <div className="flex justify-between items-end mb-6">
                  <div>
                    <h2 className="text-3xl font-bold text-slate-900 dark:text-slate-100">Hearing Calendar</h2>
                    <p className="text-slate-500 dark:text-slate-400">Track all upcoming court dates and deadlines in a single view.</p>
                  </div>
                  <div className="flex gap-2">
                    <button className="px-4 py-2 bg-white dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-xl text-sm font-bold text-slate-600 dark:text-slate-300 hover:bg-slate-50 dark:hover:bg-slate-700 transition-all">
                      Sync with Google
                    </button>
                    <button className="px-4 py-2 bg-emerald-600 text-white rounded-xl text-sm font-bold hover:bg-emerald-700 transition-all shadow-lg shadow-emerald-500/20">
                      Add Event
                    </button>
                  </div>
                </div>
                
                <HearingCalendar cases={cases} onCaseClick={(id) => { setActiveTab('cases'); /* scroll to case logic if needed */ }} />
                
                <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
                  <div className="md:col-span-2 bg-white dark:bg-slate-900 rounded-3xl border border-slate-100 dark:border-slate-800 p-6">
                    <h3 className="text-lg font-bold text-slate-900 dark:text-slate-100 mb-4 flex items-center gap-2">
                      <Clock size={20} className="text-emerald-600" />
                      Upcoming This Week
                    </h3>
                    <div className="space-y-4">
                      {cases.slice(0, 3).map(c => (
                        <div key={c.id} className="flex items-center justify-between p-4 bg-slate-50 dark:bg-slate-800/50 rounded-2xl border border-slate-100 dark:border-slate-800">
                          <div className="flex items-center gap-4">
                            <div className="w-12 h-12 bg-emerald-100 dark:bg-emerald-900/30 text-emerald-600 rounded-xl flex flex-col items-center justify-center">
                              <span className="text-[10px] font-bold uppercase tracking-tighter">Mar</span>
                              <span className="text-lg font-bold leading-none">12</span>
                            </div>
                            <div>
                              <p className="font-bold text-slate-900 dark:text-slate-100">{c.name}</p>
                              <p className="text-xs text-slate-500 dark:text-slate-400">{c.court}</p>
                            </div>
                          </div>
                          <div className="text-right">
                            <p className="text-xs font-bold text-emerald-600">10:30 AM</p>
                            <p className="text-[10px] text-slate-400">Court Room 4</p>
                          </div>
                        </div>
                      ))}
                    </div>
                  </div>
                  <div className="bg-slate-900 rounded-3xl p-6 text-white relative overflow-hidden">
                    <div className="relative z-10">
                      <h3 className="text-lg font-bold mb-4">Calendar Insights</h3>
                      <div className="space-y-6">
                        <div>
                          <p className="text-xs text-slate-400 mb-1">Total Hearings (Mar)</p>
                          <p className="text-3xl font-bold text-emerald-400">14</p>
                        </div>
                        <div>
                          <p className="text-xs text-slate-400 mb-1">Most Busy Day</p>
                          <p className="text-xl font-bold">Wednesday, Mar 18</p>
                        </div>
                        <div className="pt-4 border-t border-white/10">
                          <p className="text-xs text-slate-400 mb-2">Conflicts Detected</p>
                          <div className="flex items-center gap-2 text-rose-400">
                            <AlertTriangle size={16} />
                            <span className="text-sm font-bold">2 Overlapping Hearings</span>
                          </div>
                        </div>
                      </div>
                    </div>
                    <div className="absolute -bottom-10 -right-10 w-40 h-40 bg-emerald-600/20 rounded-full blur-3xl"></div>
                  </div>
                </div>
              </motion.div>
            )}

            {activeTab === 'cases' && (
              <motion.div 
                key="cases"
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                className="space-y-6"
              >
                <div className="flex justify-between items-center">
                  <h2 className="text-3xl font-bold text-slate-900 dark:text-slate-100">Case Management</h2>
                  <button 
                    onClick={() => {
                      const name = prompt('Enter Case Name:');
                      const type = prompt('Enter Case Type:');
                      if (name && type) {
                        setCases([...cases, { id: Date.now().toString(), name, type, status: 'Active', nextHearing: 'TBD', timestamp: new Date().getTime() }]);
                      }
                    }}
                    className="bg-emerald-600 text-white px-6 py-2 rounded-xl font-bold flex items-center gap-2 shadow-lg shadow-emerald-200 dark:shadow-none hover:bg-emerald-700 transition-all"
                  >
                    <Plus size={18} /> Add New Case
                  </button>
                </div>

                <div className="flex flex-col sm:flex-row gap-4 items-start sm:items-center justify-between bg-white dark:bg-slate-900 p-4 rounded-2xl border border-slate-100 dark:border-slate-800 shadow-sm">
                  <div className="relative flex-1 w-full sm:max-w-md">
                    <Search className="absolute left-3 top-1/2 -translate-y-1/2 text-slate-400" size={18} />
                    <input 
                      type="text" 
                      placeholder="Search cases by name or type..." 
                      value={caseSearchQuery}
                      onChange={(e) => setCaseSearchQuery(e.target.value)}
                      className="w-full pl-10 pr-4 py-2 bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-xl focus:ring-2 focus:ring-emerald-500 outline-none text-sm dark:text-slate-100"
                    />
                  </div>
                  <div className="flex gap-3 w-full sm:w-auto">
                    <select 
                      value={caseStatusFilter}
                      onChange={(e) => setCaseStatusFilter(e.target.value)}
                      className="flex-1 sm:flex-none p-2 bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-xl focus:ring-2 focus:ring-emerald-500 outline-none text-sm dark:text-slate-100"
                    >
                      <option value="All">All Statuses</option>
                      <option value="Active">Active</option>
                      <option value="Pending">Pending</option>
                      <option value="Completed">Completed</option>
                    </select>
                    <select 
                      value={caseDateFilter}
                      onChange={(e) => setCaseDateFilter(e.target.value)}
                      className="flex-1 sm:flex-none p-2 bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-xl focus:ring-2 focus:ring-emerald-500 outline-none text-sm dark:text-slate-100"
                    >
                      <option value="All">All Dates</option>
                      <option value="Upcoming (7 Days)">Upcoming (7 Days)</option>
                      <option value="Upcoming (30 Days)">Upcoming (30 Days)</option>
                      <option value="Past Cases">Past Cases</option>
                    </select>
                  </div>
                </div>

                <div className="bg-white dark:bg-slate-900 rounded-2xl border border-slate-100 dark:border-slate-800 shadow-sm overflow-hidden">
                  {filteredCases.length > 0 ? (
                    <div className="overflow-x-auto">
                      <div className="min-w-[600px]">
                        <div className="bg-slate-50 dark:bg-slate-800/50 p-4 grid grid-cols-4 gap-4 text-xs font-bold text-slate-500 dark:text-slate-400 uppercase tracking-wider">
                          <span>Case Name</span>
                          <span>Type</span>
                          <span>Status</span>
                          <span>Next Hearing</span>
                        </div>
                        <div className="divide-y divide-slate-50 dark:divide-slate-800">
                          {filteredCases.map(c => (
                            <TableRow key={c.id} cells={[c.name, c.type, c.status, c.nextHearing]} actions={<button className="text-emerald-600 font-bold text-sm hover:text-emerald-700">View</button>} />
                          ))}
                        </div>
                      </div>
                    </div>
                  ) : (
                    <EmptyState 
                      icon={Gavel}
                      title="No cases found"
                      description={caseSearchQuery ? `No cases match your search "${caseSearchQuery}"` : "You haven't added any cases yet. Start by creating your first case record."}
                      actionLabel="Add New Case"
                      onAction={() => {
                        const name = prompt('Enter Case Name:');
                        const type = prompt('Enter Case Type:');
                        if (name && type) {
                          setCases([...cases, { id: Date.now().toString(), name, type, status: 'Active', nextHearing: 'TBD', timestamp: new Date().getTime() }]);
                        }
                      }}
                    />
                  )}
                </div>
              </motion.div>
            )}

            {activeTab === 'contracts' && (
              <motion.div 
                key="contracts"
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                className="space-y-6"
              >
                <div className="flex justify-between items-center">
                  <h2 className="text-3xl font-bold text-slate-900 dark:text-slate-100">Contract Management</h2>
                  <button 
                    onClick={() => {
                      const name = prompt('Enter Contract Name:');
                      const client = prompt('Enter Client:');
                      if (name && client) {
                        setContracts([...contracts, { id: Date.now().toString(), name, client, expiryDate: 'TBD', status: 'Active' }]);
                      }
                    }}
                    className="bg-emerald-600 text-white px-6 py-2 rounded-xl font-bold flex items-center gap-2 shadow-lg shadow-emerald-200 dark:shadow-none hover:bg-emerald-700 transition-all"
                  >
                    <Plus size={18} /> New Contract
                  </button>
                </div>
                <div className="bg-white dark:bg-slate-900 rounded-2xl border border-slate-100 dark:border-slate-800 shadow-sm overflow-hidden">
                  {contracts.length > 0 ? (
                    <div className="overflow-x-auto">
                      <div className="min-w-[600px]">
                        <div className="bg-slate-50 dark:bg-slate-800/50 p-4 grid grid-cols-4 gap-4 text-xs font-bold text-slate-500 dark:text-slate-400 uppercase tracking-wider">
                          <span>Contract Name</span>
                          <span>Client</span>
                          <span>Expiry Date</span>
                          <span>Status</span>
                        </div>
                        <div className="divide-y divide-slate-50 dark:divide-slate-800">
                          {contracts.map(c => (
                            <TableRow key={c.id} cells={[c.name, c.client, c.expiryDate, c.status]} />
                          ))}
                        </div>
                      </div>
                    </div>
                  ) : (
                    <EmptyState 
                      icon={FileText}
                      title="No contracts found"
                      description="You haven't uploaded or generated any contracts yet."
                      actionLabel="New Contract"
                      onAction={() => {
                        const name = prompt('Enter Contract Name:');
                        const client = prompt('Enter Client:');
                        if (name && client) {
                          setContracts([...contracts, { id: Date.now().toString(), name, client, expiryDate: 'TBD', status: 'Active' }]);
                        }
                      }}
                    />
                  )}
                </div>
              </motion.div>
            )}

            {activeTab === 'documents' && (
              <motion.div 
                key="documents"
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                className="space-y-6"
              >
                <div className="flex justify-between items-center">
                  <h2 className="text-3xl font-bold text-slate-900 dark:text-slate-100">Document Repository</h2>
                  <button className="bg-emerald-600 text-white px-6 py-2 rounded-xl font-bold flex items-center gap-2 shadow-lg shadow-emerald-200 dark:shadow-none hover:bg-emerald-700 transition-all">
                    <Plus size={18} /> Upload Document
                  </button>
                </div>
                <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
                  <div className="bg-white dark:bg-slate-900 rounded-2xl border border-slate-100 dark:border-slate-800 shadow-sm overflow-hidden flex flex-col">
                    <div className="p-6 border-b border-slate-100 dark:border-slate-800 bg-slate-50 dark:bg-slate-800/50">
                      <h3 className="font-bold text-lg flex items-center gap-2 text-slate-900 dark:text-slate-100">
                        <FileText className="text-emerald-600" size={20} /> AI Document Generator
                      </h3>
                      <p className="text-sm text-slate-500 dark:text-slate-400 mt-1">Draft legal documents instantly using Gemini 3.1 Pro.</p>
                    </div>
                    <div className="p-6 space-y-4 flex-1">
                      <div>
                        <label className="block text-sm font-bold text-slate-700 dark:text-slate-300 mb-2">Select Template</label>
                        <select 
                          value={docTemplate}
                          onChange={(e) => setDocTemplate(e.target.value)}
                          className="w-full p-3 bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-xl focus:ring-2 focus:ring-emerald-500 outline-none dark:text-slate-100"
                        >
                          <option value="Non-Disclosure Agreement">Non-Disclosure Agreement (NDA)</option>
                          <option value="Vakalatnama">Vakalatnama</option>
                          <option value="Cease and Desist Letter">Cease and Desist Letter</option>
                          <option value="Employment Contract">Employment Contract</option>
                          <option value="Legal Notice">Legal Notice</option>
                          <option value="Plaint (Civil Suit)">Plaint (Civil Suit)</option>
                          <option value="Written Statement">Written Statement</option>
                          <option value="Bail Application">Bail Application</option>
                          <option value="Writ Petition">Writ Petition</option>
                        </select>
                      </div>
                      <div>
                        <label className="block text-sm font-bold text-slate-700 dark:text-slate-300 mb-2">Case Details & Requirements</label>
                        <textarea 
                          value={docDetails}
                          onChange={(e) => setDocDetails(e.target.value)}
                          placeholder="E.g., Client is John Doe, Respondent is Tech Corp. Include a 2-year confidentiality clause..."
                          className="w-full p-3 bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-xl focus:ring-2 focus:ring-emerald-500 outline-none min-h-[150px] resize-y dark:text-slate-100"
                        />
                      </div>
                      <button 
                        onClick={handleGenerateDocument}
                        disabled={isDocLoading || !docDetails}
                        className="w-full bg-emerald-600 text-white py-3 rounded-xl font-bold shadow-lg shadow-emerald-200 dark:shadow-none hover:bg-emerald-700 transition-all disabled:opacity-50 flex justify-center items-center gap-2"
                      >
                        {isDocLoading ? <Cpu className="animate-pulse" size={18} /> : <Zap size={18} />}
                        {isDocLoading ? 'Generating Draft...' : 'Generate Draft'}
                      </button>
                    </div>
                  </div>

                  <div className="bg-white dark:bg-slate-900 rounded-2xl border border-slate-100 dark:border-slate-800 shadow-sm overflow-hidden flex flex-col">
                    <div className="p-6 border-b border-slate-100 dark:border-slate-800 bg-slate-50 dark:bg-slate-800/50 flex justify-between items-center">
                      <h3 className="font-bold text-lg text-slate-900 dark:text-slate-100">Generated Draft</h3>
                      {docResult && (
                        <button 
                          onClick={() => navigator.clipboard.writeText(docResult)}
                          className="text-emerald-600 hover:bg-emerald-50 dark:hover:bg-emerald-900/20 p-2 rounded-lg transition-all"
                          title="Copy to Clipboard"
                        >
                          <Copy size={18} />
                        </button>
                      )}
                    </div>
                    <div className="p-6 flex-1 bg-slate-50/50 dark:bg-slate-800/20 overflow-y-auto min-h-[400px]">
                      {docResult ? (
                        <div className="whitespace-pre-wrap font-mono text-sm text-slate-700 dark:text-slate-300 leading-relaxed bg-white dark:bg-slate-800 p-6 rounded-xl border border-slate-200 dark:border-slate-700 shadow-sm">
                          {docResult}
                        </div>
                      ) : (
                        <div className="h-full flex flex-col items-center justify-center text-slate-400 gap-4">
                          <FileText size={48} className="opacity-20" />
                          <p>Your generated document will appear here.</p>
                        </div>
                      )}
                    </div>
                  </div>
                </div>

                <div className="bg-white dark:bg-slate-900 rounded-2xl border border-slate-100 dark:border-slate-800 shadow-sm overflow-hidden mt-8">
                  <div className="p-6 border-b border-slate-100 dark:border-slate-800 flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4">
                    <div className="flex items-center gap-4">
                      <h3 className="font-bold text-lg text-slate-900 dark:text-slate-100">Recent Documents</h3>
                      <label className="cursor-pointer bg-emerald-600 text-white px-4 py-2 rounded-xl text-sm font-bold hover:bg-emerald-700 transition-all flex items-center gap-2">
                        <Plus size={16} /> Upload
                        <input type="file" className="hidden" onChange={handleFileUpload} />
                      </label>
                    </div>
                    <div className="flex flex-col sm:flex-row gap-3 w-full sm:w-auto">
                      <div className="relative flex-1 sm:w-64">
                        <Search className="absolute left-3 top-1/2 -translate-y-1/2 text-slate-400" size={16} />
                        <input 
                          type="text" 
                          placeholder="Search documents..." 
                          value={docSearchQuery}
                          onChange={(e) => setDocSearchQuery(e.target.value)}
                          className="w-full pl-9 pr-4 py-2 bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-xl focus:ring-2 focus:ring-emerald-500 outline-none text-sm dark:text-slate-100"
                        />
                      </div>
                      <div className="flex gap-2 overflow-x-auto pb-2 sm:pb-0">
                        <select 
                          value={docTypeFilter}
                          onChange={(e) => setDocTypeFilter(e.target.value)}
                          className="p-2 bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-xl focus:ring-2 focus:ring-emerald-500 outline-none text-sm whitespace-nowrap dark:text-slate-100"
                        >
                          <option value="All">All Types</option>
                          <option value="PDF">PDF</option>
                          <option value="Word">Word</option>
                          <option value="Excel">Excel</option>
                        </select>
                        <select 
                          value={docClientFilter}
                          onChange={(e) => setDocClientFilter(e.target.value)}
                          className="p-2 bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-xl focus:ring-2 focus:ring-emerald-500 outline-none text-sm whitespace-nowrap dark:text-slate-100"
                        >
                          <option value="All">All Clients</option>
                          {Array.from(new Set(recentDocuments.map(d => d.client))).map(client => (
                            <option key={client} value={client}>{client}</option>
                          ))}
                        </select>
                        <select 
                          value={docDateFilter}
                          onChange={(e) => setDocDateFilter(e.target.value)}
                          className="p-2 bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-xl focus:ring-2 focus:ring-emerald-500 outline-none text-sm whitespace-nowrap dark:text-slate-100"
                        >
                          <option value="All Time">All Time</option>
                          <option value="Past 24 Hours">Past 24 Hours</option>
                          <option value="Past Week">Past Week</option>
                          <option value="Past Month">Past Month</option>
                        </select>
                      </div>
                    </div>
                  </div>
                  
                  {/* Desktop Table */}
                  <div className="hidden md:block overflow-x-auto">
                    <div className="min-w-[800px]">
                      <div className="bg-slate-50 dark:bg-slate-800/50 p-4 grid grid-cols-5 gap-4 text-xs font-bold text-slate-500 dark:text-slate-400 uppercase tracking-wider">
                        <span>Document Name</span>
                        <span>Client</span>
                        <span>Type</span>
                        <span>Uploaded</span>
                        <span>Size</span>
                      </div>
                      <div className="divide-y divide-slate-50 dark:divide-slate-800">
                        {filteredDocuments.length > 0 ? (
                          filteredDocuments.map((doc, idx) => (
                            <TableRow 
                              key={idx} 
                              cells={[doc.name, doc.client, doc.type, doc.date, doc.size]} 
                              gridClass="grid-cols-5" 
                              actions={
                                <button 
                                  onClick={() => {
                                    setSelectedDocForHistory({ id: (idx + 1).toString(), name: doc.name });
                                    setIsViewingDocHistory(true);
                                  }}
                                  className="p-2 text-slate-400 hover:text-emerald-600 hover:bg-emerald-50 dark:hover:bg-emerald-900/20 rounded-lg transition-all"
                                  title="View History"
                                >
                                  <History size={16} />
                                </button>
                              }
                            />
                          ))
                        ) : (
                          <div className="p-8 text-center text-slate-500 italic">No documents found.</div>
                        )}
                      </div>
                    </div>
                  </div>

                  {/* Mobile Card Layout */}
                  <div className="md:hidden divide-y divide-slate-50 dark:divide-slate-800">
                    {filteredDocuments.length > 0 ? (
                      filteredDocuments.map((doc, idx) => (
                        <div key={idx} className="p-4 space-y-3 hover:bg-slate-50 dark:hover:bg-slate-800 transition-colors">
                          <div className="flex justify-between items-start">
                            <h4 className="font-bold text-slate-900 dark:text-slate-100">{doc.name}</h4>
                            <span className="text-[10px] font-bold px-2 py-1 bg-emerald-100 dark:bg-emerald-900/30 text-emerald-600 rounded-lg">{doc.type}</span>
                          </div>
                          <div className="grid grid-cols-2 gap-2 text-xs">
                            <div>
                              <p className="text-slate-400 uppercase tracking-widest text-[10px] font-bold mb-1">Client</p>
                              <p className="text-slate-600 dark:text-slate-300">{doc.client}</p>
                            </div>
                            <div>
                              <p className="text-slate-400 uppercase tracking-widest text-[10px] font-bold mb-1">Uploaded</p>
                              <p className="text-slate-600 dark:text-slate-300">{doc.date}</p>
                            </div>
                          </div>
                          <div className="flex justify-between items-center pt-2">
                            <span className="text-xs text-slate-400">{doc.size}</span>
                            <button className="text-emerald-600 font-bold text-sm">Download</button>
                          </div>
                        </div>
                      ))
                    ) : (
                      <EmptyState 
                        icon={BookOpen}
                        title="No documents found"
                        description="Try adjusting your search or filters."
                      />
                    )}
                  </div>
                </div>
              </motion.div>
            )}

            {activeTab === 'innovation' && (
              <motion.div 
                key="innovation"
                initial={{ opacity: 0, scale: 0.95 }}
                animate={{ opacity: 1, scale: 1 }}
                className="max-w-6xl mx-auto space-y-6"
              >
                <div className="flex justify-between items-end mb-8">
                  <div>
                    <h2 className="text-4xl font-extrabold tracking-tight text-slate-900">Legal Innovation Hub</h2>
                    <p className="text-slate-500 mt-1">Experimental tools for students and legal professionals.</p>
                  </div>
                  <div className="flex bg-white p-1 rounded-xl border border-slate-200 shadow-sm">
                    {!hasApiKey && (
                      <button 
                        onClick={async () => {
                          if (window.aistudio) {
                            await window.aistudio.openSelectKey();
                            setHasApiKey(true);
                          }
                        }}
                        className="px-4 py-2 rounded-lg text-sm font-bold bg-amber-50 text-amber-700 hover:bg-amber-100 transition-all flex items-center gap-2 mr-2 border border-amber-200"
                      >
                        <Lock size={14} /> Setup API Key
                      </button>
                    )}
                    {user?.userType === 'student' && (
                      <button onClick={() => setInnovationMode('moot')} className={`px-4 py-2 rounded-lg text-sm font-bold transition-all ${innovationMode === 'moot' ? 'bg-emerald-600 text-white shadow-md' : 'text-slate-500 hover:bg-slate-50'}`}>Moot Court</button>
                    )}
                    {user?.userType === 'corporate' && (
                      <button onClick={() => setInnovationMode('policy')} className={`px-4 py-2 rounded-lg text-sm font-bold transition-all ${innovationMode === 'policy' ? 'bg-emerald-600 text-white shadow-md' : 'text-slate-500 hover:bg-slate-50'}`}>Policy Drafter</button>
                    )}
                    <button onClick={() => setInnovationMode('brief')} className={`px-4 py-2 rounded-lg text-sm font-bold transition-all ${innovationMode === 'brief' ? 'bg-emerald-600 text-white shadow-md' : 'text-slate-500 hover:bg-slate-50'}`}>Case Briefing</button>
                    <button onClick={() => setInnovationMode('statute')} className={`px-4 py-2 rounded-lg text-sm font-bold transition-all ${innovationMode === 'statute' ? 'bg-emerald-600 text-white shadow-md' : 'text-slate-500 hover:bg-slate-50'}`}>Statute Simplifier</button>
                    <button onClick={() => setInnovationMode('timeline')} className={`px-4 py-2 rounded-lg text-sm font-bold transition-all ${innovationMode === 'timeline' ? 'bg-emerald-600 text-white shadow-md' : 'text-slate-500 hover:bg-slate-50'}`}>Evidence Timeline</button>
                    <button onClick={() => setInnovationMode('exhibit')} className={`px-4 py-2 rounded-lg text-sm font-bold transition-all ${innovationMode === 'exhibit' ? 'bg-emerald-600 text-white shadow-md' : 'text-slate-500 hover:bg-slate-50'}`}>Evidence Exhibit</button>
                    <button onClick={() => setInnovationMode('evidence')} className={`px-4 py-2 rounded-lg text-sm font-bold transition-all ${innovationMode === 'evidence' ? 'bg-emerald-600 text-white shadow-md' : 'text-slate-500 hover:bg-slate-50'}`}>Evidence Analysis</button>
                    <button onClick={() => setInnovationMode('audio')} className={`px-4 py-2 rounded-lg text-sm font-bold transition-all ${innovationMode === 'audio' ? 'bg-emerald-600 text-white shadow-md' : 'text-slate-500 hover:bg-slate-50'}`}>Audio Transcribe</button>
                    <button onClick={() => setInnovationMode('computable-contract')} className={`px-4 py-2 rounded-lg text-sm font-bold transition-all ${innovationMode === 'computable-contract' ? 'bg-emerald-600 text-white shadow-md' : 'text-slate-500 hover:bg-slate-50'}`}>Computable Contracts</button>
                    <button onClick={() => setInnovationMode('algorithmic-triage')} className={`px-4 py-2 rounded-lg text-sm font-bold transition-all ${innovationMode === 'algorithmic-triage' ? 'bg-emerald-600 text-white shadow-md' : 'text-slate-500 hover:bg-slate-50'}`}>Algorithmic Triage</button>
                  </div>
                </div>

                {innovationMode === 'moot' && user?.userType === 'student' && (
                  <div className="grid grid-cols-1 lg:grid-cols-12 gap-6 h-auto lg:h-[600px]">
                    <div className="col-span-1 lg:col-span-4 bg-white p-6 rounded-3xl border border-slate-100 shadow-xl flex flex-col">
                      <h3 className="text-xl font-bold mb-4 flex items-center gap-2">
                        <Gavel className="text-emerald-600" /> Moot Court Setup
                      </h3>
                      <p className="text-sm text-slate-500 mb-6">Enter a case summary or legal problem to start a simulated hearing with an AI Judge.</p>
                      <textarea 
                        value={mootCase}
                        onChange={(e) => setMootCase(e.target.value)}
                        placeholder="e.g., A dispute over a commercial lease agreement where the tenant claims force majeure due to a pandemic..."
                        className="flex-1 p-4 bg-slate-50 border border-slate-200 rounded-2xl outline-none focus:ring-2 focus:ring-emerald-500 transition-all resize-none text-sm mb-4"
                      />
                      <button 
                        onClick={handleStartMoot}
                        disabled={isMootLoading || !mootCase}
                        className="w-full bg-emerald-600 text-white py-4 rounded-2xl font-bold shadow-lg shadow-emerald-200 hover:bg-emerald-700 disabled:opacity-50 transition-all flex items-center justify-center gap-2"
                      >
                        {isMootLoading ? <Activity className="animate-spin" /> : <Zap size={20} />}
                        <span>Start Hearing</span>
                      </button>
                    </div>
                    <div className="col-span-1 lg:col-span-8 bg-slate-900 rounded-3xl shadow-2xl overflow-hidden flex flex-col relative min-h-[400px]">
                      <div className="p-4 bg-slate-800 border-b border-slate-700 flex justify-between items-center">
                        <div className="flex items-center gap-2">
                          <div className="w-3 h-3 rounded-full bg-rose-500 animate-pulse" />
                          <span className="text-xs font-bold text-slate-300 uppercase tracking-widest">Live Courtroom Session</span>
                        </div>
                        <span className="text-xs text-slate-500 font-mono">JUDGE: HON. GEMINI AI</span>
                      </div>
                      <div className="flex-1 p-6 overflow-y-auto space-y-4 font-serif">
                        {!isMootActive ? (
                          <div className="h-full flex flex-col items-center justify-center text-slate-600 text-center space-y-4">
                            <Scale size={48} opacity={0.2} />
                            <p>Court is not in session. <br/>Please provide a case summary to begin.</p>
                          </div>
                        ) : (
                          mootChat.map((msg, i) => (
                            <motion.div 
                              key={i}
                              initial={{ opacity: 0, x: msg.role === 'judge' ? -20 : 20 }}
                              animate={{ opacity: 1, x: 0 }}
                              className={`flex ${msg.role === 'judge' ? 'justify-start' : 'justify-end'}`}
                            >
                              <div className={`max-w-[85%] p-4 rounded-2xl ${
                                msg.role === 'judge' 
                                  ? 'bg-slate-800 text-slate-100 border-l-4 border-emerald-500' 
                                  : 'bg-emerald-600 text-white'
                              }`}>
                                <p className="text-xs font-bold mb-1 opacity-50 uppercase tracking-wider">{msg.role}</p>
                                <p className="text-sm leading-relaxed">{msg.text}</p>
                              </div>
                            </motion.div>
                          ))
                        )}
                        {isMootLoading && (
                          <div className="flex justify-start">
                            <div className="bg-slate-800 p-4 rounded-2xl animate-pulse text-slate-500 text-xs">Judge is deliberating...</div>
                          </div>
                        )}
                      </div>
                      {isMootActive && (
                        <div className="p-4 bg-slate-800 border-t border-slate-700">
                          <div className="flex gap-2">
                            <input 
                              value={mootInput}
                              onChange={(e) => setMootInput(e.target.value)}
                              onKeyPress={(e) => e.key === 'Enter' && handleMootMessage()}
                              placeholder="Present your argument..."
                              className="flex-1 bg-slate-900 border border-slate-700 rounded-xl px-4 py-2 text-white outline-none focus:ring-2 focus:ring-emerald-500 transition-all"
                            />
                            <button 
                              onClick={handleMootMessage}
                              className="bg-emerald-600 text-white p-2 rounded-xl hover:bg-emerald-700 transition-all"
                            >
                              <ChevronRight size={20} />
                            </button>
                          </div>
                        </div>
                      )}
                    </div>
                  </div>
                )}

                {innovationMode === 'policy' && user?.userType === 'corporate' && (
                  <div className="max-w-3xl mx-auto space-y-8">
                    <div className="text-center space-y-4">
                      <div className="bg-emerald-100 w-16 h-16 rounded-2xl flex items-center justify-center text-emerald-600 mx-auto">
                        <ShieldCheck size={32} />
                      </div>
                      <h3 className="text-2xl font-bold">Enterprise Policy Drafter</h3>
                      <p className="text-slate-500">Generate internal compliance policies, HR guidelines, or IT security protocols.</p>
                    </div>
                    <div className="bg-white p-8 rounded-3xl border border-slate-100 shadow-xl space-y-6">
                      <textarea 
                        className="w-full h-40 p-4 bg-slate-50 border border-slate-200 rounded-2xl outline-none focus:ring-2 focus:ring-emerald-500 transition-all resize-none text-sm"
                        placeholder="Describe the policy requirements (e.g., 'Draft a Remote Work Policy for a banking institution with focus on data security and RBI compliance')..."
                      />
                      <button className="w-full py-4 bg-emerald-600 text-white rounded-xl font-bold hover:bg-emerald-700 transition-all shadow-lg shadow-emerald-200 flex items-center justify-center gap-2">
                        <Zap size={20} /> Generate Policy Draft
                      </button>
                    </div>
                  </div>
                )}

                {innovationMode === 'brief' && (
                  <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
                    <div className="space-y-4">
                      <h3 className="text-xl font-bold flex items-center gap-2"><BookOpen className="text-emerald-600" /> Judgment Input</h3>
                      <textarea 
                        value={briefInput}
                        onChange={(e) => setBriefInput(e.target.value)}
                        placeholder="Paste the full text of a court judgment here..."
                        className="w-full h-[300px] lg:h-[500px] p-6 bg-white border border-slate-200 rounded-3xl shadow-sm outline-none focus:ring-2 focus:ring-emerald-500 transition-all resize-none text-sm"
                      />
                      <button 
                        onClick={handleGenerateBrief}
                        disabled={isBriefLoading || !briefInput}
                        className="w-full bg-emerald-600 text-white py-4 rounded-2xl font-bold shadow-lg shadow-emerald-200 hover:bg-emerald-700 disabled:opacity-50 transition-all flex items-center justify-center gap-2"
                      >
                        {isBriefLoading ? <Activity className="animate-spin" /> : <FileText size={20} />}
                        <span>Generate Case Brief</span>
                      </button>
                    </div>
                    <div className="space-y-4">
                      <h3 className="text-xl font-bold flex items-center gap-2"><Activity className="text-emerald-600" /> Structured Brief</h3>
                      <div className="w-full h-[300px] lg:h-[500px] p-6 bg-white border border-slate-200 rounded-3xl shadow-sm overflow-y-auto">
                        {isBriefLoading ? (
                          <div className="h-full flex flex-col items-center justify-center text-slate-400 space-y-4">
                            <Cpu size={48} className="animate-spin" />
                            <p>Analyzing judgment and extracting key points...</p>
                          </div>
                        ) : briefResult ? (
                          <div className="markdown-body">
                            <Markdown>{briefResult}</Markdown>
                          </div>
                        ) : (
                          <div className="h-full flex flex-col items-center justify-center text-slate-300 text-center">
                            <BookOpen size={48} opacity={0.2} />
                            <p>Your generated brief will appear here.</p>
                          </div>
                        )}
                      </div>
                    </div>
                  </div>
                )}

                {innovationMode === 'statute' && (
                  <div className="max-w-3xl mx-auto space-y-8">
                    <div className="text-center space-y-4">
                      <div className="bg-emerald-100 w-16 h-16 rounded-2xl flex items-center justify-center text-emerald-600 mx-auto">
                        <BrainCircuit size={32} />
                      </div>
                      <h3 className="text-2xl font-bold">Statute Simplifier</h3>
                      <p className="text-slate-500">Translate complex legal sections into plain, understandable English.</p>
                    </div>
                    <div className="bg-white p-8 rounded-3xl border border-slate-100 shadow-xl space-y-6">
                      <textarea 
                        value={statuteInput}
                        onChange={(e) => setStatuteInput(e.target.value)}
                        placeholder="Paste a legal section (e.g., Section 420 of IPC)..."
                        className="w-full h-32 p-4 bg-slate-50 border border-slate-200 rounded-2xl outline-none focus:ring-2 focus:ring-emerald-500 transition-all resize-none"
                      />
                      <button 
                        onClick={handleSimplifyStatute}
                        disabled={isStatuteLoading || !statuteInput}
                        className="w-full bg-emerald-600 text-white py-4 rounded-2xl font-bold shadow-lg shadow-emerald-200 hover:bg-emerald-700 disabled:opacity-50 transition-all flex items-center justify-center gap-2"
                      >
                        {isStatuteLoading ? <Activity className="animate-spin" /> : <Zap size={20} />}
                        <span>Simplify Now</span>
                      </button>
                    </div>
                    {statuteResult && (
                      <motion.div 
                        initial={{ opacity: 0, y: 20 }}
                        animate={{ opacity: 1, y: 0 }}
                        className="bg-emerald-50 p-8 rounded-3xl border border-emerald-100"
                      >
                        <div className="markdown-body">
                          <Markdown>{statuteResult}</Markdown>
                        </div>
                      </motion.div>
                    )}
                  </div>
                )}

                {innovationMode === 'timeline' && (
                  <div className="grid grid-cols-1 lg:grid-cols-12 gap-8">
                    <div className="col-span-1 lg:col-span-4 space-y-4">
                      <h3 className="text-xl font-bold flex items-center gap-2"><Activity className="text-emerald-600" /> Case Narrative</h3>
                      <textarea 
                        value={timelineInput}
                        onChange={(e) => setTimelineInput(e.target.value)}
                        placeholder="Describe the sequence of events in the case..."
                        className="w-full h-[300px] lg:h-[400px] p-6 bg-white border border-slate-200 rounded-3xl shadow-sm outline-none focus:ring-2 focus:ring-emerald-500 transition-all resize-none text-sm"
                      />
                      <button 
                        onClick={handleGenerateTimeline}
                        disabled={isTimelineLoading || !timelineInput}
                        className="w-full bg-emerald-600 text-white py-4 rounded-2xl font-bold shadow-lg shadow-emerald-200 hover:bg-emerald-700 disabled:opacity-50 transition-all flex items-center justify-center gap-2"
                      >
                        {isTimelineLoading ? <Activity className="animate-spin" /> : <BarChart3 size={20} />}
                        <span>Generate Timeline</span>
                      </button>
                    </div>
                    <div className="col-span-1 lg:col-span-8 space-y-4">
                      <h3 className="text-xl font-bold flex items-center gap-2"><Activity className="text-emerald-600" /> Visual Timeline</h3>
                      <div className="w-full h-[400px] lg:h-[500px] p-8 bg-white border border-slate-200 rounded-3xl shadow-sm overflow-y-auto">
                        {isTimelineLoading ? (
                          <div className="h-full flex flex-col items-center justify-center text-slate-400 space-y-4">
                            <Cpu size={48} className="animate-spin" />
                            <p>Extracting dates and events...</p>
                          </div>
                        ) : timelineResult.length > 0 ? (
                          <div className="relative border-l-2 border-emerald-100 ml-4 pl-8 space-y-8">
                            {timelineResult.map((item, idx) => (
                              <motion.div 
                                key={idx}
                                initial={{ opacity: 0, x: -20 }}
                                animate={{ opacity: 1, x: 0 }}
                                transition={{ delay: idx * 0.1 }}
                                className="relative"
                              >
                                <div className="absolute -left-[41px] top-1 w-4 h-4 rounded-full bg-emerald-500 border-4 border-white shadow-sm" />
                                <div className="bg-slate-50 p-4 rounded-2xl border border-slate-100">
                                  <span className="text-xs font-bold text-emerald-600 uppercase tracking-widest">{item.date}</span>
                                  <h4 className="font-bold text-slate-900 mt-1">{item.event}</h4>
                                  <p className="text-sm text-slate-500 mt-2">{item.significance}</p>
                                </div>
                              </motion.div>
                            ))}
                          </div>
                        ) : (
                          <div className="h-full flex flex-col items-center justify-center text-slate-300 text-center">
                            <BarChart3 size={48} opacity={0.2} />
                            <p>Your visual timeline will appear here.</p>
                          </div>
                        )}
                      </div>
                    </div>
                  </div>
                )}

                {innovationMode === 'exhibit' && (
                  <div className="grid grid-cols-1 lg:grid-cols-12 gap-8">
                    <div className="col-span-1 lg:col-span-4 space-y-6">
                      <div className="bg-white dark:bg-slate-900 p-6 rounded-3xl border border-slate-100 dark:border-slate-800 shadow-xl space-y-4">
                        <h3 className="text-xl font-bold flex items-center gap-2 text-slate-900 dark:text-slate-100">
                          <Video className="text-emerald-600" /> Exhibit Generator
                        </h3>
                        <p className="text-sm text-slate-500 dark:text-slate-400">Describe a scene or event to generate a high-quality visual evidence exhibit for court presentations.</p>
                        
                        <div className="space-y-2">
                          <label className="text-xs font-bold text-slate-500 uppercase tracking-widest">Reference Image (Optional)</label>
                          <div className="flex items-center justify-center w-full">
                            <label className="flex flex-col items-center justify-center w-full h-32 border-2 border-slate-200 dark:border-slate-700 border-dashed rounded-2xl cursor-pointer bg-slate-50 dark:bg-slate-800 hover:bg-slate-100 dark:hover:bg-slate-700 transition-all">
                              <div className="flex flex-col items-center justify-center pt-5 pb-6">
                                <ImageIcon className="w-8 h-8 mb-3 text-slate-400" />
                                <p className="text-xs text-slate-500">Click to upload reference</p>
                              </div>
                              <input type="file" className="hidden" onChange={(e) => {
                                const file = e.target.files?.[0];
                                if (file) {
                                  const reader = new FileReader();
                                  reader.onloadend = () => setExhibitFile(reader.result as string);
                                  reader.readAsDataURL(file);
                                }
                              }} />
                            </label>
                          </div>
                          {exhibitFile && (
                            <div className="relative w-20 h-20 mt-2">
                              <img src={exhibitFile} className="w-full h-full object-cover rounded-lg border border-slate-200 dark:border-slate-700" />
                              <button onClick={() => setExhibitFile(null)} className="absolute -top-2 -right-2 bg-rose-500 text-white rounded-full p-1 shadow-md">
                                <X size={12} />
                              </button>
                            </div>
                          )}
                        </div>

                        <div className="space-y-2">
                          <label className="text-xs font-bold text-slate-500 uppercase tracking-widest">Scene Description</label>
                          <textarea 
                            value={exhibitPrompt}
                            onChange={(e) => setExhibitPrompt(e.target.value)}
                            placeholder="e.g., A slow-motion reconstruction of a car collision at an intersection with wet pavement..."
                            className="w-full h-32 p-4 bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-2xl outline-none focus:ring-2 focus:ring-emerald-500 transition-all resize-none text-sm dark:text-slate-100"
                          />
                        </div>

                        <button 
                          onClick={handleGenerateExhibit}
                          disabled={isExhibitLoading || !exhibitPrompt}
                          className="w-full bg-emerald-600 text-white py-4 rounded-2xl font-bold shadow-lg shadow-emerald-200 hover:bg-emerald-700 disabled:opacity-50 transition-all flex items-center justify-center gap-2"
                        >
                          {isExhibitLoading ? <Activity className="animate-spin" /> : <Zap size={20} />}
                          <span>Generate Exhibit</span>
                        </button>
                      </div>
                    </div>
                    
                    <div className="col-span-1 lg:col-span-8 bg-slate-900 rounded-[40px] shadow-2xl overflow-hidden flex flex-col min-h-[500px]">
                      <div className="p-6 bg-slate-800 border-b border-slate-700 flex justify-between items-center">
                        <div className="flex items-center gap-3">
                          <div className="w-10 h-10 rounded-xl bg-emerald-500/20 flex items-center justify-center text-emerald-400">
                            <Video size={20} />
                          </div>
                          <div>
                            <h4 className="text-white font-bold">Visual Evidence Preview</h4>
                            <p className="text-xs text-slate-400">Powered by Veo 3.1 Fast</p>
                          </div>
                        </div>
                      </div>
                      
                      <div className="flex-1 flex flex-col items-center justify-center p-8">
                        {isExhibitLoading ? (
                          <div className="text-center space-y-6">
                            <div className="relative">
                              <div className="w-24 h-24 border-4 border-emerald-500/20 border-t-emerald-500 rounded-full animate-spin mx-auto" />
                              <Video className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 text-emerald-500 animate-pulse" size={32} />
                            </div>
                            <div className="space-y-2">
                              <h5 className="text-xl font-bold text-white">Generating Visual Exhibit...</h5>
                              <p className="text-slate-400 max-w-md mx-auto">This may take a few minutes. Our AI is reconstructing the scene based on your description.</p>
                            </div>
                          </div>
                        ) : exhibitResult ? (
                          <div className="w-full max-w-3xl space-y-6">
                            <video src={exhibitResult} controls className="w-full rounded-3xl shadow-2xl border border-slate-700" />
                            <div className="flex justify-center gap-4">
                              <button className="bg-white/10 hover:bg-white/20 text-white px-6 py-3 rounded-xl font-bold transition-all flex items-center gap-2">
                                <Download size={20} /> Download Exhibit
                              </button>
                              <button className="bg-emerald-600 hover:bg-emerald-700 text-white px-6 py-3 rounded-xl font-bold transition-all flex items-center gap-2">
                                <Share2 size={20} /> Share with Team
                              </button>
                            </div>
                          </div>
                        ) : (
                          <div className="text-center text-slate-600 space-y-4">
                            <Video size={80} className="mx-auto opacity-10" />
                            <p className="text-lg">Your generated evidence exhibit will appear here.</p>
                          </div>
                        )}
                      </div>
                    </div>
                  </div>
                )}

                {innovationMode === 'evidence' && (
                  <div className="grid grid-cols-1 lg:grid-cols-12 gap-8">
                    <div className="col-span-1 lg:col-span-4 space-y-6">
                      <div className="bg-white dark:bg-slate-900 p-6 rounded-3xl border border-slate-100 dark:border-slate-800 shadow-xl space-y-4">
                        <h3 className="text-xl font-bold flex items-center gap-2 text-slate-900 dark:text-slate-100">
                          <Eye className="text-emerald-600" /> Evidence Analysis
                        </h3>
                        <p className="text-sm text-slate-500 dark:text-slate-400">Upload an image of evidence (document, photo, etc.) for AI-powered forensic analysis.</p>
                        
                        <div className="space-y-2">
                          <label className="text-xs font-bold text-slate-500 uppercase tracking-widest">Evidence Image</label>
                          <div className="flex items-center justify-center w-full">
                            <label className="flex flex-col items-center justify-center w-full h-48 border-2 border-slate-200 dark:border-slate-700 border-dashed rounded-2xl cursor-pointer bg-slate-50 dark:bg-slate-800 hover:bg-slate-100 dark:hover:bg-slate-700 transition-all">
                              {evidencePreview ? (
                                <img src={evidencePreview} className="w-full h-full object-contain rounded-2xl" />
                              ) : (
                                <div className="flex flex-col items-center justify-center pt-5 pb-6">
                                  <ImageIcon className="w-10 h-10 mb-3 text-slate-400" />
                                  <p className="text-xs text-slate-500">Click to upload evidence</p>
                                </div>
                              )}
                              <input type="file" className="hidden" accept="image/*" onChange={(e) => {
                                const file = e.target.files?.[0];
                                if (file) {
                                  setEvidenceFile(file);
                                  const reader = new FileReader();
                                  reader.onloadend = () => setEvidencePreview(reader.result as string);
                                  reader.readAsDataURL(file);
                                }
                              }} />
                            </label>
                          </div>
                        </div>

                        <button 
                          onClick={handleAnalyzeEvidence}
                          disabled={isEvidenceLoading || !evidenceFile}
                          className="w-full bg-emerald-600 text-white py-4 rounded-2xl font-bold shadow-lg shadow-emerald-200 hover:bg-emerald-700 disabled:opacity-50 transition-all flex items-center justify-center gap-2"
                        >
                          {isEvidenceLoading ? <Activity className="animate-spin" /> : <Search size={20} />}
                          <span>Analyze Evidence</span>
                        </button>
                      </div>
                    </div>
                    
                    <div className="col-span-1 lg:col-span-8 bg-white dark:bg-slate-900 rounded-3xl border border-slate-100 dark:border-slate-800 shadow-xl p-8 overflow-y-auto min-h-[500px]">
                      {isEvidenceLoading ? (
                        <div className="h-full flex flex-col items-center justify-center text-slate-400 space-y-4">
                          <Cpu size={48} className="animate-spin" />
                          <p>AI is analyzing the evidence image...</p>
                        </div>
                      ) : evidenceResult ? (
                        <div className="markdown-body">
                          <Markdown>{evidenceResult}</Markdown>
                        </div>
                      ) : (
                        <div className="h-full flex flex-col items-center justify-center text-slate-300 text-center">
                          <Eye size={80} className="mx-auto opacity-10 mb-4" />
                          <p className="text-lg">Analysis results will appear here.</p>
                        </div>
                      )}
                    </div>
                  </div>
                )}

                {innovationMode === 'audio' && (
                  <div className="grid grid-cols-1 lg:grid-cols-12 gap-8">
                    <div className="col-span-1 lg:col-span-4 space-y-6">
                      <div className="bg-white dark:bg-slate-900 p-6 rounded-3xl border border-slate-100 dark:border-slate-800 shadow-xl space-y-4">
                        <h3 className="text-xl font-bold flex items-center gap-2 text-slate-900 dark:text-slate-100">
                          <Mic className="text-emerald-600" /> Audio Transcribe
                        </h3>
                        <p className="text-sm text-slate-500 dark:text-slate-400">Upload legal recordings, interviews, or court proceedings for accurate AI transcription.</p>
                        
                        <div className="space-y-2">
                          <label className="text-xs font-bold text-slate-500 uppercase tracking-widest">Audio File</label>
                          <div className="flex items-center justify-center w-full">
                            <label className="flex flex-col items-center justify-center w-full h-32 border-2 border-slate-200 dark:border-slate-700 border-dashed rounded-2xl cursor-pointer bg-slate-50 dark:bg-slate-800 hover:bg-slate-100 dark:hover:bg-slate-700 transition-all">
                              <div className="flex flex-col items-center justify-center pt-5 pb-6">
                                <Music className="w-8 h-8 mb-3 text-slate-400" />
                                <p className="text-xs text-slate-500">{audioFile ? audioFile.name : 'Click to upload audio'}</p>
                              </div>
                              <input type="file" className="hidden" accept="audio/*" onChange={(e) => setAudioFile(e.target.files?.[0] || null)} />
                            </label>
                          </div>
                        </div>

                        <button 
                          onClick={handleTranscribeAudio}
                          disabled={isAudioLoading || !audioFile}
                          className="w-full bg-emerald-600 text-white py-4 rounded-2xl font-bold shadow-lg shadow-emerald-200 hover:bg-emerald-700 disabled:opacity-50 transition-all flex items-center justify-center gap-2"
                        >
                          {isAudioLoading ? <Activity className="animate-spin" /> : <Zap size={20} />}
                          <span>Transcribe Now</span>
                        </button>
                      </div>
                    </div>
                    
                    <div className="col-span-1 lg:col-span-8 bg-white dark:bg-slate-900 rounded-3xl border border-slate-100 dark:border-slate-800 shadow-xl p-8 overflow-y-auto min-h-[500px]">
                      {isAudioLoading ? (
                        <div className="h-full flex flex-col items-center justify-center text-slate-400 space-y-4">
                          <Cpu size={48} className="animate-spin" />
                          <p>AI is transcribing the audio recording...</p>
                        </div>
                      ) : audioResult ? (
                        <div className="markdown-body">
                          <Markdown>{audioResult}</Markdown>
                        </div>
                      ) : (
                        <div className="h-full flex flex-col items-center justify-center text-slate-300 text-center">
                          <Mic size={80} className="mx-auto opacity-10 mb-4" />
                          <p className="text-lg">Transcription will appear here.</p>
                        </div>
                      )}
                    </div>
                  </div>
                )}

                {innovationMode === 'computable-contract' && (
                  <div className="grid grid-cols-1 lg:grid-cols-12 gap-8">
                    <div className="col-span-1 lg:col-span-4 space-y-6">
                      <div className="bg-white dark:bg-slate-900 p-6 rounded-3xl border border-slate-100 dark:border-slate-800 shadow-xl space-y-4">
                        <h3 className="text-xl font-bold flex items-center gap-2 text-slate-900 dark:text-slate-100">
                          <Zap className="text-emerald-600" /> Computable Contracts
                        </h3>
                        <p className="text-sm text-slate-500 dark:text-slate-400">Convert standard legal text into machine-readable logic and automated triggers.</p>
                        
                        <textarea 
                          value={computableInput}
                          onChange={(e) => setComputableInput(e.target.value)}
                          placeholder="Paste your contract text here..."
                          className="w-full h-48 p-4 bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-2xl outline-none focus:ring-2 focus:ring-emerald-500 transition-all resize-none text-sm"
                        />

                        <button 
                          onClick={handleGenerateComputable}
                          disabled={isComputableLoading || !computableInput}
                          className="w-full bg-emerald-600 text-white py-4 rounded-2xl font-bold shadow-lg shadow-emerald-200 hover:bg-emerald-700 disabled:opacity-50 transition-all flex items-center justify-center gap-2"
                        >
                          {isComputableLoading ? <Activity className="animate-spin" /> : <Cpu size={20} />}
                          <span>Generate Logic</span>
                        </button>
                      </div>
                    </div>
                    
                    <div className="col-span-1 lg:col-span-8 bg-slate-900 rounded-3xl shadow-xl p-8 overflow-y-auto min-h-[500px]">
                      {isComputableLoading ? (
                        <div className="h-full flex flex-col items-center justify-center text-slate-400 space-y-4">
                          <Activity className="animate-spin" size={48} />
                          <p>AI is computing contract logic...</p>
                        </div>
                      ) : computableResult ? (
                        <div className="markdown-body text-slate-300">
                          <Markdown>{computableResult}</Markdown>
                        </div>
                      ) : (
                        <div className="h-full flex flex-col items-center justify-center text-slate-700 text-center space-y-4">
                          <Zap size={64} opacity={0.1} />
                          <p>Computable logic will appear here.</p>
                        </div>
                      )}
                    </div>
                  </div>
                )}

                {innovationMode === 'algorithmic-triage' && (
                  <div className="grid grid-cols-1 lg:grid-cols-12 gap-8">
                    <div className="col-span-1 lg:col-span-4 space-y-6">
                      <div className="bg-white dark:bg-slate-900 p-6 rounded-3xl border border-slate-100 dark:border-slate-800 shadow-xl space-y-4">
                        <h3 className="text-xl font-bold flex items-center gap-2 text-slate-900 dark:text-slate-100">
                          <BarChart3 className="text-emerald-600" /> Algorithmic Triage
                        </h3>
                        <p className="text-sm text-slate-500 dark:text-slate-400">Map legal scenarios to automated compliance resolutions and strategic deployment.</p>
                        
                        <textarea 
                          value={triageInput}
                          onChange={(e) => setTriageInput(e.target.value)}
                          placeholder="Describe the legal scenario or compliance issue..."
                          className="w-full h-48 p-4 bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-2xl outline-none focus:ring-2 focus:ring-emerald-500 transition-all resize-none text-sm"
                        />

                        <button 
                          onClick={handleRunTriage}
                          disabled={isTriageLoading || !triageInput}
                          className="w-full bg-emerald-600 text-white py-4 rounded-2xl font-bold shadow-lg shadow-emerald-200 hover:bg-emerald-700 disabled:opacity-50 transition-all flex items-center justify-center gap-2"
                        >
                          {isTriageLoading ? <Activity className="animate-spin" /> : <ShieldCheck size={20} />}
                          <span>Run Triage</span>
                        </button>
                      </div>
                    </div>
                    
                    <div className="col-span-1 lg:col-span-8 bg-white dark:bg-slate-900 rounded-3xl border border-slate-100 dark:border-slate-800 shadow-xl p-8 overflow-y-auto min-h-[500px]">
                      {isTriageLoading ? (
                        <div className="h-full flex flex-col items-center justify-center text-slate-400 space-y-4">
                          <Activity className="animate-spin" size={48} />
                          <p>AI is running triage algorithms...</p>
                        </div>
                      ) : triageResult ? (
                        <div className="markdown-body">
                          <Markdown>{triageResult}</Markdown>
                        </div>
                      ) : (
                        <div className="h-full flex flex-col items-center justify-center text-slate-300 dark:text-slate-700 text-center space-y-4">
                          <BarChart3 size={64} opacity={0.1} />
                          <p>Triage results and decision tree will appear here.</p>
                        </div>
                      )}
                    </div>
                  </div>
                )}
              </motion.div>
            )}

            {activeTab === 'research' && (
              <motion.div 
                key="research"
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                className="max-w-4xl mx-auto space-y-8"
              >
                <div className="flex justify-between items-center">
                  <div>
                    <h2 className="text-3xl font-bold text-slate-900 dark:text-slate-100">Legal Research</h2>
                    <p className="text-slate-500 dark:text-slate-400">Search case law, statutes, and precedents with AI grounding.</p>
                  </div>
                  <button 
                    onClick={() => {
                      const text = chatHistory.filter(m => m.role === 'ai').map(m => m.content).join('\n\n---\n\n');
                      navigator.clipboard.writeText(text);
                      // Toast would go here
                    }}
                    className="flex items-center gap-2 px-4 py-2 bg-slate-100 dark:bg-slate-800 text-slate-600 dark:text-slate-300 rounded-xl font-bold hover:bg-slate-200 transition-all"
                  >
                    <Copy size={18} /> Copy Results
                  </button>
                </div>

                <div className="bg-white dark:bg-slate-900 p-8 rounded-3xl border border-slate-100 dark:border-slate-800 shadow-xl space-y-6">
                  <div className="relative">
                    <Search className="absolute left-4 top-1/2 -translate-y-1/2 text-slate-400" size={20} />
                    <input 
                      value={aiPrompt}
                      onChange={(e) => setAiPrompt(e.target.value)}
                      placeholder="Search for case law or legal precedents..."
                      className="w-full pl-12 pr-4 py-4 bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-2xl outline-none focus:ring-2 focus:ring-emerald-500 transition-all dark:text-slate-100"
                    />
                  </div>
                  <button 
                    onClick={() => { setAiMode('search'); handleAiAction(); }}
                    disabled={loading || !aiPrompt}
                    className="w-full bg-emerald-600 text-white py-4 rounded-2xl font-bold hover:bg-emerald-700 disabled:opacity-50 transition-all flex items-center justify-center gap-2"
                  >
                    {loading ? <Activity className="animate-spin" /> : <Search size={20} />}
                    <span>Search Precedents</span>
                  </button>
                </div>

                {aiResponse && (
                  <div className="bg-white dark:bg-slate-900 p-8 rounded-3xl border border-slate-100 dark:border-slate-800 shadow-xl">
                    <div className="flex justify-between items-center mb-6">
                      <h3 className="text-xl font-bold flex items-center gap-2"><BookOpen className="text-emerald-600" /> Research Results</h3>
                      <div className="flex gap-2">
                        <button 
                          onClick={() => handleSpeak(aiResponse)}
                          className={`flex items-center gap-2 px-4 py-2 rounded-xl font-bold transition-all ${isSpeaking ? 'bg-rose-100 text-rose-600' : 'bg-emerald-100 text-emerald-600'}`}
                        >
                          {isSpeaking ? <X size={18} /> : <Volume2 size={18} />}
                          {isSpeaking ? 'Stop' : 'Listen'}
                        </button>
                        <button className="text-emerald-600 font-bold text-sm flex items-center gap-2 bg-slate-50 dark:bg-slate-800 px-4 py-2 rounded-xl"><Download size={18} /> Export PDF</button>
                      </div>
                    </div>
                    <div className="prose dark:prose-invert max-w-none">
                      <Markdown>{aiResponse}</Markdown>
                    </div>
                  </div>
                )}
              </motion.div>
            )}

            {activeTab === 'drafting' && (
              <motion.div 
                key="drafting"
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                className="max-w-4xl mx-auto space-y-8"
              >
                <div className="flex justify-between items-center">
                  <div>
                    <h2 className="text-3xl font-bold text-slate-900 dark:text-slate-100">AI Drafting</h2>
                    <p className="text-slate-500 dark:text-slate-400">Generate professional legal documents, briefs, and notices.</p>
                  </div>
                </div>

                <div className="grid grid-cols-1 lg:grid-cols-12 gap-8">
                  <div className="col-span-1 lg:col-span-5 space-y-6">
                    <div className="bg-white dark:bg-slate-900 p-6 rounded-3xl border border-slate-100 dark:border-slate-800 shadow-xl space-y-4">
                      <h3 className="font-bold text-slate-900 dark:text-slate-100">Document Details</h3>
                      <div>
                        <label className="block text-xs font-bold text-slate-500 uppercase tracking-widest mb-2">Template Type</label>
                        <select 
                          className="w-full p-3 bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-xl outline-none focus:ring-2 focus:ring-emerald-500 transition-all text-sm dark:text-slate-100"
                          value={draftType}
                          onChange={(e) => setDraftType(e.target.value)}
                        >
                          <option value="Legal Notice">Legal Notice</option>
                          <option value="Vakalatnama">Vakalatnama</option>
                          <option value="Bail Application">Bail Application</option>
                          <option value="Employment Contract">Employment Contract</option>
                          <option value="Affidavit">Affidavit</option>
                        </select>
                      </div>
                      <div>
                        <label className="block text-xs font-bold text-slate-500 uppercase tracking-widest mb-2">Case Details</label>
                        <textarea 
                          value={draftInput}
                          onChange={(e) => setDraftInput(e.target.value)}
                          placeholder="Provide names, dates, and core facts..."
                          className="w-full h-40 p-4 bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-2xl outline-none focus:ring-2 focus:ring-emerald-500 transition-all resize-none text-sm dark:text-slate-100"
                        />
                      </div>
                      <button 
                        onClick={handleGenerateDraft}
                        disabled={loading || !draftInput}
                        className="w-full bg-emerald-600 text-white py-4 rounded-2xl font-bold hover:bg-emerald-700 disabled:opacity-50 transition-all flex items-center justify-center gap-2"
                      >
                        {loading ? <Activity className="animate-spin" /> : <FileCheck size={20} />}
                        <span>Generate Draft</span>
                      </button>
                    </div>
                  </div>

                  <div className="col-span-1 lg:col-span-7 bg-white dark:bg-slate-900 rounded-3xl border border-slate-100 dark:border-slate-800 shadow-xl flex flex-col min-h-[500px]">
                    <div className="p-6 border-b border-slate-100 dark:border-slate-800 flex justify-between items-center">
                      <h3 className="font-bold text-slate-900 dark:text-slate-100">Document Preview</h3>
                      {draftResult && (
                        <div className="flex gap-2">
                          <button 
                            onClick={() => handleSpeak(draftResult)}
                            className={`flex items-center gap-2 px-3 py-1.5 rounded-lg font-bold transition-all text-xs ${isSpeaking ? 'bg-rose-100 text-rose-600' : 'bg-emerald-100 text-emerald-600'}`}
                          >
                            {isSpeaking ? <X size={14} /> : <Volume2 size={14} />}
                            {isSpeaking ? 'Stop' : 'Listen'}
                          </button>
                          <button 
                            onClick={() => navigator.clipboard.writeText(draftResult)}
                            className="p-2 text-slate-400 hover:text-emerald-600 transition-all"
                          >
                            <Copy size={18} />
                          </button>
                          <button className="p-2 text-slate-400 hover:text-emerald-600 transition-all">
                            <Download size={18} />
                          </button>
                        </div>
                      )}
                    </div>
                    <div className="flex-1 flex overflow-hidden">
                      {draftResult && (
                        <div className="w-64 border-r border-slate-100 dark:border-slate-800 p-6 overflow-y-auto hidden md:block bg-slate-50/50 dark:bg-slate-900/50">
                          <h4 className="text-xs font-bold text-slate-400 uppercase tracking-widest mb-4">Document Structure</h4>
                          <div className="space-y-2">
                            {extractHeaders(draftResult).map((header) => (
                              <button 
                                key={header.id}
                                className="w-full text-left text-xs text-slate-600 dark:text-slate-400 hover:text-emerald-600 dark:hover:text-emerald-400 transition-all py-1"
                              >
                                {header.text}
                              </button>
                            ))}
                          </div>
                          
                          <div className="mt-8 pt-8 border-t border-slate-100 dark:border-slate-800">
                            <h4 className="text-xs font-bold text-slate-400 uppercase tracking-widest mb-4">Quick Stats</h4>
                            <div className="space-y-3">
                              <div className="flex justify-between text-[10px]">
                                <span className="text-slate-500">Words</span>
                                <span className="font-bold text-slate-900 dark:text-slate-100">{draftResult.split(/\s+/).length}</span>
                              </div>
                              <div className="flex justify-between text-[10px]">
                                <span className="text-slate-500">Characters</span>
                                <span className="font-bold text-slate-900 dark:text-slate-100">{draftResult.length}</span>
                              </div>
                              <div className="flex justify-between text-[10px]">
                                <span className="text-slate-500">Complexity</span>
                                <span className="font-bold text-emerald-600">Standard</span>
                              </div>
                            </div>
                          </div>
                        </div>
                      )}
                      <div className="flex-1 p-8 overflow-y-auto font-serif text-sm leading-relaxed whitespace-pre-wrap dark:text-slate-300">
                        {draftResult || (
                          <div className="h-full flex flex-col items-center justify-center text-slate-300 dark:text-slate-700 text-center space-y-4">
                            <FileText size={64} opacity={0.1} />
                            <p>Your generated document will appear here.</p>
                          </div>
                        )}
                      </div>
                    </div>
                  </div>
                </div>
              </motion.div>
            )}

            {activeTab === 'clients' && (
              <motion.div 
                key="clients"
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                className="max-w-5xl mx-auto space-y-8"
              >
                <div className="flex justify-between items-center">
                  <div>
                    <h2 className="text-3xl font-bold text-slate-900 dark:text-slate-100">Client Management</h2>
                    <p className="text-slate-500 dark:text-slate-400">Manage your client relationships and linked cases.</p>
                  </div>
                  <button className="bg-emerald-600 text-white px-6 py-2.5 rounded-xl font-bold shadow-lg shadow-emerald-500/20 hover:bg-emerald-700 transition-all flex items-center gap-2">
                    <Plus size={18} /> Add New Client
                  </button>
                </div>

                <div className="grid grid-cols-1 gap-4">
                  {teamMembers.filter(m => m.role === 'Client').length === 0 ? (
                    <EmptyState 
                      icon={Users}
                      title="No clients found"
                      description="You haven't added any clients yet. Start by creating your first client record."
                      actionLabel="Add New Client"
                    />
                  ) : (
                    teamMembers.filter(m => m.role === 'Client').map((client: any) => (
                      <div key={client.id} className="bg-white dark:bg-slate-900 p-6 rounded-3xl border border-slate-100 dark:border-slate-800 shadow-sm flex justify-between items-center hover:shadow-md transition-all">
                        <div className="flex items-center gap-4">
                          <div className="w-14 h-14 rounded-2xl bg-slate-100 dark:bg-slate-800 flex items-center justify-center text-slate-600 dark:text-slate-400">
                            <Users size={24} />
                          </div>
                          <div>
                            <h4 className="font-bold text-slate-900 dark:text-slate-100">{client.name}</h4>
                            <p className="text-sm text-slate-500 dark:text-slate-400">{client.email}</p>
                          </div>
                        </div>
                        <div className="flex items-center gap-3">
                          <button className="px-4 py-2 bg-slate-50 dark:bg-slate-800 text-slate-600 dark:text-slate-300 rounded-xl text-sm font-bold hover:bg-slate-100 transition-all">View Cases</button>
                          <button className="p-2 text-slate-400 hover:text-rose-500 transition-all"><Trash2 size={18} /></button>
                        </div>
                      </div>
                    ))
                  )}
                </div>
              </motion.div>
            )}
            {activeTab === 'team' && (
              <motion.div 
                key="team"
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                className="max-w-4xl mx-auto h-[calc(100vh-250px)] lg:h-[700px] flex flex-col bg-white dark:bg-slate-900 rounded-3xl border border-slate-100 dark:border-slate-800 shadow-xl overflow-hidden"
              >
                <div className="p-6 bg-slate-50 dark:bg-slate-800/50 border-b border-slate-100 dark:border-slate-800 flex justify-between items-center">
                  <div>
                    <h2 className="text-2xl font-bold text-slate-900 dark:text-slate-100">Team Collaboration</h2>
                    <p className="text-sm text-slate-500 dark:text-slate-400">Real-time chat and document sync.</p>
                  </div>
                  <div className="flex items-center gap-2">
                    <div className="w-2 h-2 rounded-full bg-emerald-500 animate-pulse" />
                    <span className="text-xs font-bold text-emerald-600 uppercase tracking-widest">Live</span>
                  </div>
                </div>
                
                <div className="flex-1 p-6 overflow-y-auto space-y-4 bg-slate-50/50 dark:bg-slate-900/50">
                  {teamMessages.length === 0 ? (
                    <div className="h-full flex flex-col items-center justify-center text-slate-400 dark:text-slate-600 text-center space-y-4">
                      <MessageSquare size={48} opacity={0.2} />
                      <p>No messages yet. Start the conversation!</p>
                    </div>
                  ) : (
                    teamMessages.map((msg, i) => (
                      <div key={i} className={`flex ${msg.userId === user?.id ? 'justify-end' : 'justify-start'}`}>
                        <div className={`max-w-[70%] p-3 rounded-2xl ${msg.userId === user?.id ? 'bg-emerald-600 text-white' : 'bg-white dark:bg-slate-800 border border-slate-200 dark:border-slate-700 text-slate-800 dark:text-slate-200 shadow-sm'}`}>
                          <p className="text-[10px] font-bold mb-1 opacity-70 uppercase tracking-wider">{msg.userName}</p>
                          <p className="text-sm">{msg.message}</p>
                        </div>
                      </div>
                    ))
                  )}
                </div>

                <div className="p-4 bg-white dark:bg-slate-900 border-t border-slate-100 dark:border-slate-800">
                  <div className="flex gap-2">
                    <input 
                      value={teamInput}
                      onChange={(e) => setTeamInput(e.target.value)}
                      onKeyPress={(e) => e.key === 'Enter' && handleSendTeamMessage()}
                      placeholder="Type a message..."
                      className="flex-1 bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-xl px-4 py-3 outline-none focus:ring-2 focus:ring-emerald-500 transition-all dark:text-slate-100"
                    />
                    <button 
                      onClick={handleSendTeamMessage}
                      className="bg-emerald-600 text-white p-3 rounded-xl hover:bg-emerald-700 transition-all shadow-lg shadow-emerald-100"
                    >
                      <Send size={20} />
                    </button>
                  </div>
                </div>
              </motion.div>
            )}

            {activeTab === 'conflict-checker' && (
              <motion.div 
                key="conflict"
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                className="max-w-3xl mx-auto space-y-8"
              >
                <div className="text-center space-y-4">
                  <div className="bg-rose-100 w-16 h-16 rounded-2xl flex items-center justify-center text-rose-600 mx-auto">
                    <ShieldCheck size={32} />
                  </div>
                  <h2 className="text-3xl font-bold text-slate-900">Conflict of Interest Checker</h2>
                  <p className="text-slate-500">Search our database to identify potential ethical conflicts before onboarding new clients.</p>
                </div>

                <div className="bg-white p-8 rounded-3xl border border-slate-100 shadow-xl space-y-6">
                  <div className="relative">
                    <Search className="absolute left-4 top-1/2 -translate-y-1/2 text-slate-400" size={20} />
                    <input 
                      value={conflictSearch}
                      onChange={(e) => setConflictSearch(e.target.value)}
                      placeholder="Enter client name or entity..."
                      className="w-full pl-12 pr-4 py-4 bg-slate-50 border border-slate-200 rounded-2xl outline-none focus:ring-2 focus:ring-rose-500 transition-all"
                    />
                  </div>
                  <button 
                    onClick={handleConflictCheck}
                    disabled={isConflictLoading || !conflictSearch}
                    className="w-full bg-slate-900 text-white py-4 rounded-2xl font-bold hover:bg-slate-800 disabled:opacity-50 transition-all flex items-center justify-center gap-2"
                  >
                    {isConflictLoading ? <Activity className="animate-spin" /> : <ShieldCheck size={20} />}
                    <span>Run Conflict Check</span>
                  </button>
                </div>

                {conflictResult && (
                  <motion.div 
                    initial={{ opacity: 0, scale: 0.95 }}
                    animate={{ opacity: 1, scale: 1 }}
                    className={`p-8 rounded-3xl border ${conflictResult.hasConflict ? 'bg-rose-50 border-rose-100' : 'bg-emerald-50 border-emerald-100'}`}
                  >
                    <div className="flex items-start gap-4">
                      <div className={`p-3 rounded-xl ${conflictResult.hasConflict ? 'bg-rose-100 text-rose-600' : 'bg-emerald-100 text-emerald-600'}`}>
                        {conflictResult.hasConflict ? <AlertCircle size={24} /> : <CheckCircle2 size={24} />}
                      </div>
                      <div>
                        <h3 className={`text-xl font-bold ${conflictResult.hasConflict ? 'text-rose-900' : 'text-emerald-900'}`}>
                          {conflictResult.hasConflict ? 'Potential Conflict Detected' : 'No Conflicts Found'}
                        </h3>
                        <p className={`mt-1 ${conflictResult.hasConflict ? 'text-rose-700' : 'text-emerald-700'}`}>
                          {conflictResult.hasConflict 
                            ? `We found ${conflictResult.conflicts.length} matching record(s) in our database.` 
                            : 'This client/entity does not appear in our existing case records.'}
                        </p>
                        
                        {conflictResult.hasConflict && (
                          <>
                            <div className="mt-6 space-y-3">
                              {conflictResult.conflicts.map((c: any, i: number) => (
                                <div key={i} className="bg-white/50 p-4 rounded-xl border border-rose-200">
                                  <p className="font-bold text-slate-900">{c.case_title}</p>
                                  <p className="text-sm text-slate-500">Client: {c.client_name} | Status: {c.status}</p>
                                </div>
                              ))}
                            </div>
                            {conflictResult.aiAnalysis && (
                              <div className="mt-6 p-6 bg-white/80 rounded-2xl border border-rose-200 shadow-sm">
                                <h4 className="font-bold text-rose-900 flex items-center gap-2 mb-3">
                                  <Cpu size={18} /> AI Ethical Analysis
                                </h4>
                                <div className="text-sm text-rose-800 leading-relaxed markdown-body">
                                  <Markdown>{conflictResult.aiAnalysis}</Markdown>
                                </div>
                              </div>
                            )}
                          </>
                        )}
                      </div>
                    </div>
                  </motion.div>
                )}
              </motion.div>
            )}

            {activeTab === 'watchdog' && (
              <motion.div 
                key="watchdog"
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                className="max-w-4xl mx-auto space-y-8"
              >
                <div className="flex justify-between items-center">
                  <div>
                    <h2 className="text-3xl font-bold text-slate-900">Legal Research Watchdog</h2>
                    <p className="text-slate-500">AI agent monitoring legal updates for your areas of interest.</p>
                  </div>
                  <div className="bg-emerald-100 px-4 py-2 rounded-full text-emerald-700 text-sm font-bold flex items-center gap-2">
                    <Zap size={16} /> AI Active
                  </div>
                </div>

                <div className="grid grid-cols-1 lg:grid-cols-12 gap-8">
                  <div className="col-span-1 lg:col-span-4 space-y-6">
                    <div className="bg-white p-6 rounded-3xl border border-slate-100 shadow-xl space-y-4">
                      <h3 className="font-bold text-slate-900">Add New Subscription</h3>
                      <input 
                        value={watchdogTopic}
                        onChange={(e) => setWatchdogTopic(e.target.value)}
                        placeholder="e.g., IBC Amendments 2024"
                        className="w-full p-3 bg-slate-50 border border-slate-200 rounded-xl outline-none focus:ring-2 focus:ring-emerald-500 transition-all text-sm"
                      />
                      <button 
                        onClick={handleAddWatchdog}
                        disabled={isWatchdogLoading || !watchdogTopic}
                        className="w-full bg-emerald-600 text-white py-3 rounded-xl font-bold hover:bg-emerald-700 transition-all flex items-center justify-center gap-2"
                      >
                        {isWatchdogLoading ? <Activity className="animate-spin" /> : <Plus size={18} />}
                        <span>Subscribe</span>
                      </button>
                    </div>
                    
                    <div className="bg-slate-900 p-6 rounded-3xl text-white space-y-4">
                      <h3 className="font-bold flex items-center gap-2"><Info size={18} className="text-emerald-400" /> How it works</h3>
                      <p className="text-xs text-slate-400 leading-relaxed">
                        Our AI agent continuously crawls legal databases, gazettes, and court websites. When a match is found for your topic, you'll receive an instant summary and analysis.
                      </p>
                    </div>
                  </div>

                  <div className="col-span-1 lg:col-span-8 space-y-4">
                    <h3 className="font-bold text-slate-900 flex items-center gap-2">
                      <Activity size={18} className="text-emerald-600" /> Active Subscriptions
                    </h3>
                    <div className="grid grid-cols-1 gap-4">
                      {watchdogSubs.length === 0 ? (
                        <div className="bg-white p-12 rounded-3xl border border-slate-100 text-center text-slate-400">
                          <BrainCircuit size={48} className="mx-auto mb-4 opacity-20" />
                          <p>You haven't subscribed to any topics yet.</p>
                        </div>
                      ) : (
                        watchdogSubs.map((sub, i) => (
                          <div key={i} className="flex flex-col gap-4">
                            <div className="bg-white dark:bg-slate-900 p-6 rounded-3xl border border-slate-100 dark:border-slate-800 shadow-sm flex justify-between items-center group hover:border-emerald-200 transition-all">
                              <div className="flex items-center gap-4">
                                <div className="w-12 h-12 rounded-2xl bg-emerald-50 dark:bg-emerald-900/20 flex items-center justify-center text-emerald-600 dark:text-emerald-400">
                                  <Search size={20} />
                                </div>
                                <div>
                                  <h4 className="font-bold text-slate-900 dark:text-slate-100">{sub.topic}</h4>
                                  <p className="text-xs text-slate-500 dark:text-slate-400">Subscribed on {new Date(sub.created_at).toLocaleDateString()}</p>
                                </div>
                              </div>
                              <div className="flex items-center gap-3">
                                <button 
                                  onClick={() => handleGenerateWatchdogSummary(sub)}
                                  disabled={isSummarizingWatchdog[sub.id]}
                                  className="flex items-center gap-2 px-4 py-2 bg-emerald-50 dark:bg-emerald-900/20 text-emerald-600 dark:text-emerald-400 rounded-xl font-bold text-xs hover:bg-emerald-100 transition-all disabled:opacity-50"
                                >
                                  {isSummarizingWatchdog[sub.id] ? <Activity className="animate-spin" size={14} /> : <Cpu size={14} />}
                                  {isSummarizingWatchdog[sub.id] ? 'Summarizing...' : 'AI Summary'}
                                </button>
                                <button className="p-2 text-slate-400 hover:text-rose-500 transition-all">
                                  <Trash2 size={18} />
                                </button>
                              </div>
                            </div>
                            {watchdogSummaries[sub.id] && (
                              <motion.div 
                                initial={{ opacity: 0, height: 0 }}
                                animate={{ opacity: 1, height: 'auto' }}
                                className="bg-slate-50 dark:bg-slate-800/50 p-6 rounded-3xl border border-slate-100 dark:border-slate-800 ml-12"
                              >
                                <div className="flex justify-between items-center mb-4">
                                  <h5 className="font-bold text-slate-900 dark:text-slate-100 flex items-center gap-2 text-sm">
                                    <Zap size={16} className="text-amber-500" /> Latest AI Update
                                  </h5>
                                  <button 
                                    onClick={() => handleSpeak(watchdogSummaries[sub.id])}
                                    className={`flex items-center gap-2 px-3 py-1 rounded-lg font-bold transition-all text-[10px] ${isSpeaking ? 'bg-rose-100 text-rose-600' : 'bg-emerald-100 text-emerald-600'}`}
                                  >
                                    {isSpeaking ? <X size={12} /> : <Volume2 size={12} />}
                                    {isSpeaking ? 'Stop' : 'Listen'}
                                  </button>
                                </div>
                                <div className="text-xs text-slate-600 dark:text-slate-400 leading-relaxed markdown-body">
                                  <Markdown>{watchdogSummaries[sub.id]}</Markdown>
                                </div>
                              </motion.div>
                            )}
                          </div>
                        ))
                      )}
                    </div>
                  </div>
                </div>
              </motion.div>
            )}

            {activeTab === 'client-portal' && (
              <motion.div 
                key="client"
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                className="max-w-5xl mx-auto space-y-8"
              >
                <div className="bg-slate-900 p-10 rounded-[40px] text-white relative overflow-hidden">
                  <div className="relative z-10">
                    <h2 className="text-4xl font-bold">Welcome back, {user?.name}</h2>
                    <p className="text-slate-400 mt-2">Track your case status and upcoming hearings in real-time.</p>
                  </div>
                  <div className="absolute top-0 right-0 w-64 h-64 bg-emerald-500/10 blur-[100px] rounded-full" />
                </div>

                <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
                  <div className="bg-white p-6 rounded-3xl border border-slate-100 shadow-xl">
                    <p className="text-sm text-slate-500 font-bold uppercase tracking-widest">Active Cases</p>
                    <h3 className="text-4xl font-bold text-slate-900 mt-2">{clientCases.length}</h3>
                  </div>
                  <div className="bg-white p-6 rounded-3xl border border-slate-100 shadow-xl">
                    <p className="text-sm text-slate-500 font-bold uppercase tracking-widest">Next Hearing</p>
                    <h3 className="text-xl font-bold text-emerald-600 mt-2">
                      {clientCases.length > 0 ? clientCases[0].next_hearing : 'No upcoming'}
                    </h3>
                  </div>
                  <div className="bg-white p-6 rounded-3xl border border-slate-100 shadow-xl">
                    <p className="text-sm text-slate-500 font-bold uppercase tracking-widest">Pending Documents</p>
                    <h3 className="text-4xl font-bold text-rose-500 mt-2">2</h3>
                  </div>
                </div>

                <div className="bg-white rounded-[40px] border border-slate-100 shadow-2xl overflow-hidden">
                  <div className="p-8 border-b border-slate-100 flex justify-between items-center">
                    <h3 className="text-2xl font-bold text-slate-900">My Cases</h3>
                    <button className="text-emerald-600 font-bold flex items-center gap-2">
                      <Download size={18} /> Export Report
                    </button>
                  </div>
                  <div className="p-8">
                    {isClientLoading ? (
                      <div className="py-20 flex flex-col items-center justify-center text-slate-400 space-y-4">
                        <Activity className="animate-spin" size={48} />
                        <p>Fetching your case details...</p>
                      </div>
                    ) : clientCases.length === 0 ? (
                      <div className="py-20 text-center text-slate-400">
                        <Briefcase size={64} className="mx-auto mb-4 opacity-10" />
                        <p>No cases found for your account.</p>
                      </div>
                    ) : (
                      <div className="space-y-6">
                        {clientCases.map((c, i) => (
                          <div key={i} className="flex items-center justify-between p-6 bg-slate-50 rounded-3xl border border-slate-100 hover:border-emerald-200 transition-all">
                            <div className="flex items-center gap-6">
                              <div className="w-16 h-16 rounded-2xl bg-white flex items-center justify-center text-emerald-600 shadow-sm">
                                <Scale size={28} />
                              </div>
                              <div>
                                <h4 className="text-xl font-bold text-slate-900">{c.case_title}</h4>
                                <p className="text-sm text-slate-500">{c.court_name} | CNR: {c.cnr_number}</p>
                              </div>
                            </div>
                            <div className="text-right flex flex-col items-end gap-2">
                              <span className="px-4 py-2 bg-emerald-100 text-emerald-700 rounded-full text-xs font-bold uppercase tracking-widest">
                                {c.status}
                              </span>
                              <p className="text-xs text-slate-400">Next Hearing: {c.next_hearing}</p>
                              {hasPermission('upload_documents') && (
                                <label className="cursor-pointer bg-white border border-slate-200 text-slate-600 px-3 py-1.5 rounded-xl text-xs font-bold hover:bg-slate-50 transition-all flex items-center gap-2 mt-1 shadow-sm">
                                  <Plus size={14} /> Upload Document
                                  <input type="file" className="hidden" onChange={handleFileUpload} />
                                </label>
                              )}
                            </div>
                          </div>
                        ))}
                      </div>
                    )}
                  </div>
                </div>
              </motion.div>
            )}

            {activeTab === 'analytics' && (
              <motion.div 
                key="analytics"
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                className="space-y-8"
              >
                <h2 className="text-3xl font-bold">Platform Analytics</h2>
                <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
                  <StatCard label="Cases Completed" value={cases.filter(c => c.status === 'Completed').length.toString()} trend={10} icon={FileCheck} />
                  <StatCard label="Active Cases" value={cases.filter(c => c.status === 'Active').length.toString()} trend={15} icon={Activity} />
                  <StatCard label="Contracts" value={contracts.length.toString()} trend={8} icon={CreditCard} />
                  <StatCard label="Team Members" value={teamMembers.length.toString()} icon={Users} />
                </div>
                <div className="bg-white p-8 rounded-2xl border border-slate-100 shadow-sm">
                  <h3 className="font-bold text-lg mb-6">Performance Metrics</h3>
                  <div className="space-y-4">
                    {[
                      { label: 'Total Cases Managed', value: cases.length.toString() },
                      { label: 'Active Contracts', value: contracts.filter(c => c.status === 'Active').length.toString() },
                      { label: 'Team Size', value: teamMembers.length.toString() },
                      { label: 'Documents in Repo', value: recentDocuments.length.toString() },
                      { label: 'Success rate', value: '89%' },
                    ].map((m, i) => (
                      <div key={i} className="flex justify-between items-center py-3 border-b border-slate-50 last:border-0">
                        <span className="text-slate-600">{m.label}</span>
                        <span className="font-bold text-emerald-600">{m.value}</span>
                      </div>
                    ))}
                  </div>
                </div>
              </motion.div>
            )}

            {!['dashboard', 'cases', 'ecourts', 'contracts', 'documents', 'team', 'analytics', 'settings', 'ai', 'ai-chat', 'innovation', 'client-portal', 'conflict-checker', 'watchdog', 'student-hub', 'compliance-audit', 'research', 'drafting', 'clients'].includes(activeTab) && (
              <motion.div 
                key="not-found"
                initial={{ opacity: 0, scale: 0.95 }}
                animate={{ opacity: 1, scale: 1 }}
                className="flex flex-col items-center justify-center py-20 text-center space-y-6"
              >
                <div className="w-32 h-32 bg-slate-100 dark:bg-slate-800 text-slate-300 dark:text-slate-600 rounded-full flex items-center justify-center">
                  <AlertTriangle size={64} />
                </div>
                <div className="max-w-md">
                  <h2 className="text-4xl font-bold text-slate-900 dark:text-slate-100">404 - Page Not Found</h2>
                  <p className="text-slate-500 dark:text-slate-400 mt-2">The section you are looking for does not exist or has been moved.</p>
                </div>
                <button 
                  onClick={() => setActiveTab('dashboard')}
                  className="bg-emerald-600 text-white px-8 py-3 rounded-xl font-bold hover:bg-emerald-700 transition-all shadow-lg shadow-emerald-500/20"
                >
                  Return to Dashboard
                </button>
              </motion.div>
            )}

            {activeTab === 'ai' && (
              <motion.div 
                key="ai"
                initial={{ opacity: 0, scale: 0.95 }}
                animate={{ opacity: 1, scale: 1 }}
                className="max-w-6xl mx-auto space-y-6"
              >
                <div className="text-center mb-8">
                  <h2 className="text-3xl font-bold mb-2">Tandon AI Legal Suite</h2>
                  <p className="text-slate-500">Advanced legal intelligence powered by Gemini 3.1 Pro & Flash.</p>
                </div>

                <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
                  {/* AI Sidebar */}
                  <div className="col-span-12 lg:col-span-3 space-y-2 flex flex-wrap lg:flex-col gap-2 lg:gap-0">
                    <button onClick={() => setAiMode('chat')} className={`flex-1 lg:flex-none text-left px-4 py-3 rounded-xl flex items-center gap-3 transition-all ${aiMode === 'chat' ? 'bg-emerald-600 text-white shadow-lg' : 'bg-white hover:bg-slate-50 text-slate-600'}`}>
                      <BrainCircuit size={20} /> <span className="font-bold">Legal Chat</span>
                    </button>
                    <button onClick={() => setAiMode('search')} className={`flex-1 lg:flex-none text-left px-4 py-3 rounded-xl flex items-center gap-3 transition-all ${aiMode === 'search' ? 'bg-emerald-600 text-white shadow-lg' : 'bg-white hover:bg-slate-50 text-slate-600'}`}>
                      <Search size={20} /> <span className="font-bold">Case Law Search</span>
                    </button>
                    <button onClick={() => setAiMode('maps')} className={`flex-1 lg:flex-none text-left px-4 py-3 rounded-xl flex items-center gap-3 transition-all ${aiMode === 'maps' ? 'bg-emerald-600 text-white shadow-lg' : 'bg-white hover:bg-slate-50 text-slate-600'}`}>
                      <MapPin size={20} /> <span className="font-bold">Find Services</span>
                    </button>
                    <button onClick={() => setAiMode('vision')} className={`flex-1 lg:flex-none text-left px-4 py-3 rounded-xl flex items-center gap-3 transition-all ${aiMode === 'vision' ? 'bg-emerald-600 text-white shadow-lg' : 'bg-white hover:bg-slate-50 text-slate-600'}`}>
                      <ImageIcon size={20} /> <span className="font-bold">Evidence Analysis</span>
                    </button>
                    <button onClick={() => setAiMode('edit')} className={`flex-1 lg:flex-none text-left px-4 py-3 rounded-xl flex items-center gap-3 transition-all ${aiMode === 'edit' ? 'bg-emerald-600 text-white shadow-lg' : 'bg-white hover:bg-slate-50 text-slate-600'}`}>
                      <Zap size={20} /> <span className="font-bold">Image Editing</span>
                    </button>
                    <button onClick={() => setAiMode('video')} className={`flex-1 lg:flex-none text-left px-4 py-3 rounded-xl flex items-center gap-3 transition-all ${aiMode === 'video' ? 'bg-emerald-600 text-white shadow-lg' : 'bg-white hover:bg-slate-50 text-slate-600'}`}>
                      <Video size={20} /> <span className="font-bold">Video Reconstruction</span>
                    </button>
                    <button onClick={() => setAiMode('audio')} className={`flex-1 lg:flex-none text-left px-4 py-3 rounded-xl flex items-center gap-3 transition-all ${aiMode === 'audio' ? 'bg-emerald-600 text-white shadow-lg' : 'bg-white hover:bg-slate-50 text-slate-600'}`}>
                      <Mic size={20} /> <span className="font-bold">Transcription</span>
                    </button>
                    <button onClick={() => setAiMode('tts')} className={`flex-1 lg:flex-none text-left px-4 py-3 rounded-xl flex items-center gap-3 transition-all ${aiMode === 'tts' ? 'bg-emerald-600 text-white shadow-lg' : 'bg-white hover:bg-slate-50 text-slate-600'}`}>
                      <Volume2 size={20} /> <span className="font-bold">Read Aloud</span>
                    </button>
                  </div>

                  {/* AI Content Area */}
                  <div className="col-span-12 lg:col-span-9 bg-white rounded-2xl shadow-xl border border-slate-100 overflow-hidden flex flex-col min-h-[600px]">
                    <div className="p-6 bg-slate-50 border-b border-slate-100 flex justify-between items-center">
                      <div className="flex items-center gap-2 text-slate-700">
                        {aiMode === 'chat' && <><BrainCircuit size={20} className="text-emerald-600" /> <span className="font-bold">Legal Consultant (Thinking Mode)</span></>}
                        {aiMode === 'search' && <><Search size={20} className="text-emerald-600" /> <span className="font-bold">Search Grounding</span></>}
                        {aiMode === 'maps' && <><MapPin size={20} className="text-emerald-600" /> <span className="font-bold">Maps Grounding</span></>}
                        {aiMode === 'vision' && <><ImageIcon size={20} className="text-emerald-600" /> <span className="font-bold">Visual Evidence</span></>}
                        {aiMode === 'edit' && <><Zap size={20} className="text-emerald-600" /> <span className="font-bold">Image Editing</span></>}
                        {aiMode === 'video' && <><Video size={20} className="text-emerald-600" /> <span className="font-bold">Veo Video Generator</span></>}
                        {aiMode === 'audio' && <><Mic size={20} className="text-emerald-600" /> <span className="font-bold">Audio Transcription</span></>}
                        {aiMode === 'tts' && <><Volume2 size={20} className="text-emerald-600" /> <span className="font-bold">Text-to-Speech</span></>}
                      </div>
                      <div className="flex items-center gap-2">
                        {!hasApiKey && (aiMode === 'video' || aiMode === 'vision') && (
                          <button 
                            onClick={async () => {
                              if (window.aistudio) {
                                await window.aistudio.openSelectKey();
                                setHasApiKey(true);
                              }
                            }}
                            className="px-3 py-1.5 rounded-lg text-xs font-bold bg-amber-50 text-amber-700 hover:bg-amber-100 transition-all flex items-center gap-2 border border-amber-200"
                          >
                            <Lock size={12} /> Setup API Key
                          </button>
                        )}
                        {chatHistory.length > 0 && (
                          <>
                            <div className="relative">
                              <button onClick={() => setShowExportMenu(!showExportMenu)} className="p-2 text-slate-500 hover:text-emerald-600 hover:bg-emerald-50 rounded-lg transition-all" title="Export Chat">
                                <Download size={18} />
                              </button>
                              {showExportMenu && (
                                <div className="absolute right-0 mt-2 w-32 bg-white rounded-xl shadow-xl border border-slate-100 py-2 z-50">
                                  <button onClick={() => { handleExportChat('txt'); setShowExportMenu(false); }} className="w-full text-left px-4 py-2 text-sm text-slate-700 hover:bg-slate-50">Export as TXT</button>
                                  <button onClick={() => { handleExportChat('json'); setShowExportMenu(false); }} className="w-full text-left px-4 py-2 text-sm text-slate-700 hover:bg-slate-50">Export as JSON</button>
                                  <button onClick={() => { handleExportChat('pdf'); setShowExportMenu(false); }} className="w-full text-left px-4 py-2 text-sm text-slate-700 hover:bg-slate-50">Export as PDF</button>
                                  <button onClick={() => { handleExportChat('csv'); setShowExportMenu(false); }} className="w-full text-left px-4 py-2 text-sm text-slate-700 hover:bg-slate-50">Export as CSV</button>
                                  <button onClick={() => { handleExportChat('md'); setShowExportMenu(false); }} className="w-full text-left px-4 py-2 text-sm text-slate-700 hover:bg-slate-50">Export as MD</button>
                                  <button onClick={() => { handleCopyChat(); setShowExportMenu(false); }} className="w-full text-left px-4 py-2 text-sm text-slate-700 hover:bg-slate-50 border-t border-slate-100">Copy All</button>
                                </div>
                              )}
                            </div>
                            <button onClick={handleClearChat} className="p-2 text-slate-500 hover:text-rose-600 hover:bg-rose-50 rounded-lg transition-all" title="Clear History">
                              <Trash2 size={18} />
                            </button>
                          </>
                        )}
                        {aiMode === 'chat' && <span className="text-xs bg-emerald-100 text-emerald-700 px-2 py-1 rounded-full font-bold">Gemini 3.1 Pro</span>}
                      </div>
                    </div>

                    <div className="flex-1 p-6 overflow-y-auto bg-slate-50/50 space-y-6">
                      {chatHistory.length === 0 && !isAiLoading && (
                        <div className="flex flex-col items-center justify-center h-full text-slate-300 gap-4">
                          <Cpu size={64} />
                          <p>Select a tool and enter a prompt to begin.</p>
                        </div>
                      )}

                      {chatHistory.map((msg) => (
                        <div key={msg.id} className={`flex ${msg.role === 'user' ? 'justify-end' : 'justify-start'}`}>
                          <div className={`max-w-[80%] p-4 rounded-2xl relative ${
                            msg.role === 'user' 
                              ? 'bg-emerald-600 text-white rounded-br-none' 
                              : msg.isError
                                ? 'bg-rose-50 border border-rose-200 text-rose-700 rounded-bl-none shadow-sm'
                                : 'bg-white border border-slate-200 text-slate-700 rounded-bl-none shadow-sm'
                          }`}>
                            {msg.isError && (
                              <button 
                                onClick={() => setChatHistory(prev => prev.filter(m => m.id !== msg.id))}
                                className="absolute top-2 right-2 p-1 text-rose-400 hover:text-rose-600 hover:bg-rose-100 rounded-md transition-colors"
                                title="Dismiss Error"
                              >
                                <X size={14} />
                              </button>
                            )}
                            {msg.type === 'text' && msg.role === 'ai' && !msg.isError && <ChatMessageContent content={msg.content} />}
                            {msg.type === 'text' && (msg.role === 'user' || msg.isError) && <div className={`whitespace-pre-wrap leading-relaxed ${msg.isError ? 'pr-6' : ''}`}>{msg.content}</div>}
                            {msg.type === 'image' && <img src={msg.content} alt="AI Generated" className="rounded-lg max-w-full shadow-md" />}
                            {msg.type === 'video' && <video src={msg.content} controls className="rounded-lg max-w-full shadow-md" />}
                            {msg.type === 'audio' && <audio src={msg.content} controls className="w-full mt-2" />}
                            <div className="flex items-center justify-between mt-2">
                              <p className={`text-[10px] ${msg.role === 'user' ? 'text-emerald-200' : msg.isError ? 'text-rose-400' : 'text-slate-400'}`}>
                                {msg.timestamp.toLocaleTimeString()}
                              </p>
                              {msg.role === 'ai' && !msg.isError && (
                                <div className="flex gap-1">
                                  <button 
                                    onClick={() => setChatHistory(prev => prev.map(m => m.id === msg.id ? { ...m, feedback: m.feedback === 'up' ? undefined : 'up' } : m))}
                                    className={`p-1 rounded transition-colors ${msg.feedback === 'up' ? 'text-emerald-600 bg-emerald-50' : 'text-slate-400 hover:text-emerald-600 hover:bg-emerald-50'}`}
                                    title="Helpful"
                                  >
                                    <ThumbsUp size={12} />
                                  </button>
                                  <button 
                                    onClick={() => setChatHistory(prev => prev.map(m => m.id === msg.id ? { ...m, feedback: m.feedback === 'down' ? undefined : 'down' } : m))}
                                    className={`p-1 rounded transition-colors ${msg.feedback === 'down' ? 'text-rose-600 bg-rose-50' : 'text-slate-400 hover:text-rose-600 hover:bg-rose-50'}`}
                                    title="Not Helpful"
                                  >
                                    <ThumbsDown size={12} />
                                  </button>
                                </div>
                              )}
                            </div>
                          </div>
                        </div>
                      ))}

                      {isAiLoading && (
                        <div className="flex justify-start">
                          <div className="bg-white border border-slate-200 p-4 rounded-2xl rounded-bl-none shadow-sm flex items-center gap-3">
                            <motion.div animate={{ rotate: 360 }} transition={{ repeat: Infinity, duration: 2, ease: "linear" }}>
                              <Cpu size={20} className="text-emerald-600" />
                            </motion.div>
                            <span className="text-sm text-slate-500 font-medium">Processing...</span>
                          </div>
                        </div>
                      )}
                    </div>

                    <div className="p-6 bg-white border-t border-slate-100">
                      {(aiMode === 'vision' || aiMode === 'edit' || aiMode === 'video' || aiMode === 'audio') && (
                        <div className="mb-4">
                          <label className="block text-sm font-bold text-slate-700 mb-2">Upload File (Image/Audio)</label>
                          <input type="file" onChange={handleFileChange} className="block w-full text-sm text-slate-500 file:mr-4 file:py-2 file:px-4 file:rounded-full file:border-0 file:text-sm file:font-semibold file:bg-emerald-50 file:text-emerald-700 hover:file:bg-emerald-100"/>
                          {aiFilePreview && aiMode !== 'audio' && (
                            <img src={aiFilePreview} alt="Preview" className="mt-2 h-20 w-20 object-cover rounded-lg border border-slate-200" />
                          )}
                        </div>
                      )}
                      
                      <div className="flex flex-col gap-4">
                        <div className="flex-1 bg-slate-50 border border-slate-200 rounded-xl focus-within:ring-2 focus-within:ring-emerald-500 transition-all overflow-hidden flex flex-col h-32">
                          <div className="flex items-center gap-1 p-2 border-b border-slate-200 bg-white">
                            <button 
                              onClick={() => {
                                const textarea = document.getElementById('ai-prompt-input') as HTMLTextAreaElement;
                                if (textarea) {
                                  const start = textarea.selectionStart;
                                  const end = textarea.selectionEnd;
                                  const text = textarea.value;
                                  setAiPrompt(text.substring(0, start) + '**' + text.substring(start, end) + '**' + text.substring(end));
                                  setTimeout(() => {
                                    textarea.focus();
                                    textarea.setSelectionRange(start + 2, end + 2);
                                  }, 0);
                                }
                              }}
                              className="p-1.5 text-slate-500 hover:text-emerald-600 hover:bg-emerald-50 rounded-md transition-colors" title="Bold"
                            >
                              <Bold size={16} />
                            </button>
                            <button 
                              onClick={() => {
                                const textarea = document.getElementById('ai-prompt-input') as HTMLTextAreaElement;
                                if (textarea) {
                                  const start = textarea.selectionStart;
                                  const end = textarea.selectionEnd;
                                  const text = textarea.value;
                                  setAiPrompt(text.substring(0, start) + '*' + text.substring(start, end) + '*' + text.substring(end));
                                  setTimeout(() => {
                                    textarea.focus();
                                    textarea.setSelectionRange(start + 1, end + 1);
                                  }, 0);
                                }
                              }}
                              className="p-1.5 text-slate-500 hover:text-emerald-600 hover:bg-emerald-50 rounded-md transition-colors" title="Italic"
                            >
                              <Italic size={16} />
                            </button>
                            <div className="w-px h-4 bg-slate-200 mx-1"></div>
                            <button 
                              onClick={() => {
                                const textarea = document.getElementById('ai-prompt-input') as HTMLTextAreaElement;
                                if (textarea) {
                                  const start = textarea.selectionStart;
                                  const end = textarea.selectionEnd;
                                  const text = textarea.value;
                                  const lines = text.substring(start, end).split('\n');
                                  const newText = lines.map(l => '- ' + l).join('\n');
                                  setAiPrompt(text.substring(0, start) + (start === end ? '- ' : newText) + text.substring(end));
                                  setTimeout(() => {
                                    textarea.focus();
                                    textarea.setSelectionRange(start + 2, end + (start === end ? 2 : newText.length));
                                  }, 0);
                                }
                              }}
                              className="p-1.5 text-slate-500 hover:text-emerald-600 hover:bg-emerald-50 rounded-md transition-colors" title="Bullet List"
                            >
                              <List size={16} />
                            </button>
                            <button 
                              onClick={() => {
                                const textarea = document.getElementById('ai-prompt-input') as HTMLTextAreaElement;
                                if (textarea) {
                                  const start = textarea.selectionStart;
                                  const end = textarea.selectionEnd;
                                  const text = textarea.value;
                                  const lines = text.substring(start, end).split('\n');
                                  const newText = lines.map((l, i) => `${i + 1}. ` + l).join('\n');
                                  setAiPrompt(text.substring(0, start) + (start === end ? '1. ' : newText) + text.substring(end));
                                  setTimeout(() => {
                                    textarea.focus();
                                    textarea.setSelectionRange(start + 3, end + (start === end ? 3 : newText.length));
                                  }, 0);
                                }
                              }}
                              className="p-1.5 text-slate-500 hover:text-emerald-600 hover:bg-emerald-50 rounded-md transition-colors" title="Numbered List"
                            >
                              <ListOrdered size={16} />
                            </button>
                          </div>
                          <textarea 
                            id="ai-prompt-input"
                            value={aiPrompt}
                            onChange={(e) => setAiPrompt(e.target.value)}
                            placeholder={aiMode === 'chat' ? "Ask a complex legal question..." : aiMode === 'search' ? "Search for case law..." : "Enter prompt..."}
                            className="flex-1 p-4 bg-transparent outline-none resize-none"
                          />
                        </div>
                        <div className="flex justify-between items-center text-xs text-slate-400 px-1">
                          <span>{aiPrompt.trim() ? aiPrompt.trim().split(/\s+/).length : 0} words</span>
                          <span>{aiPrompt.length} characters</span>
                        </div>
                        <button 
                          onClick={handleAiAction}
                          disabled={isAiLoading || (!aiPrompt && !aiFile)}
                          className="bg-emerald-600 text-white py-3 px-6 rounded-xl font-bold shadow-lg shadow-emerald-200 hover:bg-emerald-700 disabled:opacity-50 transition-all flex items-center justify-center gap-2"
                        >
                          {isAiLoading ? <Activity className="animate-spin" /> : <Zap size={20} />}
                          <span>Generate Response</span>
                        </button>
                      </div>
                    </div>
                  </div>
                </div>
              </motion.div>
            )}

            {activeTab === 'ai-chat' && (
              <motion.div 
                key="ai-chat"
                initial={{ opacity: 0, scale: 0.95 }}
                animate={{ opacity: 1, scale: 1 }}
                className="max-w-4xl mx-auto space-y-6 h-[calc(100vh-8rem)] flex flex-col"
              >
                <div className="text-center mb-2">
                  <h2 className="text-3xl font-bold mb-2">AI Legal Research Chat</h2>
                  <p className="text-slate-500">Direct interaction with Gemini 3.1 Pro for complex legal inquiries.</p>
                </div>

                <div className="bg-white rounded-2xl shadow-xl border border-slate-100 overflow-hidden flex flex-col flex-1">
                  <div className="p-4 bg-slate-50 border-b border-slate-100 flex justify-between items-center">
                    <div className="flex items-center gap-2 text-slate-700">
                      <BrainCircuit size={20} className="text-emerald-600" /> <span className="font-bold">Legal Consultant (Thinking Mode)</span>
                    </div>
                    <div className="flex items-center gap-2">
                      {chatHistory.length > 0 && (
                        <>
                          <div className="relative">
                            <button onClick={() => setShowExportMenu(!showExportMenu)} className="p-2 text-slate-500 hover:text-emerald-600 hover:bg-emerald-50 rounded-lg transition-all" title="Export Chat">
                              <Download size={18} />
                            </button>
                            {showExportMenu && (
                              <div className="absolute right-0 mt-2 w-32 bg-white rounded-xl shadow-xl border border-slate-100 py-2 z-50">
                                <button onClick={() => { handleExportChat('txt'); setShowExportMenu(false); }} className="w-full text-left px-4 py-2 text-sm text-slate-700 hover:bg-slate-50">Export as TXT</button>
                                <button onClick={() => { handleExportChat('json'); setShowExportMenu(false); }} className="w-full text-left px-4 py-2 text-sm text-slate-700 hover:bg-slate-50">Export as JSON</button>
                                <button onClick={() => { handleExportChat('pdf'); setShowExportMenu(false); }} className="w-full text-left px-4 py-2 text-sm text-slate-700 hover:bg-slate-50">Export as PDF</button>
                                <button onClick={() => { handleExportChat('csv'); setShowExportMenu(false); }} className="w-full text-left px-4 py-2 text-sm text-slate-700 hover:bg-slate-50">Export as CSV</button>
                                <button onClick={() => { handleExportChat('md'); setShowExportMenu(false); }} className="w-full text-left px-4 py-2 text-sm text-slate-700 hover:bg-slate-50">Export as MD</button>
                                <button onClick={() => { handleCopyChat(); setShowExportMenu(false); }} className="w-full text-left px-4 py-2 text-sm text-slate-700 hover:bg-slate-50 border-t border-slate-100">Copy All</button>
                              </div>
                            )}
                          </div>
                          <button onClick={handleClearChat} className="p-2 text-slate-500 hover:text-rose-600 hover:bg-rose-50 rounded-lg transition-all" title="Clear History">
                            <Trash2 size={18} />
                          </button>
                        </>
                      )}
                      <span className="text-xs bg-emerald-100 text-emerald-700 px-2 py-1 rounded-full font-bold">Gemini 3.1 Pro</span>
                    </div>
                  </div>

                  <div className="flex-1 p-6 overflow-y-auto bg-slate-50/50 space-y-6">
                    {chatHistory.length === 0 && !isAiLoading && (
                      <div className="flex flex-col items-center justify-center h-full text-slate-300 gap-4">
                        <MessageSquare size={64} />
                        <p>Ask a legal question to begin your research.</p>
                      </div>
                    )}

                    {chatHistory.map((msg) => (
                      <div key={msg.id} className={`flex ${msg.role === 'user' ? 'justify-end' : 'justify-start'}`}>
                        <div className={`max-w-[80%] p-4 rounded-2xl relative ${
                          msg.role === 'user' 
                            ? 'bg-emerald-600 text-white rounded-br-none' 
                            : msg.isError
                              ? 'bg-rose-50 border border-rose-200 text-rose-700 rounded-bl-none shadow-sm'
                              : 'bg-white border border-slate-200 text-slate-700 rounded-bl-none shadow-sm'
                        }`}>
                          {msg.isError && (
                            <button 
                              onClick={() => setChatHistory(prev => prev.filter(m => m.id !== msg.id))}
                              className="absolute top-2 right-2 p-1 text-rose-400 hover:text-rose-600 hover:bg-rose-100 rounded-md transition-colors"
                              title="Dismiss Error"
                            >
                              <X size={14} />
                            </button>
                          )}
                          {msg.type === 'text' && msg.role === 'ai' && !msg.isError && <ChatMessageContent content={msg.content} />}
                          {msg.type === 'text' && (msg.role === 'user' || msg.isError) && <div className={`whitespace-pre-wrap leading-relaxed ${msg.isError ? 'pr-6' : ''}`}>{msg.content}</div>}
                          {msg.type === 'image' && <img src={msg.content} alt="AI Generated" className="rounded-lg max-w-full shadow-md" />}
                          {msg.type === 'video' && <video src={msg.content} controls className="rounded-lg max-w-full shadow-md" />}
                          {msg.type === 'audio' && <audio src={msg.content} controls className="w-full mt-2" />}
                          <div className="flex items-center justify-between mt-2">
                            <p className={`text-[10px] ${msg.role === 'user' ? 'text-emerald-200' : msg.isError ? 'text-rose-400' : 'text-slate-400'}`}>
                              {msg.timestamp.toLocaleTimeString()}
                            </p>
                            {msg.role === 'ai' && !msg.isError && (
                              <div className="flex gap-1">
                                <button 
                                  onClick={() => setChatHistory(prev => prev.map(m => m.id === msg.id ? { ...m, feedback: m.feedback === 'up' ? undefined : 'up' } : m))}
                                  className={`p-1 rounded transition-colors ${msg.feedback === 'up' ? 'text-emerald-600 bg-emerald-50' : 'text-slate-400 hover:text-emerald-600 hover:bg-emerald-50'}`}
                                  title="Helpful"
                                >
                                  <ThumbsUp size={12} />
                                </button>
                                <button 
                                  onClick={() => setChatHistory(prev => prev.map(m => m.id === msg.id ? { ...m, feedback: m.feedback === 'down' ? undefined : 'down' } : m))}
                                  className={`p-1 rounded transition-colors ${msg.feedback === 'down' ? 'text-rose-600 bg-rose-50' : 'text-slate-400 hover:text-rose-600 hover:bg-rose-50'}`}
                                  title="Not Helpful"
                                >
                                  <ThumbsDown size={12} />
                                </button>
                              </div>
                            )}
                          </div>
                        </div>
                      </div>
                    ))}

                    {isAiLoading && (
                      <div className="flex justify-start">
                        <div className="bg-white border border-slate-200 p-4 rounded-2xl rounded-bl-none shadow-sm flex items-center gap-3">
                          <motion.div animate={{ rotate: 360 }} transition={{ repeat: Infinity, duration: 2, ease: "linear" }}>
                            <Cpu size={20} className="text-emerald-600" />
                          </motion.div>
                          <span className="text-sm text-slate-500 font-medium">Processing...</span>
                        </div>
                      </div>
                    )}
                  </div>

                  <div className="p-4 bg-white border-t border-slate-100">
                    <div className="flex flex-col gap-4">
                      <div className="flex-1 bg-slate-50 border border-slate-200 rounded-xl focus-within:ring-2 focus-within:ring-emerald-500 transition-all overflow-hidden flex flex-col h-32">
                        <div className="flex items-center gap-1 p-2 border-b border-slate-200 bg-white">
                          <button 
                            onClick={() => {
                              const textarea = document.getElementById('ai-chat-prompt-input') as HTMLTextAreaElement;
                              if (textarea) {
                                const start = textarea.selectionStart;
                                const end = textarea.selectionEnd;
                                const text = textarea.value;
                                setAiPrompt(text.substring(0, start) + '**' + text.substring(start, end) + '**' + text.substring(end));
                                setTimeout(() => {
                                  textarea.focus();
                                  textarea.setSelectionRange(start + 2, end + 2);
                                }, 0);
                              }
                            }}
                            className="p-1.5 text-slate-500 hover:text-emerald-600 hover:bg-emerald-50 rounded-md transition-colors" title="Bold"
                          >
                            <Bold size={16} />
                          </button>
                          <button 
                            onClick={() => {
                              const textarea = document.getElementById('ai-chat-prompt-input') as HTMLTextAreaElement;
                              if (textarea) {
                                const start = textarea.selectionStart;
                                const end = textarea.selectionEnd;
                                const text = textarea.value;
                                setAiPrompt(text.substring(0, start) + '*' + text.substring(start, end) + '*' + text.substring(end));
                                setTimeout(() => {
                                  textarea.focus();
                                  textarea.setSelectionRange(start + 1, end + 1);
                                }, 0);
                              }
                            }}
                            className="p-1.5 text-slate-500 hover:text-emerald-600 hover:bg-emerald-50 rounded-md transition-colors" title="Italic"
                          >
                            <Italic size={16} />
                          </button>
                          <div className="w-px h-4 bg-slate-200 mx-1"></div>
                          <button 
                            onClick={() => {
                              const textarea = document.getElementById('ai-chat-prompt-input') as HTMLTextAreaElement;
                              if (textarea) {
                                const start = textarea.selectionStart;
                                const end = textarea.selectionEnd;
                                const text = textarea.value;
                                const lines = text.substring(start, end).split('\n');
                                const newText = lines.map(l => '- ' + l).join('\n');
                                setAiPrompt(text.substring(0, start) + (start === end ? '- ' : newText) + text.substring(end));
                                setTimeout(() => {
                                  textarea.focus();
                                  textarea.setSelectionRange(start + 2, end + (start === end ? 2 : newText.length));
                                }, 0);
                              }
                            }}
                            className="p-1.5 text-slate-500 hover:text-emerald-600 hover:bg-emerald-50 rounded-md transition-colors" title="Bullet List"
                          >
                            <List size={16} />
                          </button>
                          <button 
                            onClick={() => {
                              const textarea = document.getElementById('ai-chat-prompt-input') as HTMLTextAreaElement;
                              if (textarea) {
                                const start = textarea.selectionStart;
                                const end = textarea.selectionEnd;
                                const text = textarea.value;
                                const lines = text.substring(start, end).split('\n');
                                const newText = lines.map((l, i) => `${i + 1}. ` + l).join('\n');
                                setAiPrompt(text.substring(0, start) + (start === end ? '1. ' : newText) + text.substring(end));
                                setTimeout(() => {
                                  textarea.focus();
                                  textarea.setSelectionRange(start + 3, end + (start === end ? 3 : newText.length));
                                }, 0);
                              }
                            }}
                            className="p-1.5 text-slate-500 hover:text-emerald-600 hover:bg-emerald-50 rounded-md transition-colors" title="Numbered List"
                          >
                            <ListOrdered size={16} />
                          </button>
                        </div>
                        <textarea 
                          id="ai-chat-prompt-input"
                          value={aiPrompt}
                          onChange={(e) => setAiPrompt(e.target.value)}
                          placeholder="Ask a complex legal question..."
                          className="flex-1 p-4 bg-transparent outline-none resize-none"
                        />
                      </div>
                      <div className="flex justify-between items-center text-xs text-slate-400 px-1">
                        <span>{aiPrompt.trim() ? aiPrompt.trim().split(/\s+/).length : 0} words</span>
                        <span>{aiPrompt.length} characters</span>
                      </div>
                      <button 
                        onClick={handleAiAction}
                        disabled={isAiLoading || !aiPrompt}
                        className="bg-emerald-600 text-white py-3 px-6 rounded-xl font-bold shadow-lg shadow-emerald-200 hover:bg-emerald-700 disabled:opacity-50 transition-all flex items-center justify-center gap-2"
                      >
                        {isAiLoading ? <Activity className="animate-spin" /> : <Zap size={20} />}
                        <span>Generate Response</span>
                      </button>
                    </div>
                  </div>
                </div>
              </motion.div>
            )}

            {activeTab === 'compliance-audit' && user?.userType === 'corporate' && (
              <motion.div 
                key="compliance-audit"
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                exit={{ opacity: 0, y: -20 }}
                className="space-y-8"
              >
                <div className="flex justify-between items-end">
                  <div>
                    <h2 className="text-3xl font-bold text-slate-900">Compliance & Audit</h2>
                    <p className="text-slate-500 mt-1">Enterprise-grade regulatory tracking and audit trails.</p>
                  </div>
                  <div className="flex gap-3">
                    <button className="bg-white border border-slate-200 text-slate-600 px-4 py-2.5 rounded-xl font-bold hover:bg-slate-50 transition-all flex items-center gap-2">
                      <Download size={18} /> Export Audit Log
                    </button>
                    <button className="bg-emerald-600 text-white px-6 py-2.5 rounded-xl font-bold shadow-lg shadow-emerald-200 hover:bg-emerald-700 transition-all flex items-center gap-2">
                      <Plus size={18} /> New Compliance Check
                    </button>
                  </div>
                </div>

                <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
                  <div className="lg:col-span-2 space-y-8">
                    {/* Regulatory Watch */}
                    <div className="bg-white rounded-2xl border border-slate-100 shadow-sm overflow-hidden">
                      <div className="p-6 border-b border-slate-50 flex justify-between items-center bg-slate-50/50">
                        <div className="flex items-center gap-3">
                          <div className="p-2 bg-emerald-100 text-emerald-600 rounded-lg">
                            <Activity size={20} />
                          </div>
                          <h3 className="font-bold text-lg">Regulatory Watch (RBI/SEBI)</h3>
                        </div>
                        <span className="text-xs font-bold text-emerald-600 bg-emerald-50 px-3 py-1 rounded-full">Live Updates</span>
                      </div>
                      <div className="divide-y divide-slate-50">
                        {[
                          { title: 'RBI Master Circular on Digital Lending', date: 'Feb 25, 2026', impact: 'High', status: 'Reviewing' },
                          { title: 'SEBI Amendment to Listing Obligations', date: 'Feb 20, 2026', impact: 'Medium', status: 'Compliant' },
                          { title: 'New Data Protection Rules (DPDP)', date: 'Feb 15, 2026', impact: 'Critical', status: 'Action Required' },
                        ].map((item, idx) => (
                          <div key={idx} className="p-6 flex items-center justify-between hover:bg-slate-50 transition-all">
                            <div className="flex items-center gap-4">
                              <div className={`w-2 h-2 rounded-full ${
                                item.impact === 'Critical' ? 'bg-rose-500' : 
                                item.impact === 'High' ? 'bg-amber-500' : 'bg-emerald-500'
                              }`} />
                              <div>
                                <p className="font-bold text-slate-900">{item.title}</p>
                                <p className="text-xs text-slate-500">{item.date} • Impact: {item.impact}</p>
                              </div>
                            </div>
                            <span className={`text-xs font-bold px-3 py-1 rounded-full ${
                              item.status === 'Compliant' ? 'bg-emerald-100 text-emerald-700' :
                              item.status === 'Action Required' ? 'bg-rose-100 text-rose-700' : 'bg-slate-100 text-slate-600'
                            }`}>
                              {item.status}
                            </span>
                          </div>
                        ))}
                      </div>
                    </div>

                    {/* Audit Trail */}
                    <div className="bg-white rounded-2xl border border-slate-100 shadow-sm overflow-hidden">
                      <div className="p-6 border-b border-slate-50 bg-slate-50/50">
                        <h3 className="font-bold text-lg">System Audit Trail</h3>
                      </div>
                      <div className="p-0">
                        <TableRow gridClass="grid-cols-4" cells={['User', 'Action', 'Resource', 'Timestamp']} />
                        <TableRow gridClass="grid-cols-4" cells={['Admin_User_01', 'Document Export', 'NDA_Template_Final', '10:45 AM']} />
                        <TableRow gridClass="grid-cols-4" cells={['Legal_Lead_AX', 'Contract Approval', 'Loan_Agreement_v2', '09:30 AM']} />
                        <TableRow gridClass="grid-cols-4" cells={['System_Bot', 'Auto-Scan Conflict', 'Case_#9982', '08:15 AM']} />
                      </div>
                    </div>
                  </div>

                  <div className="space-y-8">
                    {/* Compliance Score */}
                    <div className="bg-white rounded-2xl border border-slate-100 shadow-sm p-6 text-center">
                      <h3 className="text-slate-500 text-sm font-bold uppercase tracking-widest mb-6">Compliance Health</h3>
                      <div className="relative w-32 h-32 mx-auto mb-6">
                        <svg className="w-full h-full transform -rotate-90">
                          <circle cx="64" cy="64" r="58" stroke="currentColor" strokeWidth="12" fill="transparent" className="text-slate-100" />
                          <circle cx="64" cy="64" r="58" stroke="currentColor" strokeWidth="12" fill="transparent" strokeDasharray="364" strokeDashoffset="36" className="text-emerald-500" />
                        </svg>
                        <div className="absolute inset-0 flex flex-col items-center justify-center">
                          <span className="text-3xl font-bold text-slate-900">92</span>
                          <span className="text-[10px] text-slate-400 font-bold uppercase">Score</span>
                        </div>
                      </div>
                      <p className="text-sm text-slate-600 mb-6">Your organization is currently <strong>92% compliant</strong> with active regulations.</p>
                      <button className="w-full py-3 bg-slate-900 text-white rounded-xl font-bold hover:bg-slate-800 transition-all">
                        Run Full Audit
                      </button>
                    </div>

                    {/* Risk Alerts */}
                    <div className="bg-rose-50 rounded-2xl p-6 border border-rose-100">
                      <div className="flex items-center gap-2 text-rose-600 mb-4">
                        <AlertCircle size={20} />
                        <h3 className="font-bold">Critical Risk Alerts</h3>
                      </div>
                      <div className="space-y-4">
                        <div className="bg-white p-4 rounded-xl border border-rose-100 shadow-sm">
                          <p className="text-xs font-bold text-rose-600 mb-1">CONTRACT EXPIRED</p>
                          <p className="text-sm font-bold text-slate-900">Vendor Agreement: Axis IT Services</p>
                        </div>
                        <div className="bg-white p-4 rounded-xl border border-rose-100 shadow-sm">
                          <p className="text-xs font-bold text-rose-600 mb-1">MISSING KYC</p>
                          <p className="text-sm font-bold text-slate-900">Case #8821: High Value Transaction</p>
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
              </motion.div>
            )}

            {activeTab === 'student-hub' && user?.userType === 'student' && (
              <motion.div 
                key="student-hub"
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                className="space-y-8"
              >
                <div className="flex justify-between items-end">
                  <div>
                    <h2 className="text-3xl font-bold text-slate-900">Student Hub</h2>
                    <p className="text-slate-500 mt-1">Exclusive resources and tools for law students.</p>
                  </div>
                  {user?.isStudentVerified ? (
                    <div className="flex items-center gap-2 bg-emerald-100 text-emerald-700 px-4 py-2 rounded-full text-sm font-bold">
                      <CheckCircle2 size={16} /> Verified Student
                    </div>
                  ) : (
                    <button 
                      onClick={() => setIsVerifyingStudent(true)}
                      className="bg-emerald-600 text-white px-6 py-3 rounded-xl font-bold shadow-xl shadow-emerald-500/20 hover:bg-emerald-700 transition-all flex items-center gap-2"
                    >
                      <ShieldCheck size={20} /> Verify Status
                    </button>
                  )}
                </div>

                {!user?.isStudentVerified ? (
                  <div className="bg-white p-12 rounded-3xl border border-slate-100 shadow-sm text-center space-y-6">
                    <div className="w-24 h-24 bg-slate-100 text-slate-400 rounded-full flex items-center justify-center mx-auto">
                      <Lock size={48} />
                    </div>
                    <div className="max-w-md mx-auto">
                      <h3 className="text-2xl font-bold text-slate-900">Student Hub is Locked</h3>
                      <p className="text-slate-500 mt-2">Please verify your law student status to access free AI research, document templates, and educational resources.</p>
                    </div>
                    <button 
                      onClick={() => setIsVerifyingStudent(true)}
                      className="bg-emerald-600 text-white px-8 py-4 rounded-xl font-bold shadow-xl shadow-emerald-500/20 hover:bg-emerald-700 transition-all active:scale-95"
                    >
                      Start Verification
                    </button>
                  </div>
                ) : (
                  <div className="space-y-8">
                    <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
                    <div className="bg-white p-8 rounded-3xl border border-slate-100 shadow-sm hover:shadow-md transition-all group">
                      <div className="w-14 h-14 bg-emerald-100 text-emerald-600 rounded-2xl flex items-center justify-center mb-6 group-hover:scale-110 transition-transform">
                        <BrainCircuit size={28} />
                      </div>
                      <h3 className="text-xl font-bold text-slate-900 mb-2">Free AI Research</h3>
                      <p className="text-slate-500 text-sm mb-6 leading-relaxed">Unlimited access to our advanced legal AI for case research, brief drafting, and memo generation.</p>
                      <button 
                        onClick={() => { setActiveTab('ai-chat'); setAiMode('chat'); }}
                        className="w-full py-3 bg-slate-50 text-slate-600 rounded-xl font-bold hover:bg-emerald-50 hover:text-emerald-600 transition-all"
                      >
                        Launch AI Chat
                      </button>
                    </div>

                    <div className="bg-white p-8 rounded-3xl border border-slate-100 shadow-sm hover:shadow-md transition-all group">
                      <div className="w-14 h-14 bg-blue-100 text-blue-600 rounded-2xl flex items-center justify-center mb-6 group-hover:scale-110 transition-transform">
                        <FileText size={28} />
                      </div>
                      <h3 className="text-xl font-bold text-slate-900 mb-2">Template Library</h3>
                      <p className="text-slate-500 text-sm mb-6 leading-relaxed">Access 500+ professional legal templates including moot court briefs, internships applications, and research memos.</p>
                      <button 
                        onClick={() => setActiveTab('documents')}
                        className="w-full py-3 bg-slate-50 text-slate-600 rounded-xl font-bold hover:bg-blue-50 hover:text-blue-600 transition-all"
                      >
                        Browse Templates
                      </button>
                    </div>

                    <div className="bg-white p-8 rounded-3xl border border-slate-100 shadow-sm hover:shadow-md transition-all group">
                      <div className="w-14 h-14 bg-purple-100 text-purple-600 rounded-2xl flex items-center justify-center mb-6 group-hover:scale-110 transition-transform">
                        <Users size={28} />
                      </div>
                      <h3 className="text-xl font-bold text-slate-900 mb-2">Mentorship Network</h3>
                      <p className="text-slate-500 text-sm mb-6 leading-relaxed">Connect with senior partners and legal experts for career guidance and internship opportunities.</p>
                      <button className="w-full py-3 bg-slate-50 text-slate-600 rounded-xl font-bold hover:bg-purple-50 hover:text-purple-600 transition-all">
                        Find a Mentor
                      </button>
                    </div>
                  </div>

                  {/* Moot Court History */}
                  <div className="bg-white dark:bg-slate-900 rounded-3xl border border-slate-100 dark:border-slate-800 shadow-sm overflow-hidden">
                    <div className="p-8 border-b border-slate-50 dark:border-slate-800 flex justify-between items-center">
                      <div>
                        <h3 className="text-2xl font-bold text-slate-900 dark:text-slate-100">Moot Court History</h3>
                        <p className="text-slate-500 dark:text-slate-400 text-sm mt-1">Track your past performances and achievements in moot court competitions.</p>
                      </div>
                      <button 
                        onClick={() => setIsAddingMootPerformance(true)}
                        className="bg-emerald-50 dark:bg-emerald-900/20 text-emerald-600 dark:text-emerald-400 px-4 py-2 rounded-xl text-sm font-bold hover:bg-emerald-100 dark:hover:bg-emerald-900/40 transition-all flex items-center gap-2"
                      >
                        <Plus size={18} /> Add Performance
                      </button>
                    </div>
                    <div className="overflow-x-auto">
                      <table className="w-full text-left">
                        <thead>
                          <tr className="bg-slate-50 dark:bg-slate-800/50 border-b border-slate-100 dark:border-slate-800">
                            <th className="px-8 py-4 text-xs font-bold text-slate-500 dark:text-slate-400 uppercase tracking-wider">Case Name</th>
                            <th className="px-8 py-4 text-xs font-bold text-slate-500 dark:text-slate-400 uppercase tracking-wider">Performance Score</th>
                            <th className="px-8 py-4 text-xs font-bold text-slate-500 dark:text-slate-400 uppercase tracking-wider">Date</th>
                            <th className="px-8 py-4 text-xs font-bold text-slate-500 dark:text-slate-400 uppercase tracking-wider">Achievement</th>
                          </tr>
                        </thead>
                        <tbody className="divide-y divide-slate-50 dark:divide-slate-800">
                          {mootHistory.map((item) => (
                            <tr key={item.id} className="hover:bg-slate-50 dark:hover:bg-slate-800/50 transition-all">
                              <td className="px-8 py-6">
                                <p className="font-bold text-slate-900 dark:text-slate-100">{item.caseName}</p>
                              </td>
                              <td className="px-8 py-6">
                                <div className="flex items-center gap-3">
                                  <div className="flex-1 h-2 bg-slate-100 dark:bg-slate-800 rounded-full overflow-hidden max-w-[100px]">
                                    <div 
                                      className="h-full bg-emerald-500 rounded-full" 
                                      style={{ width: `${item.score}%` }}
                                    />
                                  </div>
                                  <span className="font-bold text-slate-700 dark:text-slate-300">{item.score}/100</span>
                                </div>
                              </td>
                              <td className="px-8 py-6 text-slate-600 dark:text-slate-400">{item.date}</td>
                              <td className="px-8 py-6">
                                <span className="px-3 py-1 bg-emerald-100 dark:bg-emerald-900/40 text-emerald-700 dark:text-emerald-400 rounded-full text-xs font-bold">
                                  {item.rank || 'Participant'}
                                </span>
                              </td>
                            </tr>
                          ))}
                        </tbody>
                      </table>
                    </div>
                  </div>
                </div>
              )}
              </motion.div>
            )}

            {activeTab === 'for-lawyers' && (
              <motion.div 
                key="for-lawyers"
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                className="max-w-6xl mx-auto space-y-8"
              >
                <div className="bg-slate-900 p-10 rounded-[40px] text-white relative overflow-hidden">
                  <div className="relative z-10">
                    <h2 className="text-4xl font-bold">Advocate's Command Center</h2>
                    <p className="text-slate-400 mt-2">Specialized tools for independent practitioners and law firms.</p>
                  </div>
                  <Briefcase className="absolute right-10 top-1/2 -translate-y-1/2 text-white/5 w-64 h-64" />
                </div>
                
                <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
                  <div className="bg-white dark:bg-slate-900 p-8 rounded-3xl border border-slate-100 dark:border-slate-800 shadow-xl hover:shadow-2xl transition-all group">
                    <div className="w-14 h-14 rounded-2xl bg-emerald-50 dark:bg-emerald-900/20 flex items-center justify-center text-emerald-600 dark:text-emerald-400 mb-6 group-hover:scale-110 transition-transform">
                      <Scale size={28} />
                    </div>
                    <h3 className="text-xl font-bold text-slate-900 dark:text-slate-100 mb-2">Practice Management</h3>
                    <p className="text-sm text-slate-500 dark:text-slate-400 mb-6">Manage your entire practice from a single dashboard. Automated billing, task tracking, and client management.</p>
                    <button className="text-emerald-600 font-bold flex items-center gap-2 text-sm">Launch Tool <ChevronRight size={16} /></button>
                  </div>
                  
                  <div className="bg-white dark:bg-slate-900 p-8 rounded-3xl border border-slate-100 dark:border-slate-800 shadow-xl hover:shadow-2xl transition-all group">
                    <div className="w-14 h-14 rounded-2xl bg-blue-50 dark:bg-blue-900/20 flex items-center justify-center text-blue-600 dark:text-blue-400 mb-6 group-hover:scale-110 transition-transform">
                      <FileSearch size={28} />
                    </div>
                    <h3 className="text-xl font-bold text-slate-900 dark:text-slate-100 mb-2">Advanced Research</h3>
                    <p className="text-sm text-slate-500 dark:text-slate-400 mb-6">Access premium legal databases with AI-powered search grounding and source quality assessment.</p>
                    <button className="text-blue-600 font-bold flex items-center gap-2 text-sm">Launch Tool <ChevronRight size={16} /></button>
                  </div>

                  <div className="bg-white dark:bg-slate-900 p-8 rounded-3xl border border-slate-100 dark:border-slate-800 shadow-xl hover:shadow-2xl transition-all group">
                    <div className="w-14 h-14 rounded-2xl bg-rose-50 dark:bg-rose-900/20 flex items-center justify-center text-rose-600 dark:text-rose-400 mb-6 group-hover:scale-110 transition-transform">
                      <ShieldCheck size={28} />
                    </div>
                    <h3 className="text-xl font-bold text-slate-900 dark:text-slate-100 mb-2">Ethical Compliance</h3>
                    <p className="text-sm text-slate-500 dark:text-slate-400 mb-6">Run conflict checks and ensure your practice adheres to the latest bar council regulations.</p>
                    <button className="text-rose-600 font-bold flex items-center gap-2 text-sm">Launch Tool <ChevronRight size={16} /></button>
                  </div>
                </div>
              </motion.div>
            )}

            {activeTab === 'for-corporates' && (
              <motion.div 
                key="for-corporates"
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                className="max-w-6xl mx-auto space-y-8"
              >
                <div className="bg-emerald-600 p-10 rounded-[40px] text-white relative overflow-hidden">
                  <div className="relative z-10">
                    <h2 className="text-4xl font-bold">Corporate Legal Suite</h2>
                    <p className="text-emerald-100 mt-2">Enterprise-grade compliance, audit, and ERP integration tools.</p>
                  </div>
                  <ShieldCheck className="absolute right-10 top-1/2 -translate-y-1/2 text-white/10 w-64 h-64" />
                </div>

                <div className="grid grid-cols-1 lg:grid-cols-12 gap-8">
                  <div className="col-span-1 lg:col-span-8 space-y-6">
                    <div className="bg-white dark:bg-slate-900 p-8 rounded-3xl border border-slate-100 dark:border-slate-800 shadow-xl">
                      <h3 className="text-2xl font-bold text-slate-900 dark:text-slate-100 mb-6 flex items-center gap-3">
                        <Zap className="text-emerald-600" /> ERP & Data Gateway
                      </h3>
                      <div className="grid grid-cols-1 md:grid-cols-2 gap-4 mb-8">
                        <div className="p-4 bg-slate-50 dark:bg-slate-800 rounded-2xl border border-slate-100 dark:border-slate-700">
                          <p className="text-xs font-bold text-slate-400 uppercase tracking-widest mb-2">SAP Integration</p>
                          <div className="flex justify-between items-center">
                            <span className="text-sm font-medium text-slate-700 dark:text-slate-300">Status: Connected</span>
                            <div className="w-2 h-2 rounded-full bg-emerald-500" />
                          </div>
                        </div>
                        <div className="p-4 bg-slate-50 dark:bg-slate-800 rounded-2xl border border-slate-100 dark:border-slate-700">
                          <p className="text-xs font-bold text-slate-400 uppercase tracking-widest mb-2">Oracle ERP</p>
                          <div className="flex justify-between items-center">
                            <span className="text-sm font-medium text-slate-700 dark:text-slate-300">Status: Disconnected</span>
                            <button className="text-[10px] bg-emerald-600 text-white px-2 py-1 rounded-lg font-bold">Connect</button>
                          </div>
                        </div>
                      </div>
                      <p className="text-sm text-slate-500 dark:text-slate-400 mb-6">Our advanced API framework facilitates the automated exchange of data by plugging directly into your existing ERP software.</p>
                      <button className="w-full bg-slate-900 text-white py-4 rounded-2xl font-bold hover:bg-slate-800 transition-all">Configure Data Gateway</button>
                    </div>
                  </div>
                  
                  <div className="col-span-1 lg:col-span-4 space-y-6">
                    <div className="bg-slate-900 p-8 rounded-3xl text-white">
                      <h3 className="text-xl font-bold mb-4 flex items-center gap-2">
                        <BarChart3 className="text-emerald-400" /> Compliance Audit
                      </h3>
                      <p className="text-sm text-slate-400 mb-6">Run real-time compliance resolutions and automated triage for corporate legal risks.</p>
                      <div className="space-y-4">
                        <div className="flex justify-between items-center p-3 bg-white/5 rounded-xl">
                          <span className="text-xs">Risk Score</span>
                          <span className="text-xs font-bold text-emerald-400">Low (12/100)</span>
                        </div>
                        <div className="flex justify-between items-center p-3 bg-white/5 rounded-xl">
                          <span className="text-xs">Open Audits</span>
                          <span className="text-xs font-bold text-amber-400">3 Pending</span>
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
              </motion.div>
            )}

            {activeTab === 'lots-247' && (
              <motion.div 
                key="lots-247"
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                className="max-w-6xl mx-auto space-y-8"
              >
                <div className="bg-rose-600 p-10 rounded-[40px] text-white relative overflow-hidden">
                  <div className="relative z-10">
                    <h2 className="text-4xl font-bold">LOTS 24/7</h2>
                    <p className="text-rose-100 mt-2">Legal Operations Tracking System - Real-time monitoring and incident response.</p>
                  </div>
                  <Activity className="absolute right-10 top-1/2 -translate-y-1/2 text-white/10 w-64 h-64" />
                </div>
                
                <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
                  <div className="bg-white dark:bg-slate-900 p-8 rounded-3xl border border-slate-100 dark:border-slate-800 shadow-xl">
                    <h3 className="text-xl font-bold text-slate-900 dark:text-slate-100 mb-4">Incident Feed</h3>
                    <div className="space-y-4">
                      {[1, 2, 3].map(i => (
                        <div key={i} className="flex gap-4 p-4 bg-slate-50 dark:bg-slate-800 rounded-2xl">
                          <div className="w-2 h-2 rounded-full bg-rose-500 mt-1.5 shrink-0" />
                          <div>
                            <p className="text-xs font-bold text-slate-900 dark:text-slate-100">Compliance Alert #{i}04</p>
                            <p className="text-[10px] text-slate-500">2 mins ago - High Priority</p>
                          </div>
                        </div>
                      ))}
                    </div>
                  </div>
                  
                  <div className="lg:col-span-2 bg-white dark:bg-slate-900 p-8 rounded-3xl border border-slate-100 dark:border-slate-800 shadow-xl">
                    <h3 className="text-xl font-bold text-slate-900 dark:text-slate-100 mb-6">System Health & Operations</h3>
                    <div className="h-64 bg-slate-50 dark:bg-slate-800 rounded-2xl flex items-center justify-center border border-slate-100 dark:border-slate-700">
                      <div className="text-center space-y-2">
                        <Activity className="mx-auto text-rose-500 animate-pulse" size={48} />
                        <p className="text-sm text-slate-500">Real-time telemetry active</p>
                      </div>
                    </div>
                  </div>
                </div>
              </motion.div>
            )}

            {activeTab === 'challan-pay' && (
              <motion.div 
                key="challan-pay"
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                className="max-w-4xl mx-auto space-y-8"
              >
                <div className="bg-slate-900 p-10 rounded-[40px] text-white relative overflow-hidden">
                  <div className="relative z-10">
                    <h2 className="text-4xl font-bold">Challan Pay</h2>
                    <p className="text-slate-400 mt-2">Automated traffic and municipal challan resolution system.</p>
                  </div>
                  <CreditCard className="absolute right-10 top-1/2 -translate-y-1/2 text-white/5 w-64 h-64" />
                </div>

                <div className="bg-white dark:bg-slate-900 p-10 rounded-[40px] border border-slate-100 dark:border-slate-800 shadow-2xl space-y-8">
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                    <div className="space-y-2">
                      <label className="text-xs font-bold text-slate-500 uppercase tracking-widest">Vehicle Number</label>
                      <input 
                        placeholder="e.g. MH-12-AB-1234"
                        className="w-full p-4 bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-2xl outline-none focus:ring-2 focus:ring-emerald-500 transition-all"
                      />
                    </div>
                    <div className="space-y-2">
                      <label className="text-xs font-bold text-slate-500 uppercase tracking-widest">Challan ID (Optional)</label>
                      <input 
                        placeholder="e.g. CH-987654321"
                        className="w-full p-4 bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-2xl outline-none focus:ring-2 focus:ring-emerald-500 transition-all"
                      />
                    </div>
                  </div>
                  
                  <button className="w-full bg-emerald-600 text-white py-5 rounded-2xl font-bold shadow-xl shadow-emerald-500/20 hover:bg-emerald-700 transition-all flex items-center justify-center gap-3">
                    <Search size={24} /> Fetch Pending Challans
                  </button>
                  
                  <div className="pt-8 border-t border-slate-100 dark:border-slate-800">
                    <div className="flex items-center gap-4 p-6 bg-blue-50 dark:bg-blue-900/20 rounded-3xl border border-blue-100 dark:border-blue-800/50">
                      <Info className="text-blue-600 dark:text-blue-400 shrink-0" size={24} />
                      <p className="text-sm text-blue-700 dark:text-blue-300">
                        Our system automatically checks for discounts and legal loopholes to minimize your payout.
                      </p>
                    </div>
                  </div>
                </div>
              </motion.div>
            )}

            {activeTab === 'privacy' && (
              <motion.div 
                key="privacy"
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                className="max-w-4xl mx-auto bg-white dark:bg-slate-900 p-12 rounded-3xl border border-slate-100 dark:border-slate-800 shadow-xl prose dark:prose-invert"
              >
                <h1>Privacy Policy</h1>
                <p>Last Updated: March 2026</p>
                <p>At Tandon Associates, we take your privacy seriously. This policy describes how we collect, use, and protect your personal and legal data.</p>
                <h3>1. Data Collection</h3>
                <p>We collect information you provide directly to us, such as when you create an account, upload documents, or use our AI tools.</p>
                <h3>2. Data Security</h3>
                <p>All legal documents are encrypted at rest and in transit. We do not use your confidential case data to train our public AI models.</p>
                <h3>3. Your Rights</h3>
                <p>You have the right to access, correct, or delete your data at any time through your account settings.</p>
              </motion.div>
            )}

            {activeTab === 'terms' && (
              <motion.div 
                key="terms"
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                className="max-w-4xl mx-auto bg-white dark:bg-slate-900 p-12 rounded-3xl border border-slate-100 dark:border-slate-800 shadow-xl prose dark:prose-invert"
              >
                <h1>Terms of Service</h1>
                <p>Last Updated: March 2026</p>
                <p>By using Tandon Associates, you agree to the following terms:</p>
                <h3>1. Use of Service</h3>
                <p>Our platform is a tool to assist legal professionals. It does not constitute legal advice.</p>
                <h3>2. User Responsibilities</h3>
                <p>You are responsible for the accuracy of the information you provide and for maintaining the confidentiality of your account.</p>
                <h3>3. Limitation of Liability</h3>
                <p>Tandon Associates is not liable for any decisions made based on AI-generated content.</p>
              </motion.div>
            )}

            {activeTab === 'disclaimer' && (
              <motion.div 
                key="disclaimer"
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                className="max-w-4xl mx-auto bg-white dark:bg-slate-900 p-12 rounded-3xl border border-slate-100 dark:border-slate-800 shadow-xl prose dark:prose-invert"
              >
                <h1>Legal Disclaimer</h1>
                <p>The information provided by the Tandon Associates AI Legal Platform is for informational purposes only and is not intended to be legal advice.</p>
                <p>AI-generated research and drafts should always be reviewed by a qualified legal professional before use in any legal proceeding.</p>
                <p>Use of this platform does not create an attorney-client relationship between you and Tandon Associates.</p>
              </motion.div>
            )}
            {activeTab === 'settings' && (
              <motion.div 
                key="settings"
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                className="max-w-4xl mx-auto space-y-8"
              >
                <div className="flex items-center gap-4 mb-8">
                  <div className="w-20 h-20 bg-emerald-100 dark:bg-emerald-900/30 text-emerald-600 rounded-3xl flex items-center justify-center text-3xl font-bold">
                    {user?.name?.charAt(0) || 'U'}
                  </div>
                  <div>
                    <h2 className="text-3xl font-bold text-slate-900 dark:text-slate-100">{user?.name || 'User Profile'}</h2>
                    <p className="text-slate-500 dark:text-slate-400 capitalize">{user?.role} • {user?.userType}</p>
                  </div>
                </div>

                <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
                  <div className="lg:col-span-2 space-y-6">
                    <div className="bg-white dark:bg-slate-900 rounded-3xl border border-slate-100 dark:border-slate-800 shadow-xl overflow-hidden">
                      <div className="p-6 border-b border-slate-100 dark:border-slate-800">
                        <h3 className="font-bold text-slate-900 dark:text-slate-100">Personal Information</h3>
                      </div>
                      <div className="p-8 space-y-6">
                        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                          <div>
                            <label className="block text-xs font-bold text-slate-500 uppercase tracking-widest mb-2">Full Name</label>
                            <input 
                              type="text" 
                              defaultValue={user?.name}
                              className="w-full p-3 bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-xl outline-none focus:ring-2 focus:ring-emerald-500 transition-all dark:text-slate-100"
                            />
                          </div>
                          <div>
                            <label className="block text-xs font-bold text-slate-500 uppercase tracking-widest mb-2">Email Address</label>
                            <input 
                              type="email" 
                              defaultValue={user?.email}
                              disabled
                              className="w-full p-3 bg-slate-100 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-xl outline-none opacity-60 cursor-not-allowed dark:text-slate-100"
                            />
                          </div>
                          <div>
                            <label className="block text-xs font-bold text-slate-500 uppercase tracking-widest mb-2">Phone Number</label>
                            <input 
                              type="tel" 
                              placeholder="+91 98765 43210"
                              className="w-full p-3 bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-xl outline-none focus:ring-2 focus:ring-emerald-500 transition-all dark:text-slate-100"
                            />
                          </div>
                          <div>
                            <label className="block text-xs font-bold text-slate-500 uppercase tracking-widest mb-2">Bar Council Number</label>
                            <input 
                              type="text" 
                              placeholder="D/1234/2024"
                              className="w-full p-3 bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-xl outline-none focus:ring-2 focus:ring-emerald-500 transition-all dark:text-slate-100"
                            />
                          </div>
                        </div>
                        <button className="bg-emerald-600 text-white px-8 py-3 rounded-xl font-bold hover:bg-emerald-700 transition-all shadow-lg shadow-emerald-500/20">
                          Save Changes
                        </button>
                      </div>
                    </div>

                    <div className="bg-white dark:bg-slate-900 rounded-3xl border border-slate-100 dark:border-slate-800 shadow-xl overflow-hidden">
                      <div className="p-6 border-b border-slate-100 dark:border-slate-800">
                        <h3 className="font-bold text-slate-900 dark:text-slate-100">Account Security</h3>
                      </div>
                      <div className="p-8 space-y-6">
                        <div className="flex items-center justify-between p-4 bg-slate-50 dark:bg-slate-800/50 rounded-2xl border border-slate-100 dark:border-slate-800">
                          <div className="flex items-center gap-4">
                            <div className="p-2 bg-blue-100 dark:bg-blue-900/30 text-blue-600 rounded-lg">
                              <Lock size={20} />
                            </div>
                            <div>
                              <p className="font-bold text-slate-900 dark:text-slate-100">Password</p>
                              <p className="text-xs text-slate-500 dark:text-slate-400">Last changed 3 months ago</p>
                            </div>
                          </div>
                          <button className="text-blue-600 font-bold text-sm hover:underline">Change Password</button>
                        </div>

                        <div className="flex items-center justify-between p-4 bg-slate-50 dark:bg-slate-800/50 rounded-2xl border border-slate-100 dark:border-slate-800">
                          <div className="flex items-center gap-4">
                            <div className="p-2 bg-emerald-100 dark:bg-emerald-900/30 text-emerald-600 rounded-lg">
                              <ShieldCheck size={20} />
                            </div>
                            <div>
                              <p className="font-bold text-slate-900 dark:text-slate-100">Two-Factor Authentication</p>
                              <p className="text-xs text-slate-500 dark:text-slate-400">Add an extra layer of security to your account</p>
                            </div>
                          </div>
                          <button className="bg-emerald-600 text-white px-4 py-2 rounded-xl text-xs font-bold hover:bg-emerald-700 transition-all">Enable 2FA</button>
                        </div>

                        <div className="flex items-center justify-between p-4 bg-rose-50 dark:bg-rose-900/10 rounded-2xl border border-rose-100 dark:border-rose-900/30">
                          <div className="flex items-center gap-4">
                            <div className="p-2 bg-rose-100 dark:bg-rose-900/30 text-rose-600 rounded-lg">
                              <Trash2 size={20} />
                            </div>
                            <div>
                              <p className="font-bold text-rose-900 dark:text-rose-100">Delete Account</p>
                              <p className="text-xs text-rose-500 dark:text-rose-400">Permanently delete your account and all data</p>
                            </div>
                          </div>
                          <button className="text-rose-600 font-bold text-sm hover:underline">Delete Account</button>
                        </div>
                      </div>
                    </div>
                  </div>

                  <div className="space-y-6">
                    <div className="bg-slate-900 rounded-3xl p-6 text-white space-y-4">
                      <h3 className="font-bold flex items-center gap-2 text-emerald-400"><ShieldCheck size={20} /> Subscription</h3>
                      <div className="p-4 bg-white/10 rounded-2xl border border-white/10">
                        <p className="text-xs text-slate-400 uppercase tracking-widest font-bold mb-1">Current Plan</p>
                        <p className="text-xl font-bold capitalize">{user?.userType} Pro</p>
                        <p className="text-xs text-slate-400 mt-2">Renews on April 12, 2026</p>
                      </div>
                      <button className="w-full py-3 bg-emerald-600 rounded-xl font-bold hover:bg-emerald-700 transition-all">Upgrade Plan</button>
                    </div>

                    <div className="bg-white dark:bg-slate-900 rounded-3xl p-6 border border-slate-100 dark:border-slate-800 shadow-xl space-y-4">
                      <h3 className="font-bold text-slate-900 dark:text-slate-100">Preferences</h3>
                      <div className="flex items-center justify-between">
                        <span className="text-sm text-slate-600 dark:text-slate-400">Email Notifications</span>
                        <div className="w-10 h-5 bg-emerald-600 rounded-full relative"><div className="absolute right-1 top-1 w-3 h-3 bg-white rounded-full"></div></div>
                      </div>
                      <div className="flex items-center justify-between">
                        <span className="text-sm text-slate-600 dark:text-slate-400">AI Suggestions</span>
                        <div className="w-10 h-5 bg-emerald-600 rounded-full relative"><div className="absolute right-1 top-1 w-3 h-3 bg-white rounded-full"></div></div>
                      </div>
                    </div>
                  </div>
                </div>
              </motion.div>
            )}
          </AnimatePresence>
        </div>
      </main>

      <MootPerformanceModal 
        isOpen={isAddingMootPerformance}
        onClose={() => setIsAddingMootPerformance(false)}
        onSave={handleAddMootPerformance}
        details={newMootPerformance}
        setDetails={setNewMootPerformance}
      />

      <StudentVerificationModal 
        isOpen={isVerifyingStudent}
        onClose={() => setIsVerifyingStudent(false)}
        step={verificationStep}
        setStep={setVerificationStep}
        details={studentDetails}
        setDetails={setStudentDetails}
        onVerify={() => {
          setVerificationStep('success');
          if (user) {
            setUser({ ...user, isStudentVerified: true, university: studentDetails.university, studentId: studentDetails.studentId });
          }
        }}
      />

      <LegalDictionary />

      <DocumentVersionModal 
        isOpen={isViewingDocHistory}
        onClose={() => setIsViewingDocHistory(false)}
        documentId={selectedDocForHistory?.id || ''}
        documentName={selectedDocForHistory?.name || ''}
      />
    </div>
  );
}
