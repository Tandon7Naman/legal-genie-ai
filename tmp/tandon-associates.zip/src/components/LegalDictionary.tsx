import React, { useState } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { Book, X, Search, Send, Loader2 } from 'lucide-react';
import { quickLegalHelp } from '../services/legalService';

const LegalDictionary = () => {
  const [isOpen, setIsOpen] = useState(false);
  const [query, setQuery] = useState('');
  const [definition, setDefinition] = useState<string | null>(null);
  const [isLoading, setIsLoading] = useState(false);

  const handleSearch = async (e?: React.FormEvent) => {
    e?.preventDefault();
    if (!query.trim()) return;

    setIsLoading(true);
    setDefinition(null);
    try {
      const result = await quickLegalHelp(query);
      setDefinition(result);
    } catch (error) {
      setDefinition("Sorry, I couldn't find a definition for that term. Please try again.");
    } finally {
      setIsLoading(false);
    }
  };

  return (
    <div className="fixed bottom-6 right-6 z-[60]">
      <AnimatePresence>
        {isOpen && (
          <motion.div
            initial={{ opacity: 0, scale: 0.9, y: 20 }}
            animate={{ opacity: 1, scale: 1, y: 0 }}
            exit={{ opacity: 0, scale: 0.9, y: 20 }}
            className="absolute bottom-16 right-0 w-80 sm:w-96 bg-white dark:bg-slate-900 rounded-2xl shadow-2xl border border-slate-200 dark:border-slate-800 overflow-hidden"
          >
            <div className="p-4 bg-emerald-600 text-white flex justify-between items-center">
              <div className="flex items-center gap-2">
                <Book size={18} />
                <h3 className="font-bold">Legal Dictionary</h3>
              </div>
              <button onClick={() => setIsOpen(false)} className="hover:bg-white/20 p-1 rounded-full transition-colors">
                <X size={18} />
              </button>
            </div>

            <div className="p-4 space-y-4">
              <form onSubmit={handleSearch} className="relative">
                <input
                  type="text"
                  placeholder="Enter legal term (e.g. Habeas Corpus)"
                  className="w-full pl-4 pr-10 py-2.5 rounded-xl border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-800 text-sm focus:ring-2 focus:ring-emerald-500 outline-none transition-all dark:text-slate-100"
                  value={query}
                  onChange={(e) => setQuery(e.target.value)}
                />
                <button
                  type="submit"
                  disabled={isLoading || !query.trim()}
                  className="absolute right-2 top-1/2 -translate-y-1/2 text-emerald-600 disabled:text-slate-400"
                >
                  {isLoading ? <Loader2 size={18} className="animate-spin" /> : <Send size={18} />}
                </button>
              </form>

              <div className="min-h-[100px] max-h-[300px] overflow-y-auto custom-scrollbar">
                {definition ? (
                  <div className="text-sm text-slate-600 dark:text-slate-300 leading-relaxed animate-in fade-in slide-in-from-bottom-2">
                    <p className="font-bold text-slate-900 dark:text-slate-100 mb-1">{query}</p>
                    <div className="prose prose-sm dark:prose-invert">
                      {definition}
                    </div>
                  </div>
                ) : (
                  <div className="h-full flex flex-col items-center justify-center text-slate-400 py-8">
                    <Search size={32} className="mb-2 opacity-20" />
                    <p className="text-xs text-center px-8">Search for Latin maxims, legal terms, or sections for instant definitions.</p>
                  </div>
                )}
              </div>
            </div>
          </motion.div>
        )}
      </AnimatePresence>

      <button
        onClick={() => setIsOpen(!isOpen)}
        className={`p-4 rounded-full shadow-lg transition-all active:scale-90 ${
          isOpen ? 'bg-slate-800 text-white' : 'bg-emerald-600 text-white hover:bg-emerald-700'
        }`}
      >
        <Book size={24} />
      </button>
    </div>
  );
};

export default LegalDictionary;
