import React, { useState } from 'react';
import { motion } from 'framer-motion';
import { ChevronLeft, ChevronRight, Gavel, Clock, Calendar as CalendarIcon } from 'lucide-react';

interface HearingCalendarProps {
  cases: any[];
  onCaseClick?: (caseId: string) => void;
}

const HearingCalendar = ({ cases, onCaseClick }: HearingCalendarProps) => {
  const [currentDate, setCurrentDate] = useState(new Date());

  const daysInMonth = (year: number, month: number) => new Date(year, month + 1, 0).getDate();
  const firstDayOfMonth = (year: number, month: number) => new Date(year, month, 1).getDay();

  const prevMonth = () => {
    setCurrentDate(new Date(currentDate.getFullYear(), currentDate.getMonth() - 1, 1));
  };

  const nextMonth = () => {
    setCurrentDate(new Date(currentDate.getFullYear(), currentDate.getMonth() + 1, 1));
  };

  const monthNames = [
    "January", "February", "March", "April", "May", "June",
    "July", "August", "September", "October", "November", "December"
  ];

  const year = currentDate.getFullYear();
  const month = currentDate.getMonth();
  const days = daysInMonth(year, month);
  const firstDay = firstDayOfMonth(year, month);

  const calendarDays = [];
  for (let i = 0; i < firstDay; i++) {
    calendarDays.push(null);
  }
  for (let i = 1; i <= days; i++) {
    calendarDays.push(i);
  }

  const getHearingsForDay = (day: number) => {
    const dateStr = `${monthNames[month].slice(0, 3)} ${day}, ${year}`;
    return cases.filter(c => c.nextHearing === dateStr || (c.timestamp && new Date(c.timestamp).toDateString() === new Date(year, month, day).toDateString()));
  };

  return (
    <div className="bg-white dark:bg-slate-900 rounded-3xl border border-slate-100 dark:border-slate-800 shadow-sm overflow-hidden">
      <div className="p-6 border-b border-slate-50 dark:border-slate-800 flex justify-between items-center bg-emerald-600 text-white">
        <div className="flex items-center gap-3">
          <CalendarIcon size={24} />
          <h3 className="text-xl font-bold">{monthNames[month]} {year}</h3>
        </div>
        <div className="flex gap-2">
          <button onClick={prevMonth} className="p-2 hover:bg-white/20 rounded-full transition-colors">
            <ChevronLeft size={20} />
          </button>
          <button onClick={nextMonth} className="p-2 hover:bg-white/20 rounded-full transition-colors">
            <ChevronRight size={20} />
          </button>
        </div>
      </div>

      <div className="grid grid-cols-7 border-b border-slate-50 dark:border-slate-800">
        {["Sun", "Mon", "Tue", "Wed", "Thu", "Fri", "Sat"].map(d => (
          <div key={d} className="py-3 text-center text-xs font-bold text-slate-400 uppercase tracking-widest">
            {d}
          </div>
        ))}
      </div>

      <div className="grid grid-cols-7">
        {calendarDays.map((day, idx) => {
          if (day === null) return <div key={`empty-${idx}`} className="h-24 sm:h-32 border-r border-b border-slate-50 dark:border-slate-800 bg-slate-50/50 dark:bg-slate-800/20" />;
          
          const hearings = getHearingsForDay(day);
          const isToday = new Date().toDateString() === new Date(year, month, day).toDateString();

          return (
            <div 
              key={day} 
              className={`h-24 sm:h-32 border-r border-b border-slate-50 dark:border-slate-800 p-2 transition-colors hover:bg-slate-50 dark:hover:bg-slate-800/50 relative group ${
                isToday ? 'bg-emerald-50/30 dark:bg-emerald-900/10' : ''
              }`}
            >
              <span className={`text-sm font-bold ${isToday ? 'bg-emerald-600 text-white w-7 h-7 flex items-center justify-center rounded-full' : 'text-slate-500 dark:text-slate-400'}`}>
                {day}
              </span>
              
              <div className="mt-2 space-y-1 overflow-y-auto max-h-[calc(100%-2rem)] custom-scrollbar">
                {hearings.map((h, hIdx) => (
                  <motion.div 
                    key={h.id}
                    initial={{ opacity: 0, x: -5 }}
                    animate={{ opacity: 1, x: 0 }}
                    onClick={() => onCaseClick?.(h.id)}
                    className="text-[10px] sm:text-xs p-1.5 rounded-lg bg-emerald-100 dark:bg-emerald-900/40 text-emerald-700 dark:text-emerald-300 border border-emerald-200 dark:border-emerald-800/50 truncate cursor-pointer hover:shadow-sm transition-all flex items-center gap-1"
                  >
                    <Gavel size={10} />
                    {h.name}
                  </motion.div>
                ))}
              </div>
            </div>
          );
        })}
      </div>
    </div>
  );
};

export default HearingCalendar;
