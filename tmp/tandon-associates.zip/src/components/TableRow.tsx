import React from 'react';

interface TableRowProps {
  cells: string[];
  actions?: React.ReactNode;
  gridClass?: string;
}

const TableRow = ({ cells, actions, gridClass = "grid-cols-4" }: TableRowProps) => (
  <div className="p-4 flex items-center justify-between hover:bg-slate-50 dark:hover:bg-slate-800/50 transition-all border-b border-slate-50 dark:border-slate-800 last:border-0">
    <div className={`flex-1 grid ${gridClass} gap-4`}>
      {cells.map((cell, i) => (
        <span key={i} className={`text-sm ${i === 0 ? 'font-bold text-slate-900 dark:text-slate-100' : 'text-slate-600 dark:text-slate-400'}`}>
          {cell}
        </span>
      ))}
    </div>
    {actions && <div className="flex gap-2">{actions}</div>}
  </div>
);

export default TableRow;
