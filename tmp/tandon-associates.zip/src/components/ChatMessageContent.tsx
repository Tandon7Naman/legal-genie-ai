import React, { useState } from 'react';
import Markdown from 'react-markdown';
import { ChevronUp, ChevronDown } from 'lucide-react';

interface ChatMessageContentProps {
  content: string;
  isError?: boolean;
}

const ChatMessageContent = ({ content, isError }: ChatMessageContentProps) => {
  const [isExpanded, setIsExpanded] = useState(false);
  const isLong = content.length > 500;
  
  return (
    <div className={`text-sm leading-relaxed ${isError ? 'pr-6' : ''}`}>
      <div className={`markdown-body space-y-4 ${!isExpanded && isLong ? 'line-clamp-6' : ''}`}>
        <Markdown
          components={{
            p: ({node, ...props}) => <p className="mb-2 last:mb-0" {...props} />,
            pre: ({node, ...props}) => <pre className="bg-slate-800 text-slate-50 p-4 rounded-xl overflow-x-auto text-xs font-mono my-4" {...props} />,
            code: ({node, inline, className, children, ...props}: any) => {
              const match = /language-(\w+)/.exec(className || '')
              return !inline ? (
                <code className={className} {...props}>
                  {children}
                </code>
              ) : (
                <code className="bg-slate-100 text-emerald-700 px-1.5 py-0.5 rounded-md text-xs font-mono" {...props}>
                  {children}
                </code>
              )
            },
            h1: ({node, ...props}) => <h1 className="text-xl font-bold mt-6 mb-4" {...props} />,
            h2: ({node, ...props}) => <h2 className="text-lg font-bold mt-5 mb-3" {...props} />,
            h3: ({node, ...props}) => <h3 className="text-base font-bold mt-4 mb-2" {...props} />,
            ul: ({node, ...props}) => <ul className="list-disc pl-5 space-y-1 my-2" {...props} />,
            ol: ({node, ...props}) => <ol className="list-decimal pl-5 space-y-1 my-2" {...props} />,
            li: ({node, ...props}) => <li className="pl-1" {...props} />,
            blockquote: ({node, ...props}) => <blockquote className="border-l-4 border-emerald-500 pl-4 italic text-slate-600 my-4 bg-emerald-50/50 py-2 pr-4 rounded-r-lg" {...props} />,
            a: ({node, ...props}) => <a className="text-emerald-600 hover:underline font-medium" {...props} />
          }}
        >
          {content}
        </Markdown>
      </div>
      {isLong && (
        <button 
          onClick={() => setIsExpanded(!isExpanded)}
          className="mt-3 flex items-center gap-1 text-xs font-bold text-emerald-600 hover:text-emerald-700 transition-colors bg-emerald-50 px-3 py-1.5 rounded-full"
        >
          {isExpanded ? (
            <><ChevronUp size={14} /> Show Less</>
          ) : (
            <><ChevronDown size={14} /> Read More</>
          )}
        </button>
      )}
    </div>
  );
};

export default ChatMessageContent;
