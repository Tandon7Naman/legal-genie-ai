import React from 'react';
import { motion } from 'framer-motion';
import { X } from 'lucide-react';

interface MootPerformanceModalProps {
  isOpen: boolean;
  onClose: () => void;
  onSave: () => void;
  details: { caseName: string; score: number; date: string; rank: string };
  setDetails: (details: any) => void;
}

const MootPerformanceModal = ({ isOpen, onClose, onSave, details, setDetails }: MootPerformanceModalProps) => {
  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 bg-slate-900/60 backdrop-blur-sm z-[100] flex items-center justify-center p-4">
      <motion.div 
        initial={{ opacity: 0, scale: 0.95, y: 20 }}
        animate={{ opacity: 1, scale: 1, y: 0 }}
        className="bg-white dark:bg-slate-900 rounded-3xl shadow-2xl w-full max-w-lg overflow-hidden border border-slate-100 dark:border-slate-800"
      >
        <div className="p-6 border-b border-slate-100 dark:border-slate-800 flex justify-between items-center bg-emerald-600 text-white">
          <div>
            <h2 className="text-xl font-bold">Add Moot Performance</h2>
            <p className="text-emerald-100 text-sm">Record your competition achievements</p>
          </div>
          <button onClick={onClose} className="p-2 hover:bg-white/10 rounded-full transition-colors">
            <X size={24} />
          </button>
        </div>

        <div className="p-8 space-y-6">
          <div className="space-y-4">
            <div>
              <label className="block text-sm font-bold text-slate-700 dark:text-slate-300 mb-2">Case Name / Competition</label>
              <input 
                type="text" 
                className="w-full px-4 py-3 rounded-xl border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-800 focus:ring-2 focus:ring-emerald-500 outline-none transition-all dark:text-slate-100"
                placeholder="e.g. Jessup International Moot 2024"
                value={details.caseName}
                onChange={(e) => setDetails({ ...details, caseName: e.target.value })}
              />
            </div>
            <div className="grid grid-cols-2 gap-4">
              <div>
                <label className="block text-sm font-bold text-slate-700 dark:text-slate-300 mb-2">Performance Score (%)</label>
                <input 
                  type="number" 
                  min="0"
                  max="100"
                  className="w-full px-4 py-3 rounded-xl border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-800 focus:ring-2 focus:ring-emerald-500 outline-none transition-all dark:text-slate-100"
                  value={details.score}
                  onChange={(e) => setDetails({ ...details, score: parseInt(e.target.value) })}
                />
              </div>
              <div>
                <label className="block text-sm font-bold text-slate-700 dark:text-slate-300 mb-2">Date</label>
                <input 
                  type="date" 
                  className="w-full px-4 py-3 rounded-xl border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-800 focus:ring-2 focus:ring-emerald-500 outline-none transition-all dark:text-slate-100"
                  value={details.date}
                  onChange={(e) => setDetails({ ...details, date: e.target.value })}
                />
              </div>
            </div>
            <div>
              <label className="block text-sm font-bold text-slate-700 dark:text-slate-300 mb-2">Achievement / Rank</label>
              <input 
                type="text" 
                className="w-full px-4 py-3 rounded-xl border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-800 focus:ring-2 focus:ring-emerald-500 outline-none transition-all dark:text-slate-100"
                placeholder="e.g. Best Speaker, Winner, Participant"
                value={details.rank}
                onChange={(e) => setDetails({ ...details, rank: e.target.value })}
              />
            </div>
          </div>
          
          <div className="flex gap-4">
            <button 
              onClick={onClose}
              className="flex-1 py-4 border border-slate-200 dark:border-slate-700 text-slate-600 dark:text-slate-400 rounded-xl font-bold hover:bg-slate-50 dark:hover:bg-slate-800 transition-all"
            >
              Cancel
            </button>
            <button 
              onClick={onSave}
              disabled={!details.caseName || !details.date}
              className="flex-2 py-4 bg-emerald-600 text-white rounded-xl font-bold hover:bg-emerald-700 transition-all shadow-lg shadow-emerald-500/20 disabled:opacity-50 disabled:cursor-not-allowed"
            >
              Save Performance
            </button>
          </div>
        </div>
      </motion.div>
    </div>
  );
};

export default MootPerformanceModal;
