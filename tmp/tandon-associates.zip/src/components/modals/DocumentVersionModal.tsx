import React, { useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { X, History, Download, User, Clock, FileText, Plus } from 'lucide-react';

interface Version {
  id: number;
  version_number: number;
  name: string;
  url: string;
  size: number;
  user_name: string;
  updated_at: string;
}

interface DocumentVersionModalProps {
  isOpen: boolean;
  onClose: () => void;
  documentId: string;
  documentName: string;
}

const DocumentVersionModal = ({ isOpen, onClose, documentId, documentName }: DocumentVersionModalProps) => {
  const [versions, setVersions] = useState<Version[]>([]);
  const [isLoading, setIsLoading] = useState(false);

  useEffect(() => {
    if (isOpen && documentId) {
      fetchVersions();
    }
  }, [isOpen, documentId]);

  const fetchVersions = async () => {
    setIsLoading(true);
    try {
      const res = await fetch(`/api/documents/${documentId}/versions`);
      const data = await res.json();
      setVersions(data);
    } catch (error) {
      console.error('Failed to fetch versions:', error);
    } finally {
      setIsLoading(false);
    }
  };

  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 bg-slate-900/60 backdrop-blur-sm z-[100] flex items-center justify-center p-4">
      <motion.div 
        initial={{ opacity: 0, scale: 0.95, y: 20 }}
        animate={{ opacity: 1, scale: 1, y: 0 }}
        className="bg-white dark:bg-slate-900 rounded-3xl shadow-2xl w-full max-w-2xl overflow-hidden border border-slate-100 dark:border-slate-800"
      >
        <div className="p-6 border-b border-slate-100 dark:border-slate-800 flex justify-between items-center bg-slate-50 dark:bg-slate-800/50">
          <div className="flex items-center gap-3">
            <div className="p-2 bg-emerald-100 dark:bg-emerald-900/30 text-emerald-600 rounded-lg">
              <History size={20} />
            </div>
            <div>
              <h2 className="text-xl font-bold text-slate-900 dark:text-slate-100">Version History</h2>
              <p className="text-slate-500 dark:text-slate-400 text-sm">{documentName}</p>
            </div>
          </div>
          <button onClick={onClose} className="p-2 hover:bg-slate-200 dark:hover:bg-slate-700 rounded-full transition-colors text-slate-500">
            <X size={24} />
          </button>
        </div>

        <div className="p-6 max-h-[60vh] overflow-y-auto custom-scrollbar">
          {isLoading ? (
            <div className="py-20 flex flex-col items-center justify-center text-slate-400 gap-4">
              <div className="w-10 h-10 border-4 border-emerald-100 dark:border-emerald-900/20 border-t-emerald-600 rounded-full animate-spin" />
              <p className="text-sm font-medium">Loading version history...</p>
            </div>
          ) : versions.length > 0 ? (
            <div className="space-y-4">
              {versions.map((v) => (
                <div 
                  key={v.id} 
                  className="flex items-center justify-between p-4 bg-slate-50 dark:bg-slate-800/50 rounded-2xl border border-slate-100 dark:border-slate-800 hover:border-emerald-200 dark:hover:border-emerald-800/50 transition-all group"
                >
                  <div className="flex items-center gap-4">
                    <div className="w-10 h-10 bg-white dark:bg-slate-800 rounded-xl flex items-center justify-center text-slate-400 font-bold border border-slate-100 dark:border-slate-700">
                      v{v.version_number}
                    </div>
                    <div>
                      <p className="font-bold text-slate-900 dark:text-slate-100">{v.name}</p>
                      <div className="flex items-center gap-3 mt-1">
                        <span className="flex items-center gap-1 text-[10px] text-slate-500 dark:text-slate-400 font-medium">
                          <User size={12} /> {v.user_name}
                        </span>
                        <span className="flex items-center gap-1 text-[10px] text-slate-500 dark:text-slate-400 font-medium">
                          <Clock size={12} /> {new Date(v.updated_at).toLocaleString()}
                        </span>
                        <span className="text-[10px] text-slate-400">{(v.size / 1024).toFixed(1)} KB</span>
                      </div>
                    </div>
                  </div>
                  <button className="p-2 bg-white dark:bg-slate-700 text-emerald-600 rounded-lg border border-slate-100 dark:border-slate-600 opacity-0 group-hover:opacity-100 transition-all hover:bg-emerald-50 dark:hover:bg-emerald-900/20">
                    <Download size={18} />
                  </button>
                </div>
              ))}
            </div>
          ) : (
            <div className="py-20 text-center text-slate-400">
              <FileText size={48} className="mx-auto mb-4 opacity-10" />
              <p>No version history found for this document.</p>
            </div>
          )}
        </div>

        <div className="p-6 border-t border-slate-100 dark:border-slate-800 bg-slate-50 dark:bg-slate-800/50 flex justify-end gap-3">
          <button 
            onClick={onClose}
            className="px-6 py-2.5 text-slate-600 dark:text-slate-400 font-bold hover:bg-slate-200 dark:hover:bg-slate-700 rounded-xl transition-all"
          >
            Close
          </button>
          <button className="px-6 py-2.5 bg-emerald-600 text-white font-bold rounded-xl hover:bg-emerald-700 transition-all shadow-lg shadow-emerald-500/20 flex items-center gap-2">
            <Plus size={18} /> Upload New Version
          </button>
        </div>
      </motion.div>
    </div>
  );
};

export default DocumentVersionModal;
