import React from 'react';
import { motion } from 'framer-motion';
import { X, Info, ImageIcon, ShieldCheck, CheckCircle2 } from 'lucide-react';

interface StudentVerificationModalProps {
  isOpen: boolean;
  onClose: () => void;
  onVerify: () => void;
  step: 'form' | 'upload' | 'pending' | 'success';
  setStep: (step: 'form' | 'upload' | 'pending' | 'success') => void;
  details: { university: string; studentId: string; gradYear: string };
  setDetails: (details: any) => void;
}

const StudentVerificationModal = ({ isOpen, onClose, onVerify, step, setStep, details, setDetails }: StudentVerificationModalProps) => {
  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 bg-slate-900/60 backdrop-blur-sm z-[100] flex items-center justify-center p-4">
      <motion.div 
        initial={{ opacity: 0, scale: 0.95, y: 20 }}
        animate={{ opacity: 1, scale: 1, y: 0 }}
        className="bg-white dark:bg-slate-900 rounded-3xl shadow-2xl w-full max-w-lg overflow-hidden border border-slate-100 dark:border-slate-800"
      >
        <div className="p-6 border-b border-slate-100 dark:border-slate-800 flex justify-between items-center bg-emerald-600 text-white">
          <div>
            <h2 className="text-xl font-bold">Law Student Verification</h2>
            <p className="text-emerald-100 text-sm">Access exclusive student features & resources</p>
          </div>
          <button onClick={onClose} className="p-2 hover:bg-white/10 rounded-full transition-colors">
            <X size={24} />
          </button>
        </div>

        <div className="p-8">
          {step === 'form' && (
            <div className="space-y-6">
              <div className="flex items-center gap-4 p-4 bg-emerald-50 dark:bg-emerald-900/20 rounded-2xl text-emerald-700 dark:text-emerald-400 mb-6">
                <Info size={24} />
                <p className="text-sm font-medium">Verification unlocks free AI research, document templates, and the Student Hub.</p>
              </div>
              <div className="space-y-4">
                <div>
                  <label className="block text-sm font-bold text-slate-700 dark:text-slate-300 mb-2">University / Law School</label>
                  <input 
                    type="text" 
                    className="w-full px-4 py-3 rounded-xl border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-800 focus:ring-2 focus:ring-emerald-500 outline-none transition-all dark:text-slate-100"
                    placeholder="e.g. Harvard Law School"
                    value={details.university}
                    onChange={(e) => setDetails({ ...details, university: e.target.value })}
                  />
                </div>
                <div>
                  <label className="block text-sm font-bold text-slate-700 dark:text-slate-300 mb-2">Student ID Number</label>
                  <input 
                    type="text" 
                    className="w-full px-4 py-3 rounded-xl border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-800 focus:ring-2 focus:ring-emerald-500 outline-none transition-all dark:text-slate-100"
                    placeholder="e.g. L-2024-001"
                    value={details.studentId}
                    onChange={(e) => setDetails({ ...details, studentId: e.target.value })}
                  />
                </div>
                <div>
                  <label className="block text-sm font-bold text-slate-700 dark:text-slate-300 mb-2">Expected Graduation Year</label>
                  <select 
                    className="w-full px-4 py-3 rounded-xl border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-800 focus:ring-2 focus:ring-emerald-500 outline-none transition-all dark:text-slate-100"
                    value={details.gradYear}
                    onChange={(e) => setDetails({ ...details, gradYear: e.target.value })}
                  >
                    <option value="">Select Year</option>
                    <option value="2024">2024</option>
                    <option value="2025">2025</option>
                    <option value="2026">2026</option>
                    <option value="2027">2027</option>
                  </select>
                </div>
              </div>
              <button 
                onClick={() => setStep('upload')}
                disabled={!details.university || !details.studentId || !details.gradYear}
                className="w-full py-4 bg-emerald-600 text-white rounded-xl font-bold hover:bg-emerald-700 transition-all disabled:opacity-50 disabled:cursor-not-allowed shadow-lg shadow-emerald-500/20"
              >
                Next: Upload ID
              </button>
            </div>
          )}

          {step === 'upload' && (
            <div className="space-y-6 text-center">
              <div className="w-20 h-20 bg-emerald-100 dark:bg-emerald-900/40 text-emerald-600 dark:text-emerald-400 rounded-full flex items-center justify-center mx-auto mb-4">
                <ImageIcon size={40} />
              </div>
              <h3 className="text-xl font-bold text-slate-900 dark:text-slate-100">Upload Student ID</h3>
              <p className="text-slate-500 dark:text-slate-400">Please upload a clear photo of your current law school student ID card.</p>
              
              <div className="border-2 border-dashed border-slate-200 dark:border-slate-700 rounded-2xl p-12 hover:border-emerald-400 transition-colors cursor-pointer bg-slate-50 dark:bg-slate-800/50">
                <Plus size={32} className="mx-auto text-slate-400 mb-2" />
                <p className="text-sm font-medium text-slate-600 dark:text-slate-400">Click to browse or drag and drop</p>
                <p className="text-xs text-slate-400 mt-1">JPG, PNG or PDF (Max 5MB)</p>
              </div>

              <div className="flex gap-4">
                <button 
                  onClick={() => setStep('form')}
                  className="flex-1 py-4 border border-slate-200 dark:border-slate-700 text-slate-600 dark:text-slate-400 rounded-xl font-bold hover:bg-slate-50 dark:hover:bg-slate-800 transition-all"
                >
                  Back
                </button>
                <button 
                  onClick={() => {
                    setStep('pending');
                    setTimeout(() => onVerify(), 2000);
                  }}
                  className="flex-2 py-4 bg-emerald-600 text-white rounded-xl font-bold hover:bg-emerald-700 transition-all shadow-lg shadow-emerald-500/20"
                >
                  Submit for Verification
                </button>
              </div>
            </div>
          )}

          {step === 'pending' && (
            <div className="py-12 text-center space-y-6">
              <div className="relative w-24 h-24 mx-auto">
                <div className="absolute inset-0 border-4 border-emerald-100 dark:border-emerald-900/20 rounded-full"></div>
                <div className="absolute inset-0 border-4 border-emerald-600 rounded-full border-t-transparent animate-spin"></div>
                <div className="absolute inset-0 flex items-center justify-center text-emerald-600">
                  <ShieldCheck size={40} />
                </div>
              </div>
              <h3 className="text-2xl font-bold text-slate-900 dark:text-slate-100">Verifying Your Status</h3>
              <p className="text-slate-500 dark:text-slate-400 max-w-xs mx-auto">Our AI is reviewing your credentials. This usually takes less than a minute.</p>
            </div>
          )}

          {step === 'success' && (
            <div className="py-12 text-center space-y-6">
              <div className="w-24 h-24 bg-emerald-100 dark:bg-emerald-900/40 text-emerald-600 dark:text-emerald-400 rounded-full flex items-center justify-center mx-auto animate-bounce">
                <CheckCircle2 size={56} />
              </div>
              <h3 className="text-2xl font-bold text-slate-900 dark:text-slate-100">Verification Successful!</h3>
              <p className="text-slate-500 dark:text-slate-400">Welcome to the Student Hub. You now have full access to all student resources.</p>
              <button 
                onClick={onClose}
                className="w-full py-4 bg-emerald-600 text-white rounded-xl font-bold hover:bg-emerald-700 transition-all shadow-lg shadow-emerald-500/20"
              >
                Go to Student Hub
              </button>
            </div>
          )}
        </div>
      </motion.div>
    </div>
  );
};

// Helper component for Plus icon since it wasn't imported in this scope but used in original
const Plus = ({ size, className }: any) => (
  <svg width={size} height={size} viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className={className}>
    <line x1="12" y1="5" x2="12" y2="19"></line>
    <line x1="5" y1="12" x2="19" y2="12"></line>
  </svg>
);

export default StudentVerificationModal;
