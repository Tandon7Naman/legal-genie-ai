import React from 'react';
import { 
  Scale, 
  ChevronRight, 
  ArrowLeft, 
  Users, 
  Building2, 
  Mail, 
  Lock, 
  Bookmark
} from 'lucide-react';
import { motion } from 'framer-motion';
import { useAppContext } from '../context/AppContext';

export const LandingPage: React.FC = () => {
  const { 
    showLanding, 
    setShowLanding, 
    isSignup, 
    setIsSignup, 
    firmName, 
    setFirmName, 
    loginEmail, 
    setLoginEmail, 
    loginPassword, 
    setLoginPassword, 
    authError, 
    handleLogin, 
    loading, 
    addToast 
  } = useAppContext();

  if (showLanding) {
    return (
      <div className="min-h-screen bg-slate-50 flex flex-col">
        <header className="p-6 flex justify-between items-center bg-white border-b border-slate-100">
          <div className="flex items-center gap-3">
            <div className="bg-emerald-600 p-2 rounded-xl text-white shadow-md shadow-emerald-200">
              <Scale size={24} />
            </div>
            <h1 className="text-xl font-bold text-slate-900">Tandon Associates</h1>
          </div>
          <button 
            onClick={() => setShowLanding(false)}
            className="bg-emerald-600 text-white px-6 py-2.5 rounded-xl font-bold shadow-md shadow-emerald-200 hover:bg-emerald-700 transition-all"
          >
            Sign In
          </button>
        </header>
        
        <main className="flex-1 flex flex-col items-center justify-center p-6 text-center">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            className="max-w-3xl space-y-8"
          >
            <h2 className="text-5xl md:text-6xl font-extrabold text-slate-900 tracking-tight">
              Modern Legal Operations <br className="hidden md:block" />
              <span className="text-emerald-600">Powered by AI</span>
            </h2>
            <p className="text-xl text-slate-500 max-w-2xl mx-auto leading-relaxed">
              Streamline case tracking, automate document generation, and leverage advanced AI for legal research in one unified platform.
            </p>
            <div className="flex flex-wrap justify-center gap-4 pt-4">
              <button 
                onClick={() => setShowLanding(false)}
                className="bg-emerald-600 text-white px-8 py-4 rounded-xl font-bold text-lg shadow-xl shadow-emerald-200 hover:bg-emerald-700 transition-all flex items-center gap-2"
              >
                Get Started <ChevronRight size={20} />
              </button>
            </div>

            <div className="pt-20 max-w-xl mx-auto">
              <div className="bg-white p-8 rounded-3xl shadow-xl border border-slate-100 text-left space-y-6">
                <h3 className="text-2xl font-bold text-slate-900">Contact Our Experts</h3>
                <p className="text-slate-500 text-sm">Have questions? Send us a message and our team will get back to you within 24 hours.</p>
                <div className="space-y-4">
                  <input type="text" placeholder="Your Name" className="w-full p-3 bg-slate-50 border border-slate-200 rounded-xl outline-none focus:ring-2 focus:ring-emerald-500 transition-all" />
                  <input type="email" placeholder="Email Address" className="w-full p-3 bg-slate-50 border border-slate-200 rounded-xl outline-none focus:ring-2 focus:ring-emerald-500 transition-all" />
                  <textarea placeholder="How can we help?" className="w-full h-32 p-3 bg-slate-50 border border-slate-200 rounded-xl outline-none focus:ring-2 focus:ring-emerald-500 transition-all resize-none"></textarea>
                  <button 
                    onClick={() => addToast('Message sent successfully! We will contact you soon.', 'success')}
                    className="w-full bg-slate-900 text-white py-3 rounded-xl font-bold hover:bg-slate-800 transition-all"
                  >
                    Send Message
                  </button>
                </div>
              </div>
            </div>
          </motion.div>
        </main>
        
        <footer className="p-10 bg-white border-t border-slate-100">
          <div className="max-w-7xl mx-auto grid grid-cols-1 md:grid-cols-4 gap-10">
            <div className="space-y-4">
              <div className="flex items-center gap-3">
                <div className="bg-emerald-600 p-2 rounded-lg text-white">
                  <Scale size={20} />
                </div>
                <h4 className="font-bold text-slate-900">Tandon Associates</h4>
              </div>
              <p className="text-sm text-slate-500">The future of legal technology, built for modern law firms and professionals.</p>
            </div>
            <div>
              <h5 className="font-bold text-slate-900 mb-4 uppercase tracking-widest text-xs">Platform</h5>
              <ul className="space-y-2 text-sm text-slate-500">
                <li className="hover:text-emerald-600 cursor-pointer">Case Management</li>
                <li className="hover:text-emerald-600 cursor-pointer">AI Research</li>
                <li className="hover:text-emerald-600 cursor-pointer">Document Automation</li>
              </ul>
            </div>
            <div>
              <h5 className="font-bold text-slate-900 mb-4 uppercase tracking-widest text-xs">Company</h5>
              <ul className="space-y-2 text-sm text-slate-500">
                <li className="hover:text-emerald-600 cursor-pointer">About Us</li>
                <li className="hover:text-emerald-600 cursor-pointer">Contact</li>
                <li className="hover:text-emerald-600 cursor-pointer">Privacy Policy</li>
              </ul>
            </div>
            <div>
              <h5 className="font-bold text-slate-900 mb-4 uppercase tracking-widest text-xs">Legal</h5>
              <ul className="space-y-2 text-sm text-slate-500">
                <li className="hover:text-emerald-600 cursor-pointer">Terms of Service</li>
                <li className="hover:text-emerald-600 cursor-pointer">Disclaimer</li>
                <li className="hover:text-emerald-600 cursor-pointer">Cookie Policy</li>
              </ul>
            </div>
          </div>
        </footer>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-slate-50 flex items-center justify-center p-6 relative">
      <button 
        onClick={() => setShowLanding(true)}
        className="absolute top-6 left-6 p-3 bg-white text-slate-500 hover:text-emerald-600 hover:bg-emerald-50 rounded-xl shadow-sm border border-slate-200 transition-all flex items-center gap-2 font-medium"
      >
        <ArrowLeft size={20} />
        <span>Back to Home</span>
      </button>
      <motion.div 
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        className="w-full max-w-md bg-white rounded-3xl shadow-xl border border-slate-100 p-8"
      >
        <div className="flex flex-col items-center mb-8">
          <div className="bg-emerald-600 p-3 rounded-2xl text-white mb-4 shadow-lg shadow-emerald-200">
            <Scale size={32} />
          </div>
          <h1 className="text-2xl font-bold text-slate-900">Tandon Associates</h1>
          <p className="text-slate-500 text-sm">{isSignup ? 'Create your account' : 'Legal Operations Platform'}</p>
        </div>

        <form onSubmit={handleLogin} className="space-y-6">
          {isSignup && (
            <div className="space-y-4">
              <div>
                <label className="block text-sm font-bold text-slate-700 mb-2">Full Name</label>
                <div className="relative">
                  <Users className="absolute left-3 top-1/2 -translate-y-1/2 text-slate-400" size={18} />
                  <input 
                    type="text" 
                    className="w-full pl-10 pr-4 py-3 bg-slate-50 border border-slate-200 rounded-xl focus:ring-2 focus:ring-emerald-500 outline-none transition-all"
                    placeholder="John Doe"
                    required
                  />
                </div>
              </div>
              {loginEmail.endsWith('@tandonassociates.com') || loginEmail.includes('firm') ? (
                <div>
                  <label className="block text-sm font-bold text-slate-700 mb-2">Firm Name</label>
                  <div className="relative">
                    <Building2 className="absolute left-3 top-1/2 -translate-y-1/2 text-slate-400" size={18} />
                    <input 
                      type="text" 
                      value={firmName}
                      onChange={(e) => setFirmName(e.target.value)}
                      className="w-full pl-10 pr-4 py-3 bg-slate-50 border border-slate-200 rounded-xl focus:ring-2 focus:ring-emerald-500 outline-none transition-all"
                      placeholder="Tandon Associates"
                      required
                    />
                  </div>
                </div>
              ) : null}
            </div>
          )}
          <div>
            <label className="block text-sm font-bold text-slate-700 mb-2">Email Address</label>
            <div className="relative">
              <Mail className="absolute left-3 top-1/2 -translate-y-1/2 text-slate-400" size={18} />
              <input 
                type="email" 
                value={loginEmail}
                onChange={(e) => setLoginEmail(e.target.value)}
                className="w-full pl-10 pr-4 py-3 bg-slate-50 border border-slate-200 rounded-xl focus:ring-2 focus:ring-emerald-500 outline-none transition-all"
                placeholder="demo@lawfirm.com"
                required
              />
            </div>
          </div>

          <div>
            <label className="block text-sm font-bold text-slate-700 mb-2">Password</label>
            <div className="relative">
              <Lock className="absolute left-3 top-1/2 -translate-y-1/2 text-slate-400" size={18} />
              <input 
                type="password" 
                value={loginPassword}
                onChange={(e) => setLoginPassword(e.target.value)}
                className="w-full pl-10 pr-4 py-3 bg-slate-50 border border-slate-200 rounded-xl focus:ring-2 focus:ring-emerald-500 outline-none transition-all"
                placeholder="••••••••"
                required
              />
            </div>
          </div>

          {authError && (
            <p className="text-rose-500 text-xs font-medium bg-rose-50 p-3 rounded-lg border border-rose-100">
              {authError}
            </p>
          )}

          <button 
            type="submit"
            disabled={loading}
            className="w-full bg-emerald-600 text-white py-3 rounded-xl font-bold shadow-lg shadow-emerald-200 hover:bg-emerald-700 transition-all flex items-center justify-center gap-2"
          >
            {loading ? 'Authenticating...' : (isSignup ? 'Create Account' : 'Sign In')}
            {!loading && <ChevronRight size={18} />}
          </button>

          <div className="text-center">
            <button 
              type="button"
              onClick={() => setIsSignup(!isSignup)}
              className="text-sm font-bold text-emerald-600 hover:text-emerald-700"
            >
              {isSignup ? 'Already have an account? Sign In' : "Don't have an account? Sign Up"}
            </button>
          </div>

          <div className="relative my-8">
            <div className="absolute inset-0 flex items-center">
              <div className="w-full border-t border-slate-100"></div>
            </div>
            <div className="relative flex justify-center text-xs uppercase">
              <span className="bg-white px-2 text-slate-400 font-medium">Quick Access for Testing</span>
            </div>
          </div>

          <div className="grid grid-cols-2 gap-3">
            <button 
              type="button"
              onClick={() => { setLoginEmail('student@university.edu'); setLoginPassword('Demo@123'); }}
              className="p-3 border border-slate-100 rounded-xl text-xs font-bold text-slate-600 hover:bg-emerald-50 hover:text-emerald-600 hover:border-emerald-100 transition-all flex flex-col items-center gap-1"
            >
              <Bookmark size={16} />
              Law Student
            </button>
            <button 
              type="button"
              onClick={() => { setLoginEmail('partner@tandonassociates.com'); setLoginPassword('Demo@123'); }}
              className="p-3 border border-slate-100 rounded-xl text-xs font-bold text-slate-600 hover:bg-emerald-50 hover:text-emerald-600 hover:border-emerald-100 transition-all flex flex-col items-center gap-1"
            >
              <Scale size={16} />
              Senior Partner
            </button>
          </div>
        </form>

        <div className="mt-8 pt-6 border-t border-slate-100 text-center">
          <p className="text-xs text-slate-400 mb-2 uppercase tracking-widest font-bold">Demo Credentials (Role Testing)</p>
          <div className="bg-slate-50 p-3 rounded-xl text-xs text-slate-600 font-mono text-left space-y-1">
            <p><strong>Lawyer:</strong> lawyer@tandonassociates.com</p>
            <p><strong>Admin:</strong> admin@tandonassociates.com</p>
            <p><strong>Student:</strong> student@university.edu</p>
            <p className="mt-2 text-slate-400 italic">Password can be anything</p>
          </div>
        </div>
      </motion.div>
    </div>
  );
};
