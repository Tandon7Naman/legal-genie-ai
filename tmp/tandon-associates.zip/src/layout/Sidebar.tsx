import React from 'react';
import { 
  LayoutDashboard, 
  Gavel, 
  Users, 
  Search, 
  FileSearch, 
  ClipboardList, 
  FileText, 
  BookOpen, 
  ShieldCheck, 
  BrainCircuit, 
  BarChart3, 
  Cpu, 
  Zap, 
  MessageSquare, 
  Bookmark, 
  Settings, 
  Briefcase, 
  HelpCircle, 
  LogOut,
  Scale,
  X
} from 'lucide-react';
import { useAppContext } from '../context/AppContext';

const SidebarItem = ({ icon: Icon, label, active, onClick }: any) => (
  <button
    onClick={onClick}
    className={`w-full flex items-center gap-3 px-4 py-3 rounded-xl transition-all duration-200 group ${
      active 
        ? 'bg-emerald-600 text-white shadow-lg shadow-emerald-500/30' 
        : 'text-slate-500 dark:text-slate-400 hover:bg-slate-100 dark:hover:bg-slate-800'
    }`}
  >
    <Icon size={20} strokeWidth={active ? 2.5 : 2} />
    <span className={`font-medium ${active ? 'font-bold' : 'group-hover:text-slate-900 dark:group-hover:text-slate-100'}`}>{label}</span>
  </button>
);

export const Sidebar: React.FC = () => {
  const { 
    activeTab, 
    setActiveTab, 
    isSidebarOpen, 
    setIsSidebarOpen, 
    user, 
    setIsAuth,
    setAiMode
  } = useAppContext();

  return (
    <aside className={`
      fixed lg:static inset-y-0 left-0 w-64 bg-white dark:bg-slate-900 border-r border-slate-200 dark:border-slate-800 flex flex-col p-6 shrink-0 z-50 transition-transform duration-300 lg:translate-x-0
      ${isSidebarOpen ? 'translate-x-0' : '-translate-x-full'}
    `}>
      <div className="flex items-center justify-between mb-10 px-2">
        <div className="flex items-center gap-3">
          <div className="bg-emerald-600 p-2 rounded-lg text-white">
            <Scale size={24} />
          </div>
          <h1 className="text-xl font-bold tracking-tight text-slate-900 dark:text-slate-100">Tandon <span className="text-emerald-600">Legal</span></h1>
        </div>
        <button onClick={() => setIsSidebarOpen(false)} className="lg:hidden p-2 text-slate-400 hover:text-slate-600 dark:hover:text-slate-200">
          <X size={20} />
        </button>
      </div>

      <nav className="flex-1 space-y-1 overflow-y-auto">
        <SidebarItem icon={LayoutDashboard} label="Dashboard" active={activeTab === 'dashboard'} onClick={() => { setActiveTab('dashboard'); setIsSidebarOpen(false); }} />
        <SidebarItem icon={Gavel} label="Cases" active={activeTab === 'cases'} onClick={() => { setActiveTab('cases'); setIsSidebarOpen(false); }} />
        <SidebarItem icon={Users} label="Clients" active={activeTab === 'clients'} onClick={() => { setActiveTab('clients'); setIsSidebarOpen(false); }} />
        <SidebarItem icon={Search} label="eCourts Tracker" active={activeTab === 'ecourts'} onClick={() => { setActiveTab('ecourts'); setIsSidebarOpen(false); }} />
        <SidebarItem icon={FileSearch} label="Legal Research" active={activeTab === 'research'} onClick={() => { setActiveTab('research'); setIsSidebarOpen(false); }} />
        <SidebarItem icon={ClipboardList} label="Drafting" active={activeTab === 'drafting'} onClick={() => { setActiveTab('drafting'); setIsSidebarOpen(false); }} />
        <SidebarItem icon={FileText} label="Contracts" active={activeTab === 'contracts'} onClick={() => { setActiveTab('contracts'); setIsSidebarOpen(false); }} />
        <SidebarItem icon={BookOpen} label="Documents" active={activeTab === 'documents'} onClick={() => { setActiveTab('documents'); setIsSidebarOpen(false); }} />
        <SidebarItem icon={Users} label="Team" active={activeTab === 'team'} onClick={() => { setActiveTab('team'); setIsSidebarOpen(false); }} />
        <SidebarItem icon={ShieldCheck} label="Conflict Checker" active={activeTab === 'conflict-checker'} onClick={() => { setActiveTab('conflict-checker'); setIsSidebarOpen(false); }} />
        <SidebarItem icon={BrainCircuit} label="Watchdog" active={activeTab === 'watchdog'} onClick={() => { setActiveTab('watchdog'); setIsSidebarOpen(false); }} />
        <SidebarItem icon={BarChart3} label="Analytics" active={activeTab === 'analytics'} onClick={() => { setActiveTab('analytics'); setIsSidebarOpen(false); }} />
        <SidebarItem icon={Cpu} label="AI Tools" active={activeTab === 'ai'} onClick={() => { setActiveTab('ai'); setIsSidebarOpen(false); }} />
        <SidebarItem icon={Zap} label="Innovation Hub" active={activeTab === 'innovation'} onClick={() => { setActiveTab('innovation'); setIsSidebarOpen(false); }} />
        {user?.userType === 'corporate' && (
          <SidebarItem icon={ShieldCheck} label="Compliance & Audit" active={activeTab === 'compliance-audit'} onClick={() => { setActiveTab('compliance-audit'); setIsSidebarOpen(false); }} />
        )}
        <SidebarItem icon={MessageSquare} label="AI Research Chat" active={activeTab === 'ai-chat'} onClick={() => { setActiveTab('ai-chat'); setAiMode('chat'); setIsSidebarOpen(false); }} />
        {user?.userType === 'student' && (
          <SidebarItem icon={Bookmark} label="Student Hub" active={activeTab === 'student-hub'} onClick={() => { setActiveTab('student-hub'); setIsSidebarOpen(false); }} />
        )}
        <SidebarItem icon={Settings} label="Settings" active={activeTab === 'settings'} onClick={() => { setActiveTab('settings'); setIsSidebarOpen(false); }} />
        {user?.role === 'client' && (
          <SidebarItem icon={Briefcase} label="Client Portal" active={activeTab === 'client-portal'} onClick={() => { setActiveTab('client-portal'); setIsSidebarOpen(false); }} />
        )}
      </nav>

      <div className="pt-6 border-t border-slate-100 dark:border-slate-800 space-y-1">
        <SidebarItem icon={HelpCircle} label="Support" />
        <button 
          onClick={() => setIsAuth(false)}
          className="w-full flex items-center gap-3 px-4 py-3 rounded-xl text-rose-500 hover:bg-rose-50 dark:hover:bg-rose-900/20 transition-all"
        >
          <LogOut size={20} />
          <span className="font-medium">Logout</span>
        </button>
      </div>
    </aside>
  );
};
