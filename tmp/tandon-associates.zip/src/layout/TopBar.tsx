import React from 'react';
import { 
  Menu, 
  Search, 
  Sun, 
  Moon, 
  Bell, 
  Gavel, 
  Users, 
  FileText,
  CheckCircle2,
  AlertCircle,
  Info
} from 'lucide-react';
import { useAppContext } from '../context/AppContext';
import { motion, AnimatePresence } from 'framer-motion';

export const TopBar: React.FC = () => {
  const { 
    setIsSidebarOpen, 
    globalSearch, 
    setGlobalSearch, 
    cases, 
    teamMembers, 
    recentDocuments, 
    setActiveTab, 
    isDarkMode, 
    setIsDarkMode, 
    showNotifications, 
    setShowNotifications, 
    notifications,
    user
  } = useAppContext();

  return (
    <header className="bg-white dark:bg-slate-900 border-b border-slate-200 dark:border-slate-800 px-4 sm:px-8 py-4 flex justify-between items-center z-20 sticky top-0">
      <div className="flex items-center gap-4 flex-1">
        <button 
          onClick={() => setIsSidebarOpen(true)}
          className="lg:hidden p-2 text-slate-500 dark:text-slate-400 hover:bg-slate-100 dark:hover:bg-slate-800 rounded-lg transition-all"
        >
          <Menu size={24} />
        </button>
        <div className="relative w-full max-w-md hidden xs:block group">
          <Search className="absolute left-3 top-1/2 -translate-y-1/2 text-slate-400 group-focus-within:text-emerald-500 transition-colors" size={18} />
          <input 
            type="text" 
            placeholder="Global Search (Cases, Docs, Team)..." 
            value={globalSearch}
            onChange={(e) => setGlobalSearch(e.target.value)}
            className="w-full pl-10 pr-4 py-2 bg-slate-100 dark:bg-slate-800 border-none rounded-xl focus:ring-2 focus:ring-emerald-500 transition-all outline-none text-sm dark:text-slate-100"
          />
          {globalSearch && (
            <div className="absolute top-full left-0 right-0 mt-2 bg-white dark:bg-slate-900 rounded-2xl shadow-2xl border border-slate-100 dark:border-slate-800 overflow-hidden z-50 max-h-96 overflow-y-auto">
              <div className="p-3 border-b border-slate-50 dark:border-slate-800 bg-slate-50/50 dark:bg-slate-800/50">
                <p className="text-[10px] font-bold text-slate-400 uppercase tracking-widest">Search Results</p>
              </div>
              <div className="divide-y divide-slate-50 dark:divide-slate-800">
                {cases.filter(c => c.name.toLowerCase().includes(globalSearch.toLowerCase())).map(c => (
                  <div key={c.id} onClick={() => { setActiveTab('cases'); setGlobalSearch(''); }} className="p-4 hover:bg-slate-50 dark:hover:bg-slate-800 cursor-pointer flex items-center gap-3">
                    <div className="p-2 bg-emerald-100 dark:bg-emerald-900/30 text-emerald-600 rounded-lg"><Gavel size={16} /></div>
                    <div>
                      <p className="text-sm font-bold text-slate-900 dark:text-slate-100">{c.name}</p>
                      <p className="text-[10px] text-slate-500">Case • {c.type}</p>
                    </div>
                  </div>
                ))}
                {teamMembers.filter(t => t.name.toLowerCase().includes(globalSearch.toLowerCase())).map(t => (
                  <div key={t.id} onClick={() => { setActiveTab('team'); setGlobalSearch(''); }} className="p-4 hover:bg-slate-50 dark:hover:bg-slate-800 cursor-pointer flex items-center gap-3">
                    <div className="p-2 bg-blue-100 dark:bg-blue-900/30 text-blue-600 rounded-lg"><Users size={16} /></div>
                    <div>
                      <p className="text-sm font-bold text-slate-900 dark:text-slate-100">{t.name}</p>
                      <p className="text-[10px] text-slate-500">Team Member • {t.role}</p>
                    </div>
                  </div>
                ))}
                {recentDocuments.filter(d => d.name.toLowerCase().includes(globalSearch.toLowerCase())).map(d => (
                  <div key={d.name} onClick={() => { setActiveTab('documents'); setGlobalSearch(''); }} className="p-4 hover:bg-slate-50 dark:hover:bg-slate-800 cursor-pointer flex items-center gap-3">
                    <div className="p-2 bg-amber-100 dark:bg-amber-900/30 text-amber-600 rounded-lg"><FileText size={16} /></div>
                    <div>
                      <p className="text-sm font-bold text-slate-900 dark:text-slate-100">{d.name}</p>
                      <p className="text-[10px] text-slate-500">Document • {d.type}</p>
                    </div>
                  </div>
                ))}
                {globalSearch && ![...cases, ...teamMembers, ...recentDocuments].some(item => (item.name || '').toLowerCase().includes(globalSearch.toLowerCase())) && (
                  <div className="p-8 text-center text-slate-400 text-sm italic">No matches found.</div>
                )}
              </div>
            </div>
          )}
        </div>
      </div>

      <div className="flex items-center gap-2 sm:gap-4">
        <button 
          onClick={() => setIsDarkMode(!isDarkMode)}
          className="p-2.5 text-slate-500 dark:text-slate-400 hover:bg-slate-100 dark:hover:bg-slate-800 rounded-xl transition-all"
          title={isDarkMode ? "Switch to Light Mode" : "Switch to Dark Mode"}
        >
          {isDarkMode ? <Sun size={20} /> : <Moon size={20} />}
        </button>
        <div className="relative">
          <button 
            onClick={() => setShowNotifications(!showNotifications)}
            className={`p-2.5 rounded-xl relative transition-all ${showNotifications ? 'bg-emerald-50 dark:bg-emerald-900/30 text-emerald-600' : 'text-slate-500 dark:text-slate-400 hover:bg-slate-100 dark:hover:bg-slate-800'}`}
          >
            <Bell size={20} />
            {notifications.some(n => !n.isRead) && (
              <span className="absolute top-2 right-2 w-2 h-2 bg-rose-500 rounded-full border-2 border-white dark:border-slate-900"></span>
            )}
          </button>
          
          <AnimatePresence>
            {showNotifications && (
              <motion.div 
                initial={{ opacity: 0, y: 10, scale: 0.95 }}
                animate={{ opacity: 1, y: 0, scale: 1 }}
                exit={{ opacity: 0, y: 10, scale: 0.95 }}
                className="absolute right-0 mt-3 w-80 sm:w-96 bg-white dark:bg-slate-900 rounded-2xl shadow-2xl border border-slate-100 dark:border-slate-800 overflow-hidden z-50"
              >
                <div className="p-4 border-b border-slate-50 dark:border-slate-800 flex justify-between items-center bg-slate-50/50 dark:bg-slate-800/50">
                  <h4 className="font-bold text-slate-900 dark:text-slate-100">Notifications</h4>
                  <button className="text-xs text-emerald-600 font-bold hover:underline">Mark all as read</button>
                </div>
                <div className="max-h-[400px] overflow-y-auto divide-y divide-slate-50 dark:divide-slate-800">
                  {notifications.map(n => (
                    <div key={n.id} className={`p-4 hover:bg-slate-50 dark:hover:bg-slate-800 transition-colors cursor-pointer ${!n.isRead ? 'bg-emerald-50/30 dark:bg-emerald-900/10' : ''}`}>
                      <div className="flex gap-3">
                        <div className={`p-2 rounded-lg shrink-0 ${
                          n.type === 'success' ? 'bg-emerald-100 text-emerald-600' : 
                          n.type === 'warning' ? 'bg-amber-100 text-amber-600' : 'bg-blue-100 text-blue-600'
                        }`}>
                          {n.type === 'success' ? <CheckCircle2 size={16} /> : n.type === 'warning' ? <AlertCircle size={16} /> : <Info size={16} />}
                        </div>
                        <div className="space-y-1">
                          <p className="text-sm font-bold text-slate-900 dark:text-slate-100">{n.title}</p>
                          <p className="text-xs text-slate-500 leading-relaxed">{n.message}</p>
                          <p className="text-[10px] text-slate-400 font-medium">{n.time}</p>
                        </div>
                      </div>
                    </div>
                  ))}
                </div>
                <button className="w-full p-3 text-center text-xs font-bold text-slate-500 hover:bg-slate-50 dark:hover:bg-slate-800 transition-colors border-t border-slate-50 dark:border-slate-800">
                  View All Notifications
                </button>
              </motion.div>
            )}
          </AnimatePresence>
        </div>
        
        <div className="flex items-center gap-3 pl-2 sm:pl-4 border-l border-slate-100 dark:border-slate-800">
          <div className="hidden sm:block text-right">
            <p className="text-sm font-bold text-slate-900 dark:text-slate-100">{user?.name}</p>
            <p className="text-[10px] font-bold text-emerald-600 uppercase tracking-widest">{user?.role}</p>
          </div>
          <div className="w-10 h-10 rounded-xl bg-gradient-to-br from-emerald-500 to-teal-600 flex items-center justify-center text-white font-bold shadow-lg shadow-emerald-500/20">
            {user?.name?.charAt(0)}
          </div>
        </div>
      </div>
    </header>
  );
};
