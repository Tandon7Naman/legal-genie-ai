import React, { createContext, useContext, useState, useEffect, ReactNode } from 'react';
import { Section, User, Notification, UserRole } from '../types';
import { io, Socket } from 'socket.io-client';

interface AppContextType {
  activeTab: Section;
  setActiveTab: (tab: Section) => void;
  user: User | null;
  setUser: (user: User | null) => void;
  isAuth: boolean;
  setIsAuth: (auth: boolean) => void;
  showLanding: boolean;
  setShowLanding: (show: boolean) => void;
  isSignup: boolean;
  setIsSignup: (signup: boolean) => void;
  firmName: string;
  setFirmName: (name: string) => void;
  loginEmail: string;
  setLoginEmail: (email: string) => void;
  loginPassword: string;
  setLoginPassword: (pass: string) => void;
  authError: string;
  setAuthError: (err: string) => void;
  handleLogin: (e: React.FormEvent) => Promise<void>;
  handleFileUpload: (e: React.ChangeEvent<HTMLInputElement>) => void;
  isDarkMode: boolean;
  setIsDarkMode: (dark: boolean) => void;
  isSidebarOpen: boolean;
  setIsSidebarOpen: (open: boolean) => void;
  globalSearch: string;
  setGlobalSearch: (search: string) => void;
  notifications: Notification[];
  setNotifications: (notifications: Notification[]) => void;
  showNotifications: boolean;
  setShowNotifications: (show: boolean) => void;
  cases: any[];
  setCases: (cases: any[]) => void;
  teamMembers: any[];
  setTeamMembers: (members: any[]) => void;
  recentDocuments: any[];
  setRecentDocuments: (docs: any[]) => void;
  aiMode: string;
  setAiMode: (mode: any) => void;
  addToast: (message: string, type?: 'success' | 'error' | 'info') => void;
  toasts: Array<{ id: string, message: string, type: 'success' | 'error' | 'info' }>;
  loading: boolean;
  setLoading: (loading: boolean) => void;
}

const AppContext = createContext<AppContextType | undefined>(undefined);

export const AppProvider: React.FC<{ children: ReactNode }> = ({ children }) => {
  const [activeTab, setActiveTab] = useState<Section>('dashboard');
  const [user, setUser] = useState<User | null>(() => {
    const saved = localStorage.getItem('legal_user');
    return saved ? JSON.parse(saved) : null;
  });
  const [isAuth, setIsAuth] = useState(() => {
    return localStorage.getItem('legal_is_auth') === 'true';
  });
  const [showLanding, setShowLanding] = useState(true);
  const [isSignup, setIsSignup] = useState(false);
  const [firmName, setFirmName] = useState('');
  const [loginEmail, setLoginEmail] = useState('demo@lawfirm.com');
  const [loginPassword, setLoginPassword] = useState('Demo@123');
  const [authError, setAuthError] = useState('');

  const handleLogin = async (e: React.FormEvent) => {
    e.preventDefault();
    setLoading(true);
    setAuthError('');

    try {
      const res = await fetch('/api/auth/login', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ email: loginEmail })
      });
      
      if (!res.ok) throw new Error('Login failed');
      const data = await res.json();
      
      // Normalize roles from server to frontend types
      let userType: UserRole = 'firm';
      if (data.role === 'student') userType = 'student';
      else if (data.role === 'client') userType = 'corporate'; 

      const newUser: User = {
        id: data.id,
        email: data.email,
        name: data.name,
        role: data.role,
        userType: userType
      };

      setUser(newUser);
      setIsAuth(true);
      setShowLanding(false);
      addToast(`Welcome back, ${data.name}!`, 'success');
      
      if (userType === 'student') {
        setActiveTab('student-hub');
      }
    } catch (err) {
      setAuthError('Failed to login. Please try again.');
    } finally {
      setLoading(false);
    }
  };
  const [isDarkMode, setIsDarkMode] = useState(() => {
    return localStorage.getItem('legal_dark_mode') === 'true';
  });
  const [isSidebarOpen, setIsSidebarOpen] = useState(false);
  const [globalSearch, setGlobalSearch] = useState('');
  const [showNotifications, setShowNotifications] = useState(false);
  const [loading, setLoading] = useState(false);
  const [aiMode, setAiMode] = useState('chat');
  const [toasts, setToasts] = useState<Array<{ id: string, message: string, type: 'success' | 'error' | 'info' }>>([]);

  const [notifications, setNotifications] = useState<Notification[]>([
    { id: '1', title: 'Case Update', message: 'Hearing for Case #1234 has been rescheduled to March 15th.', time: '2h ago', isRead: false, type: 'info' },
    { id: '2', title: 'Document Ready', message: 'The Non-Disclosure Agreement for Client X is ready for review.', time: '5h ago', isRead: false, type: 'success' },
    { id: '3', title: 'Subscription Warning', message: 'Your professional tier subscription expires in 3 days.', time: '1d ago', isRead: true, type: 'warning' },
  ]);

  const [cases, setCases] = useState<any[]>(() => {
    const saved = localStorage.getItem('legal_cases');
    return saved ? JSON.parse(saved) : [
      { id: '1', name: 'Smith vs Johnson', type: 'Civil Litigation', status: 'Active', nextHearing: 'Dec 15, 2025', timestamp: new Date('2025-12-15').getTime(), department: 'Litigation' },
      { id: '2', name: 'ABC Corp Merger', type: 'Corporate', status: 'Active', nextHearing: 'Dec 20, 2025', timestamp: new Date('2025-12-20').getTime(), department: 'Corporate' },
      { id: '3', name: 'Property Dispute', type: 'Real Estate', status: 'Pending', nextHearing: 'Jan 5, 2026', timestamp: new Date('2026-01-05').getTime(), department: 'Real Estate' },
      { id: '4', name: 'Divorce Settlement', type: 'Family Law', status: 'Completed', nextHearing: 'Closed', timestamp: new Date('2025-11-01').getTime(), department: 'Family' },
    ];
  });

  const [teamMembers, setTeamMembers] = useState<any[]>(() => {
    const saved = localStorage.getItem('legal_team');
    return saved ? JSON.parse(saved) : [
      { id: '1', name: 'John Doe', email: 'john@lawfirm.com', role: 'Admin', status: 'Active' },
      { id: '2', name: 'Jane Smith', email: 'jane@lawfirm.com', role: 'Attorney', status: 'Active' },
      { id: '3', name: 'Mike Johnson', email: 'mike@lawfirm.com', role: 'Paralegal', status: 'Active' },
    ];
  });

  const [recentDocuments, setRecentDocuments] = useState<any[]>(() => {
    const saved = localStorage.getItem('legal_documents');
    return saved ? JSON.parse(saved) : [
      { name: 'Court_Order_Smith.pdf', type: 'PDF', date: 'Today', size: '2.1 MB', timestamp: new Date().getTime(), client: 'Smith & Co' },
      { name: 'Contract_Draft.docx', type: 'Word', date: 'Yesterday', size: '1.3 MB', timestamp: new Date().getTime() - 86400000, client: 'Tech Corp' },
      { name: 'Financial_Analysis.xlsx', type: 'Excel', date: '2 days ago', size: '0.9 MB', timestamp: new Date().getTime() - 172800000, client: 'Global Fin' },
      { name: 'Client_Intake_Form.pdf', type: 'PDF', date: 'Last Week', size: '0.5 MB', timestamp: new Date().getTime() - 604800000, client: 'John Doe' },
      { name: 'Settlement_Agreement.docx', type: 'Word', date: 'Last Month', size: '1.8 MB', timestamp: new Date().getTime() - 2592000000, client: 'Smith & Co' },
    ];
  });

  const addToast = (message: string, type: 'success' | 'error' | 'info' = 'success') => {
    const id = Date.now().toString();
    setToasts(prev => [...prev, { id, message, type }]);
    setTimeout(() => {
      setToasts(prev => prev.filter(t => t.id !== id));
    }, 3000);
  };

  const handleFileUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;
    
    const newDoc = {
      name: file.name,
      type: file.name.split('.').pop()?.toUpperCase() || 'File',
      date: 'Just now',
      size: `${(file.size / 1024 / 1024).toFixed(1)} MB`,
      timestamp: new Date().getTime(),
      client: 'Unassigned'
    };
    
    setRecentDocuments(prev => [newDoc, ...prev]);
    addToast(`${file.name} uploaded successfully!`, 'success');
  };

  useEffect(() => {
    localStorage.setItem('legal_user', JSON.stringify(user));
    localStorage.setItem('legal_is_auth', JSON.stringify(isAuth));
    localStorage.setItem('legal_dark_mode', JSON.stringify(isDarkMode));
    localStorage.setItem('legal_cases', JSON.stringify(cases));
    localStorage.setItem('legal_team', JSON.stringify(teamMembers));
    localStorage.setItem('legal_documents', JSON.stringify(recentDocuments));

    if (isDarkMode) {
      document.documentElement.classList.add('dark');
    } else {
      document.documentElement.classList.remove('dark');
    }
  }, [user, isAuth, isDarkMode, cases, teamMembers, recentDocuments]);

  return (
    <AppContext.Provider value={{
      activeTab, setActiveTab,
      user, setUser,
      isAuth, setIsAuth,
      showLanding, setShowLanding,
      isSignup, setIsSignup,
      firmName, setFirmName,
      loginEmail, setLoginEmail,
      loginPassword, setLoginPassword,
      authError, setAuthError,
      handleLogin,
      handleFileUpload,
      isDarkMode, setIsDarkMode,
      isSidebarOpen, setIsSidebarOpen,
      globalSearch, setGlobalSearch,
      notifications, setNotifications,
      showNotifications, setShowNotifications,
      cases, setCases,
      teamMembers, setTeamMembers,
      recentDocuments, setRecentDocuments,
      aiMode, setAiMode,
      addToast, toasts,
      loading, setLoading
    }}>
      {children}
    </AppContext.Provider>
  );
};

export const useAppContext = () => {
  const context = useContext(AppContext);
  if (context === undefined) {
    throw new Error('useAppContext must be used within an AppProvider');
  }
  return context;
};
