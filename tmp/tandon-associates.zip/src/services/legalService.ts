import { GoogleGenAI, ThinkingLevel, Modality } from "@google/genai";

const ai = new GoogleGenAI({ apiKey: process.env.GEMINI_API_KEY || "" });

// 1. Complex Legal Reasoning (Thinking Mode)
export const askLegalAssistantWithThinking = async (prompt: string) => {
  const model = ai.models.generateContent({
    model: "gemini-3.1-pro-preview",
    contents: prompt,
    config: {
      thinkingConfig: { thinkingLevel: ThinkingLevel.HIGH },
      systemInstruction: "You are a senior legal consultant. Analyze this complex legal scenario with deep reasoning.",
    },
  });
  return (await model).text;
};

// 2. Fast Legal Definitions (Flash Lite)
export const quickLegalHelp = async (prompt: string) => {
  const model = ai.models.generateContent({
    model: "gemini-2.5-flash-lite-latest",
    contents: prompt,
    config: {
      systemInstruction: "You are a concise legal dictionary. Provide brief, accurate definitions.",
    },
  });
  return (await model).text;
};

// 3. Search Grounding (Case Law)
export const searchLegalPrecedents = async (prompt: string) => {
  const model = ai.models.generateContent({
    model: "gemini-3-flash-preview",
    contents: prompt,
    config: {
      tools: [{ googleSearch: {} }],
      systemInstruction: `Find recent and relevant case law or statutes. 
      CRITICAL: For each source found, evaluate its legal validity and authority. 
      Distinguish between binding precedents (Supreme Court, High Courts), persuasive authorities, and general legal commentary. 
      Flag any potentially outdated or unreliable sources.
      Structure your response with a "Source Quality Assessment" section.`,
    },
  });
  const response = await model;
  return {
    text: response.text,
    sources: response.candidates?.[0]?.groundingMetadata?.groundingChunks || []
  };
};

// 4. Maps Grounding (Find Courts/Services)
export const locateLegalServices = async (prompt: string, location?: {lat: number, lng: number}) => {
  const config: any = {
    tools: [{ googleMaps: {} }],
    systemInstruction: "Locate legal services, courts, or police stations.",
  };
  
  if (location) {
    config.toolConfig = {
      retrievalConfig: {
        latLng: {
          latitude: location.lat,
          longitude: location.lng
        }
      }
    };
  }

  const model = ai.models.generateContent({
    model: "gemini-2.5-flash",
    contents: prompt,
    config: config,
  });
  const response = await model;
  return {
    text: response.text,
    places: response.candidates?.[0]?.groundingMetadata?.groundingChunks || []
  };
};

// 5. Image Analysis (Evidence Analysis)
export const analyzeEvidenceImage = async (prompt: string, base64Image: string, mimeType: string = "image/jpeg") => {
  const model = ai.models.generateContent({
    model: "gemini-3.1-pro-preview",
    contents: {
      parts: [
        { inlineData: { mimeType, data: base64Image } },
        { text: prompt }
      ]
    },
  });
  return (await model).text;
};

// 6. Image Generation (Visual Evidence/Exhibits)
export const generateVisualEvidence = async (prompt: string, size: "1K" | "2K" | "4K" = "1K") => {
  const apiKey = process.env.API_KEY || process.env.GEMINI_API_KEY || "";
  const freshAi = new GoogleGenAI({ apiKey });
  
  const model = freshAi.models.generateContent({
    model: "gemini-3-pro-image-preview",
    contents: { parts: [{ text: prompt }] },
    config: {
      imageConfig: {
        imageSize: size,
        aspectRatio: "16:9"
      }
    }
  });
  
  const response = await model;
  // Extract image
  for (const part of response.candidates?.[0]?.content?.parts || []) {
    if (part.inlineData) {
      return `data:${part.inlineData.mimeType};base64,${part.inlineData.data}`;
    }
  }
  return null;
};

// 7. Image Editing (Nano Banana)
export const editEvidenceImage = async (prompt: string, base64Image: string, mimeType: string = "image/jpeg") => {
  const model = ai.models.generateContent({
    model: "gemini-2.5-flash-image",
    contents: {
      parts: [
        { inlineData: { mimeType, data: base64Image } },
        { text: prompt }
      ]
    },
  });
  
  const response = await model;
  for (const part of response.candidates?.[0]?.content?.parts || []) {
    if (part.inlineData) {
      return `data:${part.inlineData.mimeType};base64,${part.inlineData.data}`;
    }
  }
  return null;
};

// 8. Video Generation (Veo)
export const animateEvidenceVideo = async (prompt: string, base64Image?: string, mimeType: string = "image/jpeg") => {
  const apiKey = process.env.API_KEY || process.env.GEMINI_API_KEY || "";
  const freshAi = new GoogleGenAI({ apiKey });

  const contents: any = { prompt };
  if (base64Image) {
    contents.image = { imageBytes: base64Image, mimeType };
  }

  let operation = await freshAi.models.generateVideos({
    model: "veo-3.1-fast-generate-preview",
    ...contents,
    config: {
      numberOfVideos: 1,
      resolution: "720p",
      aspectRatio: "16:9"
    }
  });

  // Poll for completion
  while (!operation.done) {
    await new Promise(resolve => setTimeout(resolve, 5000));
    operation = await freshAi.operations.getVideosOperation({ operation });
  }

  const videoUri = operation.response?.generatedVideos?.[0]?.video?.uri;
  if (!videoUri) return null;

  // Fetch the actual video bytes using the API key
  const response = await fetch(videoUri, {
    method: 'GET',
    headers: { 'x-goog-api-key': apiKey },
  });
  
  const blob = await response.blob();
  return URL.createObjectURL(blob);
};

// 9. Audio Transcription
export const transcribeLegalAudio = async (base64Audio: string, mimeType: string = "audio/mp3") => {
  const model = ai.models.generateContent({
    model: "gemini-3-flash-preview",
    contents: {
      parts: [
        { inlineData: { mimeType, data: base64Audio } },
        { text: "Transcribe this legal audio recording accurately." }
      ]
    },
  });
  return (await model).text;
};

// 10. Text to Speech
export const synthesizeLegalSpeech = async (text: string) => {
  const model = ai.models.generateContent({
    model: "gemini-2.5-flash-preview-tts",
    contents: { parts: [{ text }] },
    config: {
      responseModalities: [Modality.AUDIO],
      speechConfig: {
        voiceConfig: { prebuiltVoiceConfig: { voiceName: "Puck" } }
      }
    }
  });
  
  const response = await model;
  const audioData = response.candidates?.[0]?.content?.parts?.[0]?.inlineData?.data;
  if (audioData) {
    return `data:audio/mp3;base64,${audioData}`;
  }
  return null;
};

// 11. Moot Court Judge (Interactive)
export const startMootCourtSession = async (caseSummary: string) => {
  const prompt = `
    You are a presiding Judge in a Moot Court competition. 
    The case summary is: ${caseSummary}
    
    Start the session by asking the counsel (the student) to present their opening arguments. 
    Be professional, authoritative, and ready to interrupt with sharp legal questions.
  `;
  
  const model = ai.models.generateContent({
    model: "gemini-3.1-pro-preview",
    contents: prompt,
    config: {
      systemInstruction: "You are a strict but fair Moot Court Judge. Engage in a realistic legal dialogue.",
    },
  });
  return (await model).text;
};

// 12. Case Brief Generator
export const generateCaseBrief = async (judgmentText: string) => {
  const prompt = `
    Analyze the following judgment and generate a structured Case Brief:
    1. Case Name & Citation
    2. Facts of the Case
    3. Issues Raised
    4. Arguments (Petitioner vs Respondent)
    5. Rule of Law (Ratio Decidendi)
    6. Court's Decision (Obiter Dicta)
    7. Conclusion/Impact
    
    Judgment:
    ${judgmentText}
  `;
  
  const model = ai.models.generateContent({
    model: "gemini-3.1-pro-preview",
    contents: prompt,
    config: {
      systemInstruction: "You are an expert legal academic. Provide precise, structured case briefs.",
    },
  });
  return (await model).text;
};

// 13. Statute Simplifier
export const simplifyStatute = async (sectionText: string) => {
  const prompt = `
    Translate the following legal statute/section into "Plain English" that a first-year law student or a layperson can understand. 
    Include:
    - Simplified Meaning
    - Key Requirements
    - A Real-world Example
    
    Statute:
    ${sectionText}
  `;
  
  const model = ai.models.generateContent({
    model: "gemini-3-flash-preview",
    contents: prompt,
    config: {
      systemInstruction: "You are a legal educator. Make complex law simple without losing its essence.",
    },
  });
  return (await model).text;
};

// 14. Evidence Timeline Generator
export const generateEvidenceTimeline = async (caseDetails: string) => {
  const prompt = `
    Based on the following case details, extract a chronological timeline of events. 
    Format the output as a JSON array of objects with 'date', 'event', and 'significance' fields.
    
    Case Details:
    ${caseDetails}
  `;
  
  const model = ai.models.generateContent({
    model: "gemini-3-flash-preview",
    contents: prompt,
    config: {
      responseMimeType: "application/json",
      systemInstruction: "You are a forensic legal analyst. Extract clear timelines from narratives.",
    },
  });
  return (await model).text;
};

// Legacy/Simple
export const legalAssistant = async (prompt: string, context?: string) => {
  return askLegalAssistantWithThinking(prompt); // Upgrade default to thinking
};

export const generateVakalatnama = (data: any) => {
  return `
VAKALATNAMA
IN THE COURT OF ${data.courtName}
CASE NO. ${data.caseNo} OF 2026

${data.petitioner} ... Petitioner/Plaintiff
VERSUS
${data.respondent} ... Respondent/Defendant

I, ${data.clientName}, do hereby appoint Tandon Associates, Advocates, to appear and act for me in the above-mentioned case...
  `.trim();
};

export const generateLegalDocument = async (templateType: string, caseDetails: string) => {
  const prompt = `
You are an expert legal drafter. Generate a professional draft of a ${templateType} based on the following case details. 
Ensure the formatting is clean, uses appropriate legal terminology, and includes placeholders like [Insert Date] or [Insert Name] where information is missing.

Case Details:
${caseDetails}
  `;
  
  const model = ai.models.generateContent({
    model: "gemini-3.1-pro-preview",
    contents: prompt,
    config: {
      systemInstruction: "You are a senior legal drafter. Output only the drafted document text without markdown code blocks, or with standard markdown formatting.",
    },
  });
  return (await model).text;
};
